// RO Survivors bot v6.2 — PRE-BOSS THINNING, on top of v6/v6.1 (build main-BNOcv2PN.js, live 2026-11-11).
// v6 verdict: 0/3 clears, best 311.8s, first Eclipse kill — but all three
// runs died the SAME way: buried in the mob pack during a boss fight,
// HP melting ~9/s from contact damage at nearest 6-21px, live 66-70.
// The dodge layer works (skill hits are not the killer); the pack is.
// v6.2 = TWO changes on top of v6/v6.1:
//  (a) PRE-BOSS THINNING: in the ~40s before each boss spawns
//      (Eclipse 150, Toad 300, Dragon Fly 450, Vocal 600, Mastering 720),
//      force the pack thin — kite outward and burn adds down until live
//      < 40 AND nearest non-boss enemy > 100px, then hold that spacing
//      until the boss spawns. No loot detours, no elite pulls in the window.
//  (b) BREAK-OUT: during a boss fight, if the pack re-thickens
//      (live > 40 AND nearest non-boss enemy < 100px), break OUT of the
//      pack first (path-aware gap escape, held 4s) — do not keep engaging adds
//      inside it — re-establish spacing, then re-engage the boss.
//  (c) CORRECTION from Araso — MULTI-AoE AVOIDANCE: the bot also dies
//      because boss skills OVERLAP: it dodges one cast and lands inside
//      another's AoE. The dodge now considers ALL live danger zones AT
//      ONCE (their union) and steers to a spot safe from ALL of them; if
//      no fully-safe spot exists it minimises overlapping zones, then pack
//      density, then distance from the boss band — never stands still
//      inside a zone. Per-cast radial shoves are gone. Each death is
//      logged with its real damage source (skill vs contact, which skill,
//      zones overlapped at death) so the report can prove which diagnosis
//      was right.
// Mini-bosses are never skipped (they drop loot); meat rule unchanged;
// all four of Araso's points, v6.1 sidestep + killing-first boss mode,
// and loot-first are kept. Guest only, normal stages only, read-only
// patch, never Endless Tower. See ../beast-v6-report.md.
const { chromium } = require('playwright');
const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { gapDir, hordeThreatAt, pathThreat, routeVectorFromPath } = require('./movement-policy');

const SITE = 'https://ro-survivors.com/';
// The patched bundle is not a fixed file: the site ships a new build (and a
// new file name) on every deploy. The patch tool finds the live bundle and
// writes patched/<live name> plus patched/bundle.json; the bot reads that
// manifest. If patching is not possible the bot still runs on the plain live
// bundle (the farm keeps farming, only the inventory detail is missing).
const PATCHED_MANIFEST = path.join(__dirname, '..', 'rea', 'patched', 'bundle.json');
let PATCHED = null;
const PICKER_UNLOCK_BASE_MS = 380, PICKER_UNLOCK_PER_CARD_MS = 120;
const LOOP_MS = Math.max(120, parseInt(process.argv.find(a => a.startsWith('--loop-ms='))?.split('=')[1] || '250', 10));
const argv = Object.fromEntries(process.argv.slice(2).map(a => { const [k, v] = a.replace(/^--/, '').split('='); return [k, v === undefined ? 'true' : v]; }));
const ATTACH_EXISTING = argv['attach-existing'] !== 'false';
const START_FROM_EXISTING = argv['start-existing'] === 'true';
const PROBE = argv.probe === 'true';
const VIEWPORT = (argv.viewport || '640x400').split('x').map(Number);
const DSF = parseFloat(argv.dsf || '0.5');
const SPEED_PROBE_SECONDS = parseInt(argv['probe-seconds'] || '60', 10);
const RUNS = parseInt(argv.runs || '1', 10);
const MAX_SECONDS = parseInt(argv['max-seconds'] || '3600', 10);
const HEADLESS = argv.headless !== 'false';
const RECORD_VIDEO = argv['record-video'] === 'true'; // headed runs: Playwright records each page as .webm under OUT/videos
let JOB = (argv.job || 'mage').toLowerCase();
let STAGE = (argv.stage || 'prontera').toLowerCase();
const LADDER = argv.ladder === 'true';
const COMPARE = argv.compare === 'true';
const MAX_LOOT = argv['max-loot'] === 'true'; // push every difficulty slider to max (max loot multiplier)
// Camoufox mode: the bot launches its own headless Camoufox (Firefox) profiles
// instead of attaching to the app's CDP browser. One persistent profile per
// account; login and the created character persist across runs.
const CAMOUFOX = argv.browser === 'camoufox';
const CAMOUFOX_ROOT = process.env.RO_CAMOFOX_ROOT ||
  '/home/whizshounen/.local/share/mise/installs/node/26.12.1/lib/node_modules/camofox-browser/node_modules';
let camoufoxContext = null;
const OUT = path.resolve(argv.out || path.join(__dirname, 'logs-v6.2'));
// Multi-account mode: one account per bot process. Its sign-in is cached in
// its own file so later runs skip the login form.
const ACCOUNT_USER = process.env.RO_BOT_USER || argv.username || '';
const ACCOUNT_PASS = process.env.RO_BOT_PASS || argv.password || '';
// The character's equipment + backpack (read from the plaza snapshot) so the
// GUI can show the live inventory even while a run is going.
let lastCharData = null;
const AUTH_STATE = ACCOUNT_USER
  ? path.join(OUT, 'accounts', ACCOUNT_USER.replace(/[^A-Za-z0-9._-]/g, '_') + '.json')
  : path.join(OUT, 'browser-auth-state.json');
let ownedBrowserProcess = null;
let ownedHeadlessContext = null;
function commandOutput(command, args = []) {
  try {
    const result = spawnSync(command, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
    return result.status === 0 ? result.stdout.trim() : '';
  } catch { return ''; }
}
function executableForCommand(command) {
  if (!command) return null;
  if (path.isAbsolute(command)) return fs.existsSync(command) ? command : null;
  return commandOutput('which', [command]) || null;
}
function executableFromDesktop(desktopId, visited = new Set()) {
  if (!desktopId || visited.has(desktopId)) return null;
  visited.add(desktopId);
  const dataHome = process.env.XDG_DATA_HOME || path.join(require('os').homedir(), '.local', 'share');
  const dataDirs = [...new Set([dataHome, ...(process.env.XDG_DATA_DIRS || '/usr/local/share:/usr/share').split(':')])];
  for (const dataDir of dataDirs) {
    const desktopFile = path.join(dataDir, 'applications', desktopId);
    if (!fs.existsSync(desktopFile)) continue;
    const contents = fs.readFileSync(desktopFile, 'utf8');
    const line = contents.match(/^Exec=(.*)$/m)?.[1]?.trim();
    const match = line && line.match(/^(?:"([^"]+)"|'([^']+)'|(\S+))/);
    const command = match && (match[1] || match[2] || match[3]);
    if (!command) continue;
    if (path.basename(command) === 'omarchy-launch-browser') {
      return executableFromDesktop(commandOutput('omarchy-cmd-default-browser'), visited);
    }
    const executable = executableForCommand(command);
    if (executable) return executable;
  }
  return null;
}
function defaultBrowserExecutable() {
  const desktopId = commandOutput('omarchy-cmd-default-browser') ||
    commandOutput('xdg-settings', ['get', 'default-web-browser']);
  const selected = executableFromDesktop(desktopId);
  if (selected) return selected;
  const browserCommand = process.env.BROWSER?.trim().split(/\s+/)[0];
  const fallback = executableForCommand(browserCommand);
  if (fallback) return fallback;
  throw new Error(`Couldn't resolve the default browser${desktopId ? ` (${desktopId})` : ''}.`);
}
async function cdpIsReady(cdpUrl) {
  try {
    const response = await fetch(`${cdpUrl.replace(/\/$/, '')}/json/version`, { signal: AbortSignal.timeout(1000) });
    return response.ok;
  } catch { return false; }
}
const patchedRouteStates = new WeakMap();
let patchedDocCache = null;
// Firefox (Camoufox) ignores Playwright's fulfilled ES-module responses, so
// the patched bundle cannot be swapped in at the module URL. It CAN serve a
// document, so we rewrite the site's index.html and inline the patched bundle
// as a module script. Relative chunk specifiers are re-pointed at /build/
// because an inline module resolves them against the document URL.
async function patchedDocumentHtml() {
  if (patchedDocCache) return patchedDocCache;
  const html = await (await fetch(SITE)).text();
  let src = fs.readFileSync(PATCHED, 'utf8');
  // No service worker in headless mode: it would serve the live bundle from
  // its cache on the next load. (Done before the path rewrite below, or the
  // registration URL would already have been rewritten.)
  src = src.replace(/await a\.register\("sw\.js"\)/g, 'await Promise.resolve(null)');
  src = src.replace(/from"\.\/([A-Za-z0-9_.-]+\.js)"/g, 'from"./build/$1"');
  src = src.replace(/"\.\/([A-Za-z0-9_.-]+\.js)"/g, '"./build/$1"');
  const inline = '<script type="module">' + src.replace(/<\/script/gi, '<\\/script') + '</script>';
  // Function replacer: the bundle contains $& / $' sequences, and a string
  // replacement would expand them and corrupt the inlined source.
  const patched = html.replace(/<script[^>]*main-[A-Za-z0-9_-]+\.js[^>]*><\/script>/, () => inline);
  if (patched === html) throw new Error('could not find the game bundle script tag in index.html');
  patchedDocCache = patched;
  return patched;
}
async function installPatchedDocument(page) {
  if (!PATCHED) return { served: false };
  const html = await patchedDocumentHtml();
  await page.route(url => {
    try {
      const href = String(url && url.href ? url.href : url).replace(/\/$/, '');
      return href === SITE.replace(/\/$/, '');
    } catch { return false; }
  }, async route => {
    log({ msg: 'patched document served (patched bundle inlined)' });
    await route.fulfill({ status: 200, contentType: 'text/html; charset=utf-8', headers: { 'cache-control': 'no-store' }, body: html });
  });
}
async function installPatchedBundleRoute(page) {
  if (!PATCHED) return { served: false, cdpSession: null };
  if (CAMOUFOX) return installPatchedDocument(page);
  let state = patchedRouteStates.get(page);
  if (state) return state;
  state = { served: false, cdpSession: null };
  try {
    state.cdpSession = await page.context().newCDPSession(page);
    await state.cdpSession.send('Network.setBypassServiceWorker', { bypass: true });
    // The cache stays ENABLED (the game's art must stay cached between runs,
    // that is what makes a start fast). Only the patched bundle is served
    // with no-store below, so the page can never run a stale patch.
  } catch (error) {
    log({ msg: `could not bypass cached/service-worker bundle responses: ${String(error).slice(0, 160)}` });
  }
  const bundleName = path.basename(PATCHED);
  page.on('request', request => {
    if (request.url().includes('main-')) log({ msg: `main bundle request: ${request.url()}` });
  });
  await page.route(url => {
    try {
      // Playwright hands the matcher a URL object in some builds and a string
      // in others; a broken matcher silently serves the UNPATCHED bundle.
      const pathname = (url && typeof url === 'object' && url.pathname)
        ? url.pathname
        : new URL(String(url)).pathname;
      return pathname.endsWith(`/${bundleName}`);
    }
    catch { return false; }
  }, async route => {
    state.served = true;
    log({ msg: 'patched bundle served (route fulfilled)' });
    await route.fulfill({
      status: 200,
      contentType: 'text/javascript',
      // Never cache the patched bundle: the next run must always get the
      // current one, while the rest of the game stays cached.
      headers: { 'cache-control': 'no-store' },
      body: fs.readFileSync(PATCHED, 'utf8'),
    });
  });
  patchedRouteStates.set(page, state);
  return state;
}
async function saveBrowserAuth(context) {
  try {
    fs.mkdirSync(path.dirname(AUTH_STATE), { recursive: true });
    const state = await context.storageState({ indexedDB: true });
    const temporary = `${AUTH_STATE}.tmp-${process.pid}`;
    fs.writeFileSync(temporary, JSON.stringify(state), { mode: 0o600 });
    fs.chmodSync(temporary, 0o600);
    fs.renameSync(temporary, AUTH_STATE);
  } catch (error) {
    log({ msg: `could not save browser sign-in state: ${String(error).slice(0, 180)}` });
  }
}
async function closeOwnedHeadlessBrowser() {
  if (!HEADLESS) return;
  if (ownedHeadlessContext) {
    const context = ownedHeadlessContext;
    ownedHeadlessContext = null;
    await context.close().catch(() => {});
  }
  if (camoufoxContext) {
    const context = camoufoxContext;
    camoufoxContext = null;
    await context.close().catch(() => {});
  }
  if (ownedBrowserProcess && ownedBrowserProcess.exitCode === null) {
    ownedBrowserProcess.kill('SIGTERM');
  }
  ownedBrowserProcess = null;
}
let shuttingDown = false;
for (const signal of ['SIGTERM', 'SIGINT']) {
  process.on(signal, () => {
    if (shuttingDown) return;
    shuttingDown = true;
    closeOwnedHeadlessBrowser().finally(() => process.exit(signal === 'SIGINT' ? 130 : 143));
  });
}
// Fallback only. Each map has its own live script.bosses schedule; the
// snapshot supplies that schedule at run time so Payon Cave, Prontera and
// future maps do not share a fake Prontera timetable.
const FALLBACK_BOSS_TIMES = [150, 300, 450, 600, 720];
// Job defs from soul_linker (pp table): hp/speed/start skill/basic attack.
const JOB_DEFS = {
  swordsman: { re: /swordsman|espadach/i, hp: 130, speed: 150, start: 'bash', basic: 'atk_sword', basicRange: 90, basicDps: 18.8, ranged: false },
  archer: { re: /archer|arquero/i, hp: 95, speed: 165, start: 'double_strafe', basic: 'atk_bow', basicRange: 770, basicDps: 17.3, ranged: true },
  mage: { re: /mage|mago|wizard/i, hp: 80, speed: 145, start: 'firebolt', basic: 'atk_rod', basicRange: 728, basicDps: 14.1, ranged: true },
  // Acolyte (Priest path): job table in soul_linker — hp 105, speed 150,
  // starts with Heal, casts (magic scaling), club weapon (1501).
  acolyte: { re: /acolyte|acólito|priest|sacerdote/i, hp: 105, speed: 150, start: 'heal', basic: 'atk_club', basicRange: 100, basicDps: 13, ranged: true },
};
// Lobby ("server") selection. The game's lobby picker reuses the NPC dialog:
// the lobby buttons live in #npc-text as <button data-lb="N"> with the lobby
// name, and #npc-options holds only the escape hatch "Jugar sin conexión"
// (play offline). Without an explicit pick the bot treated that dialog as an
// NPC dialog and clicked the offline button, so every run was solo.
const LOBBY_NAMES = ['Asgard', 'Midgard', 'Alfheim', 'Vanaheim', 'Jotunheim', 'Nidavellir', 'Svartalfheim', 'Niflheim', 'Muspelheim'];
const LOBBY_NAME = String(argv.lobby || 'Nidavellir');
const LOBBY_ID = (() => { const i = LOBBY_NAMES.findIndex(n => n.toLowerCase() === LOBBY_NAME.toLowerCase()); return i >= 0 ? i + 1 : 6; })();
const RUN_TAG = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
fs.mkdirSync(OUT, { recursive: true });
fs.mkdirSync(path.join(OUT, 'screenshots'), { recursive: true });
const SCREENSHOT_DIR = path.join(OUT, 'screenshots');
const MAX_DIAGNOSTIC_SCREENSHOTS = 40;
const MAX_DIAGNOSTIC_SCREENSHOT_BYTES = 64 * 1024 * 1024;
function pruneScreenshots() {
  const candidates = fs.readdirSync(SCREENSHOT_DIR, { withFileTypes: true })
    .filter(entry => entry.isFile() && /^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-r.+\.png$/.test(entry.name))
    .map(entry => {
      try {
        const file = path.join(SCREENSHOT_DIR, entry.name);
        const stat = fs.statSync(file);
        return { name: entry.name, file, modified: stat.mtimeMs, size: stat.size };
      } catch { return null; }
    })
    .filter(Boolean);
  let removed = 0;
  for (const name of screenshotsToDelete(candidates, MAX_DIAGNOSTIC_SCREENSHOTS, MAX_DIAGNOSTIC_SCREENSHOT_BYTES)) {
    try { fs.unlinkSync(path.join(SCREENSHOT_DIR, name)); removed++; } catch {}
  }
  return removed;
}
const logFile = path.join(OUT, `runs-${RUN_TAG}.jsonl`);
const logStream = fs.createWriteStream(logFile, { flags: 'a' });
function log(ev) { const rec = { t: new Date().toISOString(), ...ev }; logStream.write(JSON.stringify(rec) + '\n'); console.log(`[${rec.t.slice(11, 19)}]`, ev.msg || JSON.stringify(ev)); }
const prunedScreenshots = pruneScreenshots();
if (prunedScreenshots) log({ msg: `screenshot retention removed ${prunedScreenshots} old diagnostic images; keeping at most ${MAX_DIAGNOSTIC_SCREENSHOTS} / ${Math.round(MAX_DIAGNOSTIC_SCREENSHOT_BYTES / 1024 / 1024)} MiB` });
const sleep = ms => new Promise(r => setTimeout(r, ms));

// --- auto re-patch on bundle-hash change. The patch tool (rea/patch.py)
// downloads the live bundle, discovers the game's anchors by pattern, injects
// the read-only snapshot hooks and writes patched/bundle.json. The bot reads
// that manifest afterwards.
//
// If the game renamed its internals so badly that the anchors cannot be
// found, patching fails but the FARM KEEPS RUNNING on the plain live bundle:
// a missing inventory panel must never stop the bots.
const { execSync } = require('child_process');
const PATCH_SCRIPT = path.join(__dirname, '..', 'rea', 'patch.py');

function readPatchManifest() {
  try { return JSON.parse(fs.readFileSync(PATCHED_MANIFEST, 'utf8')); } catch { return {}; }
}
function runPatchTool() {
  try {
    execSync(`python3 ${PATCH_SCRIPT}`, { timeout: 300000, stdio: 'pipe' });
  } catch (e) {
    log({ msg: `patch tool failed: ${String(e && e.stderr || e).slice(0, 300)}` });
  }
}
function ensurePatched() {
  const root = path.join(__dirname, '..');
  let manifest = readPatchManifest();
  // The manifest is only trusted if the patched file is really there.
  let ok = manifest && manifest.ok && manifest.name
    && fs.existsSync(path.join(root, 'rea', 'patched', manifest.name));
  if (!ok) {
    log({ msg: 'no usable patched bundle — running the patch tool' });
    runPatchTool();
    manifest = readPatchManifest();
    ok = manifest && manifest.ok && manifest.name
      && fs.existsSync(path.join(root, 'rea', 'patched', manifest.name));
  }
  if (ok) {
    PATCHED = path.join(root, 'rea', 'patched', manifest.name);
    log({ msg: `patched bundle ready: ${manifest.name} (sha ${String(manifest.patchedSha || '').slice(0, 12)})` });
  } else {
    PATCHED = null;
    log({ msg: `patch unavailable (${manifest && manifest.reason || 'unknown'}) — running the plain live bundle, the farm still works` });
  }
  return PATCHED;
}
ensurePatched();

// --- local CONNECT relay (same reason as v1 bot.js: Chromium cannot
// authenticate to this VM's egress proxy directly; curl/Node can). The relay
// re-issues CONNECT with the env credentials; credentials stay in memory.
// LOCAL-PACKAGE NOTE: the relay is only needed behind an egress proxy
// (this VM). On a normal PC with no https_proxy set, skip it and let
// Chromium connect directly — otherwise the browser gets pointed at
// a dead proxy and nothing loads.
const NEED_PROXY = !!(process.env.https_proxy || process.env.HTTPS_PROXY);
const relay = NEED_PROXY ? spawn('node', [path.join(__dirname, '..', 'rea', 'relay.js')], { env: { ...process.env, RELAY_PORT: '18080' }, stdio: 'ignore' }) : null;

// --- build planner (v4, DPS-per-level from soul_linker tables, Tp=1.5).
// DPS priors are L1 single-target DPS estimates (live dmgBy in the
// snapshot measures the real thing per run; see report). AoE skills get
// an `aoe` multiplier = how many targets they typically hit at once.
//   Swordsman: bash cd.9 dmg ~300/Tp=200 -> ~222 DPS single (observed
//     v3: much lower in practice - melee uptime is the tax); magnum cd4
//     AoE r~144 knock 260; sword_dance cd9 r185 3 ticks.
//   Archer: double_strafe cd.9, 2 arrows x 56/1.5=37.3 -> 83 DPS, +20%/lvl;
//     arrow_shower cd3.2, 22 dmg x 2 volleys, 60deg cone range 300, knock 90;
//     blitz_beat cd6 multi 3 hits; beast_strafing cd5 projectile;
//     phantasmic_arrow cd9 pierce projectile.
//   Mage: firebolt cd1.3, 19 dmg, 1 bolt +1 per level-ish (count grows),
//     range 420; soul_strike cd1.7, 10.35 dmg, count 1+, burst 2+;
//     sight cd8-uptime orbit flames r88 dmg 12.65 hitCd .6, count lvl+1;
//     frost_nova cd12 AoE freeze 60% 2s; meteor_storm cd14 AoE;
//     fire_pillar cd9 AoE ground; jupitel_thunder cd6 projectile;
//     earth_spike cd6 multi; storm_gust cd16 AoE freeze; lord_of_vermilion
//     cd18 AoE ground; energy_coat -6% dmg taken/rank (survive).
// Phase plan: early damage+area -> upgrades to owned -> crit/ASPD/CD ->
// survivability FORCED when a boss is due within 40s or HP<50% (v3 died
// to the t~150 boss with no survival picks). After t=600 (boss phase)
// single-target DPS is worth 1.5x (Mastering 52k HP must die in the
// 720-900 window: ~290 DPS needed). Discovery late-game only.
const SKILL_PLAN = [
  // Swordsman
  { id: 'bash', job: 'swordsman', names: [/bash/i], dps: 120, aoe: 1, role: 'single', phase: 'early', prio: 1 },
  { id: 'magnum', job: 'swordsman', names: [/magnum/i], dps: 45, aoe: 6, role: 'aoe', phase: 'early', prio: 1, note: 'AoE+knockback 260' },
  { id: 'sword_dance', job: 'swordsman', names: [/sword dance|danza de espadas/i], dps: 40, aoe: 8, role: 'aoe', phase: 'early', prio: 2, note: 'AoE 3 ticks r185' },
  { id: 'demoralizing_shout', job: 'swordsman', names: [/demoralizing|desmoral/i], dps: 10, aoe: 3, role: 'debuff', phase: 'mid', prio: 4, note: 'weaken -dmg' },
  { id: 'provoke', job: 'swordsman', names: [/provoke|provoca/i], dps: 0, aoe: 3, role: 'debuff', phase: 'mid', prio: 5, note: 'mark +dmg taken' },
  { id: 'endure', job: 'swordsman', names: [/endure|aguant/i], dps: 0, aoe: 0, role: 'survive', phase: 'late', prio: 6, note: 'dmg reduction' },
  { id: 'hp_recovery', job: 'swordsman', names: [/hp recovery|recuperaci/i], dps: 0, aoe: 0, role: 'survive', phase: 'late', prio: 7, note: 'regen' },
  { id: 'shield_bash', job: 'swordsman', names: [/shield bash|golpe de escudo/i], dps: 0, aoe: 0, role: 'never', phase: 'never', prio: 9, note: 'needs shield' },
  // Archer
  { id: 'double_strafe', job: 'archer', names: [/double strafe|doble/i], dps: 83, aoe: 1, role: 'single', phase: 'early', prio: 1, note: '83 DPS L1, +20%/lvl' },
  { id: 'arrow_shower', job: 'archer', names: [/arrow shower|lluvia de flechas|shower/i], dps: 14, aoe: 6, role: 'aoe', phase: 'early', prio: 2, note: 'cone 60deg r300, 2 volleys' },
  { id: 'blitz_beat', job: 'archer', names: [/blitz beat/i], dps: 30, aoe: 2, role: 'single', phase: 'early', prio: 3, note: 'falcon 3 hits' },
  { id: 'beast_strafing', job: 'archer', names: [/beast strafing|strafing/i], dps: 25, aoe: 1, role: 'single', phase: 'mid', prio: 4, note: 'projectile cd5' },
  { id: 'phantasmic_arrow', job: 'archer', names: [/phantasmic/i], dps: 20, aoe: 3, role: 'aoe', phase: 'mid', prio: 5, note: 'pierce projectile cd9' },
  { id: 'fire_arrow', job: 'archer', names: [/fire arrow/i], dps: 25, aoe: 4, role: 'aoe', phase: 'early', prio: 3, note: 'AoE lobbed arrow, bursts on hit (seen live)' },
  { id: 'arcane_shot', job: 'archer', names: [/arcane shot/i], dps: 30, aoe: 1, role: 'single', phase: 'mid', prio: 4, note: 'single-target shot (seen live)' },
  { id: 'arrow_repel', job: 'archer', names: [/arrow repel/i], dps: 15, aoe: 3, role: 'aoe', phase: 'mid', prio: 5, note: 'reactive repel, fired live' },
  { id: 'retreat', job: 'archer', names: [/retreat/i], dps: 0, aoe: 0, role: 'survive', phase: 'mid', prio: 6, note: 'leap back + damage on landing (seen live)' },
  // Mage
  { id: 'firebolt', job: 'mage', names: [/fire ?bolt|fire ?ball|bola de fuego/i], dps: 15, aoe: 1, role: 'single', phase: 'early', prio: 1, note: '15 DPS/bolt, +bolts/lvl' },
  { id: 'soul_strike', job: 'mage', names: [/soul strike/i], dps: 12, aoe: 1, role: 'single', phase: 'early', prio: 2, note: 'count grows, burst 2+' },
  { id: 'sight', job: 'mage', names: [/sight/i], dps: 20, aoe: 2, role: 'orbit', phase: 'early', prio: 3, note: 'orbit flames r88' },
  { id: 'meteor_storm', job: 'mage', names: [/meteor storm|meteor/i], dps: 30, aoe: 6, role: 'aoe', phase: 'early', prio: 2, note: 'AoE ground cd14' },
  { id: 'fire_pillar', job: 'mage', names: [/fire pillar|pilar de fuego/i], dps: 25, aoe: 4, role: 'aoe', phase: 'early', prio: 3, note: 'AoE ground cd9' },
  { id: 'jupitel_thunder', job: 'mage', names: [/jupitel/i], dps: 20, aoe: 1, role: 'single', phase: 'mid', prio: 4, note: 'projectile cd6' },
  { id: 'earth_spike', job: 'mage', names: [/earth spike/i], dps: 20, aoe: 2, role: 'multi', phase: 'mid', prio: 4, note: 'multi cd6' },
  { id: 'frost_nova', job: 'mage', names: [/frost nova/i], dps: 10, aoe: 4, role: 'control', phase: 'mid', prio: 5, note: 'freeze 60% 2s' },
  { id: 'storm_gust', job: 'mage', names: [/storm gust/i], dps: 15, aoe: 4, role: 'control', phase: 'mid', prio: 6, note: 'AoE freeze' },
  { id: 'lord_of_vermilion', job: 'mage', names: [/lord of vermilion|vermilion/i], dps: 30, aoe: 6, role: 'aoe', phase: 'late', prio: 3, note: 'AoE ground cd18' },
  { id: 'energy_coat', job: 'mage', names: [/energy coat/i], dps: 0, aoe: 0, role: 'survive', phase: 'late', prio: 6, note: '-6% dmg taken/rank' },
  { id: 'increase_sp_recovery', job: 'mage', names: [/increase sp recovery|sp recovery/i], dps: 0, aoe: 0, role: 'haste', phase: 'mid', prio: 6, note: '+6% haste/rank' },
];
const WIZARD_BANNED = [/napalm/i, /fire ?wall/i, /soul ?strike/i, /frost ?diver/i, /sight/i];
const WIZARD_ARMOR = /armor|armour|defen|shield|plate|mail|guard|resist|coat|robe|vest|helmet|boots|vit|hp|health|barrier/i;
const WIZARD_POWER = /damage|atk|attack|power|might|crit|pierc|sharp|element|magic|str/i;
const WIZARD_SKILL_TIERS = [
  { name: 'firebolt', patterns: [/fire ?bolt|bola de fuego/i] },
  { name: 'thunderstorm', patterns: [/thunder ?storm/i] },
  { name: 'lightning', patterns: [/lightning/i] },
  { name: 'cold', patterns: [/cold/i] },
  { name: 'armor', patterns: [WIZARD_ARMOR] },
  { name: 'power', patterns: [WIZARD_POWER] },
];
const WIZARD_ITEM_TIERS = [
  { name: 'bulwark', patterns: [/bulwark/i] },
  { name: 'armor', patterns: [WIZARD_ARMOR] },
  { name: 'power', patterns: [WIZARD_POWER] },
];
// ---- User builds (--builds=<file>) ----
// File format: { "<job>": { "cards": ["name", ...], "items": ["name", ...] } }
// Order in each list = pick priority (first = best). Matching is by substring
// against the pick's text, lowercased. Listed picks outrank all builtin rules;
// unlisted picks are scored by the normal planner. Lists boost, never ban.
let USER_BUILDS = null;
try {
  if (argv.builds) {
    const raw = JSON.parse(fs.readFileSync(String(argv.builds), 'utf8'));
    const out = {};
    for (const [job, b] of Object.entries(raw)) {
      if (!b || typeof b !== 'object') continue;
      out[String(job).toLowerCase()] = {
        cards: Array.isArray(b.cards) ? b.cards.map(s => String(s).toLowerCase()).filter(Boolean) : [],
        items: Array.isArray(b.items) ? b.items.map(s => String(s).toLowerCase()).filter(Boolean) : [],
      };
    }
    USER_BUILDS = Object.keys(out).length ? out : null;
    if (USER_BUILDS) console.error('builds: loaded user builds for ' + Object.keys(USER_BUILDS).join(', '));
  }
} catch (e) {
  console.error('builds: failed to load --builds: ' + (e && e.message));
}
function userTierIndex(text, ctx) {
  if (!USER_BUILDS) return null;
  const b = USER_BUILDS[String(ctx.job || '').toLowerCase()];
  if (!b) return null;
  const list = ctx.pickType === 'item' ? b.items : b.cards;
  if (!list || !list.length) return null;
  const s = String(text || '').toLowerCase();
  for (let i = 0; i < list.length; i++) if (list[i] && s.includes(list[i])) return i;
  return null;
}
function wizardScoreCard(text, ctx) {
  // User build (--builds): a listed entry outranks every builtin rule, in the
  // order the user gave. Unlisted picks are scored exactly as before — the
  // lists boost, they never ban.
  const name = String(text || '').slice(0, 80);
  const userTier = userTierIndex(name, ctx);
  if (userTier != null) return { score: 1000000 - userTier * 10000, hits: [`user-build:${ctx.pickType === 'item' ? 'item' : 'card'}#${userTier + 1}`], plan: null, isNew: false };
  if (ctx.pickType === 'skill' && WIZARD_BANNED.some(re => re.test(name))) {
    return { score: -1000000, hits: ['user-banned'], plan: null, isNew: false };
  }
  const tiers = ctx.pickType === 'skill' ? WIZARD_SKILL_TIERS : WIZARD_ITEM_TIERS;
  if (/fire\s*bolt\s+deity|deity.{0,20}fire\s*bolt|deidad.{0,24}bola de fuego/i.test(name)) {
    return { score: 1000000, hits: ['user-required:firebolt-deity'], plan: null, isNew: false };
  }
  const tier = tiers.findIndex(t => t.patterns.some(re => re.test(name)));
  if (tier >= 0) return { score: 10000 - tier * 1000, hits: [`user-priority:${tiers[tier].name}`], plan: null, isNew: false };
  return { score: Math.random() * 100, hits: ['user-priority:random'], plan: null, isNew: false };
}

function objectivesFound(observedNames, objectives) {
  const names = observedNames.map(name => String(name || '').toLowerCase());
  return objectives.every(objective => {
    const target = String(objective || '').trim().toLowerCase();
    return !!target && names.some(name => name.includes(target));
  });
}
function mergeFoundObjectives(previous, observedNames, objectives) {
  const found = new Set([...previous].map(objective => String(objective).toLowerCase()));
  for (const objective of objectives) {
    if (objectivesFound(observedNames, [objective])) found.add(String(objective).trim().toLowerCase());
  }
  return found;
}
function allObjectivesObtained(found, objectives) {
  return objectives.length > 0 && objectives.every(objective => found.has(String(objective).trim().toLowerCase()));
}
function screenshotsToDelete(entries, maxFiles, maxBytes) {
  const newestFirst = [...entries].sort((a, b) => b.modified - a.modified);
  const remove = [];
  let kept = 0, bytes = 0;
  for (const entry of newestFirst) {
    if (kept >= maxFiles || bytes + entry.size > maxBytes) remove.push(entry.name);
    else { kept++; bytes += entry.size; }
  }
  return remove;
}

const SCORE_RULES = [
  [/damage|daño|dmg/i, 250, 'damage'], [/flee|huida|esquiva|evasion/i, 220, 'flee'],
  [/crit|crít/i, 150, 'crit'], [/attack speed|velocidad de ataque|aspd/i, 140, 'attack speed'],
  [/cooldown|enfriamiento|recarga/i, 130, 'cooldown'], [/move ?speed|velocidad de movimiento|movement speed/i, 120, 'move speed'],
  [/area|área|radius|radio/i, 100, 'area'], [/projectile|proyectil|extra hit|golpe extra|multishot/i, 110, 'projectiles'],
  [/max hp|hp máx|vida máx|\+ ?\d+ hp/i, 120, 'max hp'], [/armor|armadura|defense|defensa|def\b/i, 90, 'defense'],
  [/discovery|descubrimiento/i, 80, 'discovery (late-game only)'], [/exp|experiencia/i, 60, 'exp'],
  [/zeny/i, 40, 'zeny'], [/luck|suerte/i, 50, 'luck'], [/regen|regener/i, 110, 'regen'], [/lifesteal|robo de vida/i, 100, 'lifesteal'],
];
function planEntryFor(text, job) {
  // Match against the NAME portion only (first 80 chars: "N Skill NEW!
  // <Name> <Type> ..."). Matching the full text misfires on description
  // words — live: "Fire Arrow ... bursts like a fireball" matched the
  // Mage firebolt pattern. The name is where the skill identity lives.
  const t = (text || '').slice(0, 80);
  if (/shield bash|golpe de escudo/i.test(t)) return SKILL_PLAN.find(p => p.id === 'shield_bash');
  // This job's pool first, then any pool (a card for another job's skill
  // should not normally appear, but never let it score as unknown).
  for (const p of SKILL_PLAN) if (p.job === job && p.names.some(re => re.test(t))) return p;
  for (const p of SKILL_PLAN) if (p.names.some(re => re.test(t))) return p;
  return null;
}
// v4 scoring: DPS-per-level math, not vibes. ctx carries liveEnemies,
// bossDueIn (seconds to the next boss in the live map script),
// bossActive, elapsedS (game seconds), hpFrac, level, ownedSkills,
// slotsFree, job. AoE value scales with how many enemies are actually
// alive; single-target value scales up in the boss phase (t>=600) when
// Mastering (52k HP) has to die in the 720-900 window; survival value
// spikes when a boss is due or HP is low — the exact failure v3 died to.
// v6 scoring: phase-aware, final-boss build (Araso point 4). The planner
// thinks like an AI that knows the endgame: every pick is judged by "does
// this help kill Mastering at t=720-900 while staying alive?"
// Phase weights (full table + reasons in beast-v6-report.md §pick table):
//   t<150   — thin the pack: AoE x1.3, sustain x0.8 (nothing can kill you
//              yet except density; damage is king).
//   150-600 — build the boss killer: single x1.1, sustain x1.2.
//   t>=600  — final-boss build: single x2.0, sustain x2.0, AoE x0.5,
//              Discovery x0.25 (too late to matter), zeny x0.5.
//   Mastering active — single x2.5, sustain x2.5, AoE x0.3, Discovery 0.
// Survival is FORCED when a boss is due within 40s or HP<50% (v3's death),
// and sustain gets +150 flat when Mastering is due within 60s.
function scoreCard(text, ctx) {
  if (ctx.job === 'mage' && ctx.pickType) return wizardScoreCard(text, ctx);
  const t = (text || '').toLowerCase(); let score = 0; const hits = [];
  // User build (--builds): a listed entry outranks every builtin rule, in the
  // order the user gave. Unlisted picks are scored exactly as before.
  const userTier = userTierIndex(text, ctx);
  if (userTier != null) return { score: 1000000 - userTier * 10000, hits: [`user-build:${ctx.pickType === 'item' ? 'item' : 'card'}#${userTier + 1}`], plan: null, isNew: false };
  const isNew = /new!|nuevo|new skill|nueva habilidad|new weapon|nueva arma|desbloquea/i.test(t);
  const plan = planEntryFor(text, ctx.job);
  const owned = plan && ctx.ownedSkills && ctx.ownedSkills.some(s => String(s).toLowerCase().includes(plan.id.replace('_', '')) || String(s).toLowerCase() === plan.id);
  for (const [re, w, note] of SCORE_RULES) {
    // v5: a debuff/control card's description says the ENEMY "deals less
    // damage" — that is not our damage. Without this guard Demoralizing
    // Shout outscores Bash at Lv 2 on the word "damage" alone (smoke run).
    if (note === 'damage' && plan && (plan.role === 'debuff' || plan.role === 'control')) continue;
    if (re.test(t)) { score += w; hits.push(note); }
  }
  const live = ctx.liveEnemies || 0;
  const bossDue = ctx.bossDueIn != null && ctx.bossDueIn <= 40;
  const bossPhase = (ctx.elapsedS || 0) >= 600 || !!ctx.masteringActive;
  const masteringDue = ctx.timeToMastering != null && ctx.timeToMastering <= 60;
  let singleMul = 1, aoeMul = 1, sustainMul = 1, discMul = 1, zenyMul = 1;
  if ((ctx.elapsedS || 0) < 150) { aoeMul = 1.3; sustainMul = 0.8; }
  else if ((ctx.elapsedS || 0) < 600) { singleMul = 1.1; sustainMul = 1.2; }
  else { singleMul = 2.0; aoeMul = 0.5; sustainMul = 2.0; discMul = 0.25; zenyMul = 0.5; }
  if (ctx.masteringActive) { singleMul = 2.5; sustainMul = 2.5; aoeMul = 0.3; discMul = 0; zenyMul = 0.5; }
  if (plan) {
    hits.push('plan:' + plan.id);
    if (plan.role === 'never') { score = Math.min(score, 30); hits.push('needs-shield-deprioritised'); }
    else if (plan.role === 'survive') {
      score += Math.round(130 * sustainMul); hits.push('survive-base');
      if (bossDue || ctx.bossActive) { score *= 2.5; hits.push('boss-due-survive-x2.5'); }
      else if (ctx.hpFrac < 0.5) { score *= 2; hits.push('lowhp-survive-x2'); }
      else if (ctx.level >= 6) score += 60;
      if (masteringDue) { score += 150; hits.push('mastering-due-sustain+150'); }
    } else if (plan.role === 'debuff' || plan.role === 'control') {
      score += Math.round((100 + Math.min(60, live * 2)) * (bossPhase ? 1.2 : 1)); hits.push('debuff-control');
      if (bossDue || ctx.bossActive) { score += 60; hits.push('boss-debuff'); }
    } else if (plan.role === 'haste') { score += Math.round(140 * (bossPhase ? 1.5 : 1)); hits.push('haste'); }
    else {
      // Damage skills: DPS x targets-hit x phase factors.
      const targets = (plan.role === 'aoe' || plan.role === 'multi' || plan.role === 'orbit')
        ? Math.min(plan.aoe || 1, Math.max(1, live / 3))
        : 1; // v5: AoE value up — every extra kill is its exp in gems
      let effDps = plan.dps * targets;
      if (plan.role === 'single') { effDps *= singleMul; hits.push('single-x' + singleMul); }
      else { effDps *= aoeMul; if (aoeMul !== 1) hits.push('aoe-x' + aoeMul); }
      if ((bossDue || ctx.bossActive) && plan.role !== 'single') { effDps *= 0.85; hits.push('boss-due-aoe-x0.85'); }
      score += Math.round(effDps * 2); hits.push('dps:' + Math.round(effDps));
    }
    if (isNew && plan.role !== 'never') {
      const slotsFree = ctx.slotsFree == null ? true : ctx.slotsFree > 0;
      // After t=600, do NOT open new AoE slots — the final boss is a
      // single-target fight; a new AoE skill is a wasted pick.
      if (bossPhase && plan.role === 'aoe') { score -= 100; hits.push('boss-phase-no-new-aoe'); }
      else { score += slotsFree ? Math.max(60, 340 - plan.prio * 30) : -200; hits.push(slotsFree ? 'new-skill-bonus' : 'slots-full'); }
    } else if (owned && plan.role !== 'never') { score += 240; hits.push('upgrade-owned'); }
    if (plan.phase === 'late' && ctx.level < 5 && plan.role !== 'survive') score -= 60;
    if (plan.phase === 'early' && ctx.level >= 8 && plan.role === 'aoe') score -= 20;
  } else if (isNew) { score += 120; hits.push('new-skill-generic'); }
  const isMeat = /meat|carne/.test(t) && /50|recupera|heal|curar/.test(t);
  if (isMeat) {
    if (ctx.hpFrac < 0.35) score = 1000;
    else if (bossDue && ctx.hpFrac < 0.75) score = 600;
    else score = ctx.hpFrac < 0.6 ? 400 : 5;
    hits.push('meat');
  }
  // v6 LOOT: same sources as v5, but Discovery's value collapses late —
  // a quality re-weight only pays off over MANY future rolls, and after
  // t=600 there are few rolls left that matter for the Mastering kill.
  const lootEarly = (ctx.level || 1) < 8 || (ctx.elapsedS || 0) < 300;
  const isDiscSrc = /surprise|sorpresa|plenty|abundancia|avarice|avaricia|wisdom|sabidur/i.test(t) && /discovery|descubrimiento/.test(t);
  const isZenySrc = /greed|avaricia|plenty|abundancia|avarice|avaricia/.test(t) && /zeny/.test(t);
  const isPickupSrc = /pickup|recogida|recolecci/i.test(t);
  const isDeityCard = /deity|deidad/.test(t);
  if (isDiscSrc) { score += Math.round((lootEarly ? 320 : 180) * discMul); hits.push(lootEarly ? 'loot:discovery-early' : 'loot:discovery'); }
  else if (/discovery|descubrimiento/.test(t)) { score += Math.round((lootEarly ? 120 : 80) * discMul); hits.push('loot:discovery-generic'); }
  if (isZenySrc) { score += Math.round((lootEarly ? 200 : 120) * zenyMul); hits.push('loot:zeny-buys-chests'); }
  if (isPickupSrc) { score += 220; hits.push('loot:pickup-radius'); }
  if (isDeityCard) { score += 80; hits.push('loot:deity-chest-only'); }
  if (/area|área/.test(t) && plan && (plan.role === 'aoe' || plan.role === 'orbit')) { score += 60; hits.push('loot:aoe-more-kills-more-gems'); }
  if (/legendario|legendary/.test(t)) score *= 1.6; else if (/épico|epic/.test(t)) score *= 1.35; else if (/raro|rare/.test(t)) score *= 1.15;
  return { score: Math.round(score), hits, plan: plan ? plan.id : null, isNew: !!isNew };
}
// --- exact-state perception
async function readState(page) {
  // The game snapshot contains large/cyclic metadata. Never JSON-clone it:
  // project only the fields consumed by steering and run accounting in-page.
  return page.evaluate(() => {
    if (typeof window.__RO_SNAPSHOT__ !== 'function') return null;
    try {
      const raw = window.__RO_SNAPSHOT__();
      if (!raw || typeof raw !== 'object') return null;
      const pick = (obj, keys) => {
        if (!obj || typeof obj !== 'object') return null;
        const out = {};
        for (const k of keys) {
          const v = obj[k];
          if (v == null || ['string', 'number', 'boolean'].includes(typeof v)) out[k] = v;
        }
        return out;
      };
      const rows = (value, keys) => Array.isArray(value) ? value.map(v => pick(v, keys)).filter(Boolean) : [];
      // Item names and icons come from the game's own item table, which the
      // patched bundle exposes as __RO_ITEM__ (available once the character
      // has been in the plaza).
      const itemInfo = (id) => {
        try {
          const it = (typeof window.__RO_ITEM__ === 'function') ? window.__RO_ITEM__(id) : null;
          return it ? { name: it.name || null, icon: it.icon || null, slot: it.slot || null } : { name: null, icon: null, slot: null };
        } catch { return { name: null, icon: null, slot: null }; }
      };
      const named = (value, keys) => Array.isArray(value)
        ? value.map(v => { const p = pick(v, keys); if (!p) return null; return { ...p, ...itemInfo(p.id) }; }).filter(Boolean)
        : [];
      const count = value => Array.isArray(value) ? { length: value.length } : { length: 0 };
      const summary = value => {
        if (!value || typeof value !== 'object') return value;
        if (Array.isArray(value)) return value.slice(0, 12).map(v => typeof v === 'object' ? pick(v, ['id', 'name', 'key', 'value']) : v);
        return Object.fromEntries(Object.entries(value).slice(0, 24).map(([k, v]) => [k, typeof v === 'object' ? null : v]));
      };
      const out = pick(raw, [
        'ok', 'state', 'stage', 'time', 'timeUp', 'closeAt', 'lootUntil', 'finalBossDefeated', 'bossSchedule',
        'hp', 'maxHp', 'level', 'exp', 'expNext', 'kills', 'zeny', 'nextHordeAt', 'nextEliteAt',
        'chestsOpened', 'mobLoot', 'mvpsKilled', 'bossKills',
      ]) || {};
      out.bossSchedule = Array.isArray(raw.bossSchedule)
        ? raw.bossSchedule.map(b => pick(b, ['id', 't'])).filter(Boolean)
        : [];
      out.finalBossDefeated = raw.finalBossDefeated ?? (() => {
        const R = window.__RO__;
        if (!R || !R.script || !Array.isArray(R.script.bosses)) return false;
        const live = [...(R.bosses || []), ...(R.enemies || []).filter(e => e && !e.dead && e.def && e.def.boss)];
        return R.nextBoss >= R.script.bosses.length && !live.some(b => !b.dead);
      })();
      out.mvpsKilled = summary(raw.mvpsKilled);
      out.player = pick(raw.player, ['x', 'y', 'dead', 'moving']);
      out.bounds = pick(raw.bounds, ['x0', 'y0', 'x1', 'y1']);
      out.stats = pick(raw.stats, ['speedMult']);
      out.enemies = rows(raw.enemies, ['id', 'x', 'y', 'boss', 'elite', 'damage', 'hp', 'maxHp', 'dead']);
      out.pickups = rows(raw.pickups, ['x', 'y', 'kind', 'value', 'quality']);
      out.bosses = rows(raw.bosses, ['id', 'hp', 'maxHp']);
      // Some game builds expose a live boss in `enemies` but leave `bosses`
      // empty. Fold those flagged enemies in so end detection cannot declare
      // victory while the final boss is still on the field.
      for (const boss of (out.enemies || []).filter(e => e && e.boss && !out.bosses.some(b => b.id === e.id))) out.bosses.push(boss);
      out.bossBrains = Array.isArray(raw.bossBrains) ? raw.bossBrains.map(b => ({
        ...pick(b, ['boss', 'maxHp', 'busyUntil', 'phase', 'gcd']),
        skills: rows(b.skills, ['name', 'cd', 'range']),
        ready: Array.isArray(b.ready) ? b.ready.slice(0, 24) : [],
        skillReadyAt: Array.isArray(b.skillReadyAt) ? b.skillReadyAt.slice(0, 24) : [],
      })) : [];
      out.projectiles = rows(raw.projectiles, ['x', 'y', 'vx', 'vy']);
      out.fireRings = rows(raw.fireRings, ['x', 'y', 'r']);
      out.slots = summary(raw.slots) || [];
      out.weapons = summary(raw.weapons) || [];
      out.passives = summary(raw.passives) || [];
      out.runLoot = named(raw.runLoot, ['id', 'quality', 'ilvl', 'tier']);
      out.runCards = named(raw.runCards, ['id', 'quality', 'ilvl', 'tier']);
      out.runEggs = named(raw.runEggs, ['id', 'quality']);
      // Equipment the character is wearing (ids + names) — the game's own
      // look object keeps it during a run.
      out.equip = raw.equip && typeof raw.equip === 'object'
        ? Object.fromEntries(Object.entries(raw.equip).filter(([, v]) => v != null).map(([k, v]) => [k, { id: v, ...itemInfo(v) }]))
        : null;
      out.dmgBy = summary(raw.dmgBy);
      out.killsBy = summary(raw.killsBy);
      return out;
    } catch (e) { return { ok: false, error: String(e) }; }
  }).catch(e => ({ ok: false, error: String(e) }));
}
async function readHud(page) {
  return page.evaluate(() => {
    const txt = s => { const el = document.querySelector(s); return el ? el.textContent.trim() : null; };
    // NOTE: offsetParent is null for position:fixed elements, which most
    // game overlays are — judge visibility by class + computed style.
    const vis = s => { const el = document.querySelector(s); if (!el || el.classList.contains('hidden')) return false; const cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden'; };
    const cards = [...document.querySelectorAll('#pk-cards .pk-card')].map(el => ({ text: el.textContent.replace(/\s+/g, ' ').trim(), disabled: el.disabled }));
    const perkBtns = [...document.querySelectorAll('#picker button, #pk-perks button, .pk-perk')].map(el => ({ text: (el.textContent || '').replace(/\s+/g, ' ').trim(), disabled: !!el.disabled }));
    const pickerSub = txt('#pk-sub');
    const sockets = txt('#lu-sockets');
    const pickType = /skill|habilidad/i.test([txt('#pk-title'), pickerSub, sockets].filter(Boolean).join(' '))
      ? 'skill' : 'item';
    return { pickerOpen: vis('#picker'), pickerTitle: txt('#pk-title'), pickerSub, pickType, pickerTimer: txt('#pk-timer'), perkBtns, cards,
      gameOver: vis('#gameover'), gameOverTitle: txt('#go-title'), gameOverStats: txt('#go-stats'),
      paused: vis('#pause'), npcDialog: vis('#npc-dialog'), story: vis('#story'),
      stagesOpen: vis('#stages'), charSelect: vis('#charselect'), hudVisible: vis('#hud') };
  }).catch(e => ({ error: String(e) }));
}

// --- steering v4: anti-encirclement FIRST, kite-at-max-range for ranged.
// Spawn math (bundle yU): 1.2/s (maxAlive 40) -> 7/s (maxAlive 260); v3
// died at 63-69 live. v4 modes, in priority order:
//  boss: any boss alive. Ranged jobs hold a 710-760px ring: every damaging
//    boss skill in the bundle has range <=650 (summons reach 700 but deal
//    no direct damage), so beyond 700 the boss CANNOT cast — it only
//    chases at speed 80-115 while the player runs 145-165. Strafe
//    tangentially, keep firing (bow 770 / rod 728 range). Melee keeps the
//    v3 300px ring. Adds within 150px are fled from radially. During the
//    boss's busyUntil (casting/recovery) hold the ring and burn.
//  emergency: live>=55 OR nearest<25px OR (HP<35% AND nearest<200).
//    path-aware 16-direction escape, held 4s — escape EARLY, v3 only fled
//    once already surrounded and its centroid-away escape ran into the
//    pack in every direction.
//  thin: live>=40. Flow mode: keep a heading, turn only to avoid dense
//    cones; bias to the nearest map edge so spawns funnel to one side.
//  kite (ranged default): hold 350-550px from the nearest enemy; approach
//    if nearest>700 (basic-attack range), back off if <200; snake in
//    straight runs (orbit flips every 8s) so the pack trails in a line
//    for cone/AoE skills. Basic attacks auto-fire the whole time.
//  engage (melee default): v3 band 55-95px, predictive intercept.
// Telegraph dodging always on: fireRings / fxAnchors / projectiles
// (closest-approach test), weight x1.5 in boss mode.
const SWORD_MIN = 55, SWORD_MAX = 95, SWARM_N = 4, SWARM_R = 260, FLEE_HP = 0.35;
const THIN_N = 40, EMERG_N = 55, EMERG_NEAR = 25, BOSS_RING = 730, BOSS_RING_MIN = 705, BOSS_RING_MAX = 760;
// v6.2 pre-boss thinning. The schedule comes from the live map script; the
// fallback is only for an unpatched/older bundle. Window: start thinning this
// many game-seconds before each boss spawns.
// Goal at spawn: live < THIN_LIVE AND nearest non-boss enemy > THIN_NEAR px.
const PRETHIN_WINDOW = 40, THIN_LIVE = 40, THIN_NEAR = 100;
const BOSS_MAX_SKILL_RANGE = 700; // all damaging boss skills <=650px; summons 700 (lives here so the unit-test slice has it — gapDir uses it)
const SPAWN_FARM_RADIUS = 500;
const VALUABLE_LOOT_RADIUS = 1500; // reach valuable drops well outside the farm radius
// At max-loot enemy speed, 1.5s was not enough to cross a newly spawned
// wave. Hold the chosen safe heading long enough to actually leave it.
const ESCAPE_HOLD_MS = 4000;
const HORDE_PREP_WINDOW = 18;
function mapBossTimes(s) {
  const live = Array.isArray(s && s.bossSchedule)
    ? s.bossSchedule.map(b => Number(b && b.t)).filter(t => Number.isFinite(t) && t >= 0).sort((a, b) => a - b)
    : [];
  return live.length ? live : FALLBACK_BOSS_TIMES;
}
function nextBossTime(s, now) {
  return mapBossTimes(s).find(t => t > now) ?? null;
}
function isValuablePickup(p) {
  if (!p) return false;
  if (p.kind === 'magnet' || p.kind === 'loot' || p.kind === 'card' || p.kind === 'egg') return true;
  if (p.kind === 'chest') return true;
  const q = Number(p.quality || 0);
  return Number.isFinite(q) && q >= 3; // purple/epic+ quality
}
function valuablePickupTarget(s, px, py) {
  if (!s || !Array.isArray(s.pickups)) return null;
  let best = null, bestScore = -Infinity;
  for (const p of s.pickups) {
    if (!isValuablePickup(p)) continue;
    const d = Math.hypot(p.x - px, p.y - py);
    if (d > VALUABLE_LOOT_RADIUS) continue;
    // Prefer magnet first, then close/rare drops.
    const mag = p.kind === 'magnet' ? 5000 : 0;
    const q = Number(p.quality || 0);
    const score = mag + (Number.isFinite(q) ? q * 120 : 0) - d;
    if (score > bestScore) { bestScore = score; best = { p, d }; }
  }
  return best;
}
function applySpawnLeash(s, v) {
  // Never replace a combat escape with a loot or center leash. The old order
  // let this function overwrite an emergency vector after steer() had already
  // found a safe gap, which made the bot walk back into the pack.
  if (v && ['emergency', 'horde-prep', 'breakout', 'prethin', 'rescue', 'boss', 'mastering', 'horde-avoid'].includes(v.mode)) return v;
  const b = s.bounds;
  if (!b) return v;
  const px = s.player.x, py = s.player.y;
  const hx = (b.x0 + b.x1) / 2, hy = (b.y0 + b.y1) / 2;
  const dx = hx - px, dy = hy - py;
  const distCenter = Math.hypot(dx, dy);
  if (distCenter <= SPAWN_FARM_RADIUS) return v;
  // The final boss can end the run without exposing a lootUntil timer.
  // Keep the exception bounded to the game's final-boss signal.
  if (v.mode === 'loot-sweep' && victorySweepActive(s)) return v;
  // Valuable loot (magnet / purple / card / egg) is worth a short detour even
  // outside the farm radius, but only when the path there is not a horde.
  const vt = valuablePickupTarget(s, px, py);
  if (vt) {
    const vdx = vt.p.x - px, vdy = vt.p.y - py, vd = Math.hypot(vdx, vdy) || 1;
    const here = hordeThreatAt(s, px, py);
    const there = hordeThreatAt(s, vt.p.x, vt.p.y);
    const route = pathThreat(s, px, py, vdx / vd, vdy / vd);
    const hp = s.maxHp ? s.hp : (s.hp || 1);
    const projectedLoss = Math.max(there.dmg, route.maxDmg) * Math.min(3, vd / 140); // rough HP cost to reach it
    const tooDangerous = here.n >= 12 || there.n >= 12 || route.maxN >= 12 || (hp > 0 && projectedLoss > hp * 0.25);
    if (!tooDangerous) return { ...v, dx: vdx / vd, dy: vdy / vd, mode: 'loot-detour' };
  }
  const d = distCenter || 1;
  return { ...v, dx: dx / d, dy: dy / d, mode: 'spawn-leash' };
}

// Keyboard movement is collision-resolved one frame at a time. A cardinal key
// can therefore keep the player pressed against a wall forever even though a
// safe direction exists around the corner. For escape modes, ask the running
// game for a real walkable route and steer toward its next waypoint instead of
// blindly holding the first geometric gap heading.
async function mapAwareVector(page, s, v) {
  const routeModes = new Set(['emergency', 'horde-prep', 'breakout', 'prethin', 'rescue', 'horde-avoid', 'spawn-leash']);
  if (!page || !s || !s.player || !v || !routeModes.has(v.mode)) return v;
  if (!Number.isFinite(v.dx) || !Number.isFinite(v.dy) || Math.hypot(v.dx, v.dy) < 0.05) return v;
  const distance = v.mode === 'rescue' ? 420 : 640;
  const route = await page.evaluate(({ vector, distance, bounds }) => {
    try {
      const R = window.__RO__;
      const walk = R && R.walk;
      if (!walk || typeof walk.pathTo !== 'function') return null;
      const x = Number(R.player && R.player.x);
      const y = Number(R.player && R.player.y);
      if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
      const b = bounds && Number.isFinite(bounds.x0) && Number.isFinite(bounds.x1) && Number.isFinite(bounds.y0) && Number.isFinite(bounds.y1)
        ? bounds : null;
      const clamp = (value, lo, hi) => Math.max(lo, Math.min(hi, value));
      let tx = x + vector.dx * distance;
      let ty = y + vector.dy * distance;
      if (b) {
        tx = clamp(tx, b.x0 + 32, b.x1 - 32);
        ty = clamp(ty, b.y0 + 32, b.y1 - 32);
      }
      if (typeof walk.nearestWalkable === 'function') [tx, ty] = walk.nearestWalkable(tx, ty);
      let path = walk.pathTo(x, y, tx, ty);
      // `resolve` is the game's own one-step collision rule. If a target is
      // valid only on one axis, use that resolved point as a final fallback;
      // the normal path still comes from pathTo and remains map-aware.
      if (!path && typeof walk.resolve === 'function') {
        const resolved = walk.resolve(x, y, tx, ty);
        if (Array.isArray(resolved) && resolved.length >= 2) path = walk.pathTo(x, y, resolved[0], resolved[1]);
      }
      return {
        x, y,
        path: Array.isArray(path) ? path.slice(0, 8).map(point => ({ x: Number(point.x), y: Number(point.y) })) : null,
      };
    } catch { return null; }
  }, { vector: { dx: v.dx, dy: v.dy }, distance, bounds: s.bounds }).catch(() => null);
  if (!route || !Array.isArray(route.path)) return { ...v, walkRouted: false, walkRouteMiss: true };
  const waypoint = routeVectorFromPath(route.path, route.x, route.y);
  if (!waypoint) return { ...v, walkRouted: false, walkRouteMiss: true };
  return { ...v, dx: waypoint.dx, dy: waypoint.dy, walkRouted: true, walkWaypoint: waypoint.waypoint };
}

function victorySweepActive(s) {
  return !!s && (s.lootUntil > s.time || (s.finalBossDefeated && s.state !== 'over'));
}
function activeBosses(s) {
  const seen = new Set();
  const out = [];
  for (const boss of [...((s && s.bosses) || []), ...(((s && s.enemies) || []).filter(e => e && e.boss))]) {
    if (!boss || boss.dead) continue;
    const id = boss.id || `${boss.x}:${boss.y}:${boss.hp}`;
    if (seen.has(id)) continue;
    seen.add(id);
    out.push(boss);
  }
  return out;
}
function isLiveRunState(s) {
  return !!(s && s.ok && ['playing', 'levelup'].includes(s.state));
}
function nearestVictoryPickup(s, px, py) {
  if (!victorySweepActive(s) || !Array.isArray(s.pickups)) return null;
  let nearest = null, nearestD = Infinity, magnet = null, magnetD = Infinity;
  for (const p of s.pickups) {
    const d = Math.hypot(p.x - px, p.y - py);
    if (p.kind === 'magnet' && d < magnetD) { magnet = p; magnetD = d; }
    if (d < nearestD) { nearest = p; nearestD = d; }
  }
  const best = magnet || nearest;
  return best ? { x: best.x, y: best.y, kind: best.kind, quality: best.quality ?? null, d: magnet ? magnetD : nearestD } : null;
}
// --- v6 helpers: meat-rescue survivability + perfect-dodge layer ---
// Meat scale: the player sprite is ~115 world units tall ≈ 1.75 m, so
// 1 m ≈ 65 world units and Araso's "20 metres" ≈ 1300 units.
const MEAT_RESCUE_RANGE = 1300; // ≈20 m
function meatRescueOK(s, px, py, meat) {
  // Can the bot reach this meat WITHOUT dying on the way (i.e. HP must
  // not hit 0 before arrival)? Estimates time-to-reach at swordsman
  // speed (150 u/s x speedMult, 0.85 for dodging detours) and the damage
  // it will take en route: ~1 contact hit/s per enemy within 180px, plus
  // one budgeted graze if a boss skill is about to fire.
  const d = Math.hypot(meat.x - px, meat.y - py);
  const speed = 150 * ((s.stats && s.stats.speedMult) || 1);
  const tReach = d / (speed * 0.85);
  let incoming = 0;
  for (const e of s.enemies) {
    const ed = Math.hypot(e.x - px, e.y - py);
    if (ed < 180) incoming += (e.damage || 4);
  }
  const bossE = s.enemies.find(e => e.boss);
  if (bossE) {
    const bd = Math.hypot(bossE.x - px, bossE.y - py);
    const bb = s.bossBrains ? s.bossBrains.find(b => b.boss === bossE.id) : null;
    if (bb && bd < 650 && bb.ready && bb.ready.length && Math.min(...bb.ready) < 2) incoming += 25 / Math.max(tReach, 0.5);
  }
  const projected = s.hp - incoming * tReach;
  const floor = Math.max(20, 0.12 * s.maxHp);
  return { ok: projected > floor, tReach: +tReach.toFixed(1), projected: Math.round(projected), floor, incoming: Math.round(incoming) };
}
// --- v6.2 CORRECTION (Araso): the killer is not only the pack — boss
// skills OVERLAP. The old dodge summed one radial shove per hazard, so
// dodging one cast stepped straight into another cast's AoE, took huge
// damage, and repeated it. The dodge now considers ALL live danger zones
// AT ONCE (their union) and steers to a spot safe from ALL of them. If
// no fully-safe spot exists, it picks the spot with the fewest overlapping
// zones, then the thinnest pack, then the closest to the boss band — and
// never stands still inside a zone.
// DANGER-ZONE TRUTH (verified in the bundle 2026-11-11): fireRings are
// the real ground AoEs. fxAnchors are NOT telegraphs — placeOverlay()
// gives EVERY fx an anchor by default, so the list is damage numbers
// (which follow enemies via live getters), arrow/projectile visuals,
// skill particles and decorative map fires. v6 treated them as a soft
// push (mostly harmless); v6.2 first promoted them to hard zones and the
// smoke run proved that wrong — the bot hard-dodged damage numbers every
// tick instead of fighting (998/998 hard, died t=127 pre-Eclipse).
// Anchors are therefore EXCLUDED from the danger set entirely.
function zonesAtPoint(x, y, zones) {
  let n = 0, w = 0; const kinds = [];
  for (const z of zones) {
    const d = Math.hypot(x - z.x, y - z.y);
    if (d < z.r) { n++; w += z.w; if (!kinds.includes(z.kind)) kinds.push(z.kind); }
  }
  return { n, w, kinds };
}
function sampleSafeDir(s, px, py, zones, imminent, bossE) {
  // 16 directions x 3 distances + staying put. Score: overlapping zones
  // (x10, radius counted with a +30 keep-out margin) first, pack density
  // at the point (x2 per enemy within 60px), then boss-band penalty
  // (running away from the boss is the v6.0 failure), then travel
  // distance as a tiebreak (nearest safe spot wins). When a cast is
  // imminent, radial movement toward/away from the boss is penalised —
  // the dodge must stay a SIDESTEP (gap-close doctrine), not a retreat.
  const cands = [{ x: px, y: py, dist: 0 }];
  for (let k = 0; k < 16; k++) {
    const a = k * Math.PI * 2 / 16, ux = Math.cos(a), uy = Math.sin(a);
    for (const dist of [120, 220, 340]) cands.push({ x: px + ux * dist, y: py + uy * dist, dist });
  }
  let best = null;
  for (const c of cands) {
    let z = 0;
    for (const zn of zones) { const d = Math.hypot(c.x - zn.x, c.y - zn.y); if (d < zn.r + 30) z += zn.w; }
    if (imminent.length) { const d = Math.hypot(c.x - px, c.y - py); if (d < 130) z += 2; } // blast lands where we stand
    for (const pr of s.projectiles || []) {
      const pvx = pr.vx || 0, pvy = pr.vy || 0, ps = Math.hypot(pvx, pvy);
      if (!ps) continue;
      const rx = c.x - pr.x, ry = c.y - pr.y;
      const tca = Math.max(0, -(rx * pvx + ry * pvy) / (ps * ps));
      const cd = Math.hypot(c.x - (pr.x + pvx * tca), c.y - (pr.y + pvy * tca));
      if (cd < 45 && tca < 1.2) z += 2;
    }
    let pack = 0;
    for (const e of s.enemies) { if (Math.hypot(e.x - c.x, e.y - c.y) < 60) pack++; }
    let bossPen = 0, radialPen = 0;
    if (bossE) {
      const bd = Math.hypot(c.x - bossE.x, c.y - bossE.y);
      bossPen = bd > 150 ? (bd - 150) / 150 : (bd < 40 ? 0.5 : 0);
      if (imminent.length) {
        // Sidestep, not retreat: penalise movement along the boss axis.
        const bdx = px - bossE.x, bdy = py - bossE.y, bdd = Math.hypot(bdx, bdy) || 1;
        const mx = c.x - px, my = c.y - py, md = Math.hypot(mx, my) || 1;
        radialPen = Math.abs((mx / md) * (bdx / bdd) + (my / md) * (bdy / bdd)) * 5;
      }
    }
    const score = z * 10 + pack * 2 + bossPen + radialPen + c.dist * 0.001;
    if (!best || score < best.score) best = { x: c.x, y: c.y, dist: c.dist, score, zones: z, pack };
  }
  return best;
}
function dodgeVector(s, px, py, bossE, bossBrain, mastering, st) {
  // PERFECT-DODGE layer (Araso points 2+3), v6.2 union version. Every boss
  // skill is telegraphed before it lands: bossBrain ready[] countdowns say
  // a skill is about to fire, fireRings are the ground AoE, fxAnchors are
  // cast anchors, projectiles fly at us. This returns an escape vector;
  // `hard` means a cast is about to land on our current spot (or we stand
  // inside a live AoE) and the dodge must override everything else.
  // Skill-window logic: a skill whose ready countdown just hit ~0 is about
  // to fire — hard-dodge for up to 1.5 game-s. If it still has not fired
  // after that (gcd-gated), downgrade to a soft drift so the bot does not
  // run away forever from a skill that never comes.
  let dx = 0, dy = 0, hard = false; const reasons = [];
  // ALL live danger zones at once — their union is what kills us.
  // fireRings ONLY: fxAnchors are every visual effect's position
  // (damage numbers, arrows, map fires) — not telegraphs, see above.
  const zones = [];
  for (const r of s.fireRings || []) zones.push({ x: r.x, y: r.y, r: r.r + 20, w: 3, kind: 'ring' });
  // Imminent boss casts: the skill lands where we stand, so it is a blast
  // disc on our spot. Soft precast drift is accumulated separately.
  const imminent = [];
  let driftX = 0, driftY = 0;
  if (bossE && bossBrain && bossBrain.ready) {
    const bdx = px - bossE.x, bdy = py - bossE.y, bd = Math.hypot(bdx, bdy) || 1;
    const trk = st || null;
    if (trk && !trk.skillReadyAt) trk.skillReadyAt = {};
    (bossBrain.skills || []).forEach((sk, i) => {
      const rdy = bossBrain.ready[i];
      if (rdy == null) return;
      if (rdy > 2) { if (trk) delete trk.skillReadyAt[i]; return; } // skill on cooldown, window closed
      if (rdy <= 0.7 && bd <= sk.range + 80) {
        if (trk && trk.skillReadyAt[i] == null) trk.skillReadyAt[i] = s.time;
        const sinceReady = trk && trk.skillReadyAt[i] != null ? s.time - trk.skillReadyAt[i] : 0;
        if (sinceReady <= 1.5) { imminent.push({ name: sk.name, range: sk.range }); reasons.push('cast:' + sk.name); }
        else if (bd > 150) { driftX += (bdx / bd) * 0.8; driftY += (bdy / bd) * 0.8; reasons.push('precast:' + sk.name); }
      } else if (rdy <= 1.5 && bd <= sk.range * 0.6 && bd > 150) {
        driftX += (bdx / bd) * 0.8; driftY += (bdy / bd) * 0.8; reasons.push('precast:' + sk.name);
      }
      // Casts-exposed accounting (report metric: how many boss skills the
      // bot stood inside the range of as they came ready).
      if (trk) {
        const prev = trk.prevReady || [];
        if (prev[i] != null && prev[i] > 0.5 && rdy <= 0.5 && bd <= ((sk && sk.range) || 650) + 80) trk.castsExposed = (trk.castsExposed || 0) + 1;
      }
    });
    if (trk) trk.prevReady = bossBrain.ready.slice();
  }
  // Projectile danger at our current spot (closest-approach test).
  let projDanger = false;
  for (const pr of s.projectiles || []) {
    const rx = px - pr.x, ry = py - pr.y, pvx = pr.vx || 0, pvy = pr.vy || 0, ps = Math.hypot(pvx, pvy);
    if (!ps) continue;
    const tca = Math.max(0, -(rx * pvx + ry * pvy) / (ps * ps));
    const cxp = pr.x + pvx * tca, cyp = pr.y + pvy * tca, cd = Math.hypot(px - cxp, py - cyp);
    if (cd < 45 && tca < 1.2) { projDanger = true; reasons.push('proj'); }
  }
  const here = zonesAtPoint(px, py, zones);
  for (const k of here.kinds) if (!reasons.includes(k)) reasons.push(k);
  const nearZone = zones.some(z => Math.hypot(px - z.x, py - z.y) < z.r + 90);
  if (here.n > 0 || imminent.length > 0 || projDanger || nearZone) {
    // Multi-AoE avoidance: steer to the best sampled spot, safe from ALL
    // zones at once — never dodge one cast into another. Ground-truth AoE
    // is the fireRing; the old per-cast radial shoves are gone (v6.0
    // showed they strand the bot 540px out doing 2 DPS).
    const best = sampleSafeDir(s, px, py, zones, imminent, bossE);
    const bx = best.x - px, by = best.y - py, bd = Math.hypot(bx, by);
    if (bd > 5) { dx = bx / bd; dy = by / bd; } else { dx = driftX; dy = driftY; }
    hard = here.n > 0 || imminent.length > 0 || projDanger;
    if (best.zones === 0 && here.n > 0) reasons.push('union:safe');
  } else {
    dx = driftX; dy = driftY; hard = false;
  }
  return { dx, dy, hard, reasons };
}
// Engage-band on a single enemy: hold 55-95px, always moving, sword
// auto-swings while we strafe (point-1 kite macro). Shared by the
// plain engage branch (inline there, kept) and the boss branch.
function engageBand(px, py, e, d, nNear, cx, cy, nSwarm, dir) {
  const sp = e.speed || 60;
  const ex = e.x + ((px - e.x) / (d || 1)) * sp * 0.3;
  const ey = e.y + ((py - e.y) / (d || 1)) * sp * 0.3;
  const ax = ex - px, ay = ey - py, ad = Math.hypot(ax, ay) || 1;
  let vx = 0, vy = 0;
  if (d > 100) { vx = ax / ad; vy = ay / ad; }
  else if (d < SWORD_MIN) { vx = -ax / ad * 0.7 + (-ay / ad) * 0.8; vy = -ay / ad * 0.7 + (ax / ad) * 0.8; }
  else { vx = (-ay / ad) * dir; vy = (ax / ad) * dir; }
  if (nNear >= 2 && d <= 130 && nSwarm > 0) {
    const gx = cx / nSwarm - px, gy = cy / nSwarm - py, gd = Math.hypot(gx, gy) || 1;
    vx += (gx / gd) * 0.35; vy += (gy / gd) * 0.35;
  }
  return { vx, vy };
}
function heldGapDir(s, px, py, bossE, st) {
  const now = Date.now();
  if (st && st.escapeDir && now < st.escapeUntil) return st.escapeDir;
  const g = gapDir(s, px, py, 16, bossE);
  if (st) {
    st.escapeDir = { dx: g.dx, dy: g.dy };
    st.escapeUntil = now + ESCAPE_HOLD_MS;
  }
  return g;
}
function steer(s, st) {
  const px = s.player.x, py = s.player.y;
  const ranged = !!(st && st.ranged);
  let vx = 0, vy = 0, nearest = Infinity, nearestE = null, nearestBoss = Infinity, nearestBossE = null, nNear = 0;
  let nearestElite = Infinity, nearestEliteE = null;
  // v6.2: nearest NON-BOSS enemy — the boss itself sits in the sword band
  // at 55-95px by design and must NOT trigger thinning/break-out.
  let nearestAdd = Infinity, nearestAddE = null;
  let cx = 0, cy = 0, nSwarm = 0;
  for (const e of s.enemies) {
    const dx = px - e.x, dy = py - e.y, d = Math.hypot(dx, dy) || 1;
    if (d < nearest) { nearest = d; nearestE = e; }
    if (e.boss && d < nearestBoss) { nearestBoss = d; nearestBossE = e; }
    if (!e.boss && d < nearestAdd) { nearestAdd = d; nearestAddE = e; }
    if (e.elite && !e.boss && d < nearestElite) { nearestElite = d; nearestEliteE = e; }
    if (d < SWARM_R) { nNear++; cx += e.x; cy += e.y; nSwarm++; }
  }
  const hpFrac = s.maxHp ? s.hp / s.maxHp : 1;
  const live = s.enemies.length;
  const bossActive = !!nearestBossE;
  const bossBrain = bossActive && s.bossBrains ? s.bossBrains.find(bb => bb.boss === nearestBossE.id) : null;
  const bossBusy = bossBrain && bossBrain.busyUntil > s.time;
  const mastering = !!(nearestBossE && /mastering/i.test(nearestBossE.id || ''));
  const victoryPickup = nearestVictoryPickup(s, px, py);
  // Nearest meat on the floor (point 1 rules below).
  let nearestMeat = null, nearestMeatD = Infinity;
  for (const p of s.pickups || []) {
    if (p.kind !== 'meat') continue;
    const d = Math.hypot(p.x - px, p.y - py);
    if (d < nearestMeatD) { nearestMeatD = d; nearestMeat = p; }
  }
  // --- DODGE LAYER (points 2+3): computed FIRST, wins over the mode
  // vector; a hard dodge overrides it outright.
  const dg = dodgeVector(s, px, py, nearestBossE, bossBrain, mastering, st);
  if (dg.reasons.length && st) { st.dodges = (st.dodges || 0) + 1; if (dg.hard) st.hardDodges = (st.hardDodges || 0) + 1; }
  // --- MEAT RESCUE (point 1 exception): HP < 50% AND meat within ~20 m
  // that the bot can reach WITHOUT dying on the way. Overrides the fight.
  let rescue = null, rescueDenied = null;
  if (hpFrac < 0.5 && nearestMeat && nearestMeatD <= MEAT_RESCUE_RANGE) {
    const chk = meatRescueOK(s, px, py, nearestMeat);
    if (chk.ok) { rescue = { meat: nearestMeat, d: nearestMeatD, ...chk }; if (st) st.rescuesAttempted = (st.rescuesAttempted || 0) + 1; }
    else { rescueDenied = { d: Math.round(nearestMeatD), ...chk }; if (st) st.rescueDenied = (st.rescueDenied || 0) + 1; }
  }
  // --- v6.2 PRE-BOSS THINNING STATE: the pack is what kills us (v6
  // deaths: nearest 6-21px, live 66-70 at boss fights). Before each boss
  // spawns, force live < 40 AND nearest non-boss enemy > 100px, then hold
  // that spacing. During a boss fight, if the pack re-thickens, BREAK OUT.
  const nextBossT = nextBossTime(s, s.time);
  const timeToBoss = nextBossT != null ? nextBossT - s.time : null;
  const preBossWindow = timeToBoss != null && timeToBoss <= PRETHIN_WINDOW;
  const timeToHorde = Number.isFinite(Number(s.nextHordeAt)) && Number(s.nextHordeAt) > s.time
    ? Number(s.nextHordeAt) - s.time
    : null;
  const hordeWindow = timeToHorde != null && timeToHorde <= HORDE_PREP_WINDOW;
  const thickPack = live > THIN_LIVE && nearestAdd < THIN_NEAR;
  const thinReady = live < THIN_LIVE && nearestAdd >= THIN_NEAR;
  // v6.2 breakout hysteresis (run 1: 19 breakouts in 26s — the mode
  // flapped every tick because exiting at nearestAdd > 100 re-entered
  // the boss dive instantly). Once in breakout, STAY in it until
  // spacing is really re-established (nearest add > 130px).
  if (st && st.inBreakout && nearestAdd > 130) st.inBreakout = false;
  if (bossActive && thickPack && st) st.inBreakout = true;
  // --- MODE SELECTION (point 1: killing is ALWAYS first — loot never
  // overrides the fight; rescue overrides everything but a hard dodge).
  let mode = ranged ? 'kite' : 'engage';
  if (rescue && !dg.hard) mode = 'rescue';
  else if (bossActive && (thickPack || (st && st.inBreakout))) mode = 'breakout'; // v6.2: pack re-thickened mid-fight — get OUT first
  else if (bossActive) mode = mastering ? 'mastering' : 'boss';
  // Survival outranks the pre-boss thinning plan. A max-loot wave can turn
  // prethin into a death march if we wait for the pack to become thin.
  else if (live >= EMERG_N || nearest < EMERG_NEAR || (ranged && nearest < 150) || (hpFrac < FLEE_HP && nearest < 200)) mode = 'emergency';
  else if (hordeWindow && !victoryPickup) mode = 'horde-prep';
  else if (preBossWindow && !victoryPickup && (live >= THIN_LIVE || nearestAdd < THIN_NEAR)) mode = 'prethin'; // v6.2
  else if (victoryPickup && !dg.hard) mode = 'loot-sweep';
  else if (live >= THIN_N) mode = 'thin';
  if (mode === 'rescue' && rescue) {
    const mdx = rescue.meat.x - px, mdy = rescue.meat.y - py, md = Math.hypot(mdx, mdy) || 1;
    vx = (mdx / md) * 1.6; vy = (mdy / md) * 1.6;
  } else if (mode === 'emergency') {
    const g = heldGapDir(s, px, py, nearestBossE, st);
    vx = g.dx * 1.6; vy = g.dy * 1.6;
  } else if (mode === 'horde-prep') {
    // The game tells us when the next wave will be scheduled. Leave loot mode
    // before it fires so the player is already moving through open space.
    const g = heldGapDir(s, px, py, nearestBossE, st);
    vx = g.dx * 1.3; vy = g.dy * 1.3;
  } else if (mode === 'breakout') {
    // v6.2 BREAK-OUT: the pack re-thickened around us mid-boss-fight
    // (live > 40, nearest add < 100px) — exactly how v6 died (nearest
    // 6-21px, HP -9/s). Do NOT engage adds inside the pack; escape along
    // the emptiest direction (boss-aware: gapDir penalises running into
    // boss skill range) and hold it 4s, then re-engage the boss from
    // spacing. Skills still auto-fire while we move.
    const g = heldGapDir(s, px, py, nearestBossE, st);
    vx = g.dx * 1.6; vy = g.dy * 1.6;
  } else if (mode === 'prethin') {
    // v6.2 PRE-BOSS THINNING: burn the pack down before the boss spawns.
    // BURIED fix (run 1: the t~120 horde spawns ~55 enemies at once and
    // the bot orbits INSIDE the pack — engageBand strafes tangentially
    // and the centroid-outward drift vanishes when surrounded, because
    // the centroid IS the player). When buried (nearest add < 50px) or
    // swamped (live >= 55), ESCAPE with gapDir first (emptiest direction),
    // then thin from spacing. Otherwise kill in the sword band with an
    // outward drift; once thin but too close, back off to 100-150px;
    // once ready (live < 40, nearest add > 100): slow orbit, hold spacing.
    const dir = (st && st.orbitDir) || 1;
    if ((nearestAdd < 50 || live >= EMERG_N) && nearestAddE) {
      const g = heldGapDir(s, px, py, nearestBossE, st);
      vx = g.dx * 1.6; vy = g.dy * 1.6;
    } else if (live >= THIN_LIVE && nearestAddE) {
      const eb = engageBand(px, py, nearestAddE, nearestAdd, nNear, cx, cy, nSwarm, dir);
      vx = eb.vx; vy = eb.vy;
      if (nSwarm > 0) { const gx = px - cx / nSwarm, gy = py - cy / nSwarm, gd = Math.hypot(gx, gy) || 1; vx += (gx / gd) * 0.6; vy += (gy / gd) * 0.6; }
    } else if (nearestAdd < THIN_NEAR && nearestAddE) {
      const ax = nearestAddE.x - px, ay = nearestAddE.y - py, ad = Math.hypot(ax, ay) || 1;
      vx = (-ax / ad) * 1.2 + (-ay / ad) * dir * 0.6; vy = (-ay / ad) * 1.2 + (ax / ad) * dir * 0.6;
    } else {
      const a = (s.time * 0.5) % (Math.PI * 2);
      vx = Math.cos(a) * 0.6; vy = Math.sin(a) * 0.6;
    }
  } else if (mode === 'loot-sweep' && victoryPickup) {
    const dx = victoryPickup.x - px, dy = victoryPickup.y - py, d = Math.hypot(dx, dy) || 1;
    vx = dx / d; vy = dy / d;
  } else if (mode === 'thin') {
    // Flow: keep current heading, only turn away from dense cones; bias
    // to the nearest map edge so the pack funnels to one side.
    const g = gapDir(s, px, py, 8, nearestBossE);
    vx = g.dx; vy = g.dy;
    const b = s.bounds;
    if (b) {
      const dEdge = Math.min(px - b.x0, b.x1 - px, py - b.y0, b.y1 - py);
      if (dEdge < 600) {
        const nx = (px - b.x0 < b.x1 - px) ? 1 : (b.x1 - px < px - b.x0 ? -1 : 0);
        const ny = (py - b.y0 < b.y1 - py) ? 1 : (b.y1 - py < py - b.y0 ? -1 : 0);
        if (nx !== 0 && Math.abs(px - (nx > 0 ? b.x0 : b.x1)) <= Math.abs(py - (ny > 0 ? b.y0 : b.y1))) { vx = vx - nx * (vx * nx); vy = vy * 1.2; }
        else if (ny !== 0) { vy = vy - ny * (vy * ny); vx = vx * 1.2; }
      }
    }
  } else if (mode === 'mastering' && nearestBossE) {
    // FINAL BOSS (point 3): no mobs, likely no meat — survival is the
    // build (see scoreCard). The fight is dodge-everything + gap-close:
    // every dodge is a sidestep that ends back in sword range, and the
    // post-cast recovery window is spent diving back in, not running.
    const dx = px - nearestBossE.x, dy = py - nearestBossE.y, d = Math.hypot(dx, dy) || 1;
    const dir = (st && st.orbitDir) || 1;
    if (bossBusy) {
      // Post-cast recovery = the gap-close window: dive straight in.
      if (d > 100) { vx = (-dx / d) * 1.5; vy = (-dy / d) * 1.5; }
      else { vx = (-dy / d) * dir; vy = (dx / d) * dir; }
    } else if (hpFrac < 0.35) {
      // Too hurt to trade: back off to 250-350, farm the boss's spawned
      // adds for gems/level-ups (level-ups heal), re-engage at >=50%.
      if (d < 250) { vx = (dx / d) * 1.4; vy = (dy / d) * 1.4; }
      else if (d > 350) { vx = (-dx / d) * 0.8; vy = (-dy / d) * 0.8; }
      else { vx = (-dy / d) * dir; vy = (dx / d) * dir; }
      if (nearestE && !nearestE.boss && nearest < 150) {
        const ax = nearestE.x - px, ay = nearestE.y - py, ad = Math.hypot(ax, ay) || 1;
        if (nearest > 95) { vx += (-ax / ad) * 0.8; vy += (-ay / ad) * 0.8; }
      }
    } else {
      // Hold the sword band on the boss, strafing; pull toward mobs
      // clustered on the boss so the sword hits both.
      if (d > SWORD_MAX) { vx = (-dx / d) * 1.5 + (-dy / d) * dir * 0.6; vy = (-dy / d) * 1.5 + (dx / d) * dir * 0.6; }
      else if (d < SWORD_MIN) { vx = (dx / d) * 0.7 + (-dy / d) * dir; vy = (dy / d) * 0.7 + (dx / d) * dir; }
      else { vx = (-dy / d) * dir; vy = (dx / d) * dir; }
      let tx = nearestBossE.x, ty = nearestBossE.y, tn = 1;
      for (const e of s.enemies) {
        if (!e.boss && Math.hypot(e.x - nearestBossE.x, e.y - nearestBossE.y) < 200) { tx += e.x; ty += e.y; tn++; }
      }
      const cdx = tx / tn - px, cdy = ty / tn - py, cd = Math.hypot(cdx, cdy) || 1;
      if (cd > 95) { vx += (cdx / cd) * 0.35; vy += (cdy / cd) * 0.35; }
    }
  } else if (mode === 'boss' && nearestBossE) {
    // MINIBOSS (point 2): close-quarters kite — sword band on the boss
    // AND the mobs clustered on it, same macro as the mobs, while the
    // dodge layer above keeps every skill off us.
    // v6.1 (live run 1: bot sat 540px from Eclipse, 96 boss dmg in
    // ~50s, 100 adds chewing it): KILLING IS FIRST even in a boss
    // fight — if adds are in sword range and the boss is not, kill the
    // adds; if the pack is dense (>=55) thin it before pushing the
    // boss; the disengage still kills adds while it retreats.
    const dx = px - nearestBossE.x, dy = py - nearestBossE.y, d = Math.hypot(dx, dy) || 1;
    const dir = (st && st.orbitDir) || 1;
    const addInBand = nearestE && !nearestE.boss && nearest <= 100;
    // v6.2: the dense-pack clause (live >= 55) is GONE — a thick pack
    // during a boss fight now routes to 'breakout' before we get here.
    // Engage adds only when the boss is far and the field is thin.
    if (addInBand && d > 150) {
      const eb = engageBand(px, py, nearestE, nearest, nNear, cx, cy, nSwarm, dir);
      vx = eb.vx; vy = eb.vy;
    } else if (hpFrac < 0.5 && !rescue) {
      // Too hurt and no survivable meat: disengage to 300-400, thin the
      // adds, re-engage at >=60%. Do NOT burn HP you do not have — v5
      // died because it burned until the window closed or it died.
      // But still kill adds in range on the way out (killing first).
      if (addInBand) { const eb = engageBand(px, py, nearestE, nearest, nNear, cx, cy, nSwarm, dir); vx = eb.vx; vy = eb.vy; }
      else if (d < 300) { vx = (dx / d) * 1.5; vy = (dy / d) * 1.5; }
      else if (d > 400) { vx = (-dx / d) * 0.7; vy = (-dy / d) * 0.7; }
      else { vx = (-dy / d) * dir; vy = (dx / d) * dir; }
    } else {
      if (d > SWORD_MAX) { vx = (-dx / d) * 1.6 + (-dy / d) * dir * 0.6; vy = (-dy / d) * 1.6 + (dx / d) * dir * 0.6; }
      else if (d < SWORD_MIN) { vx = (dx / d) * 0.7 + (-dy / d) * dir; vy = (dy / d) * 0.7 + (dx / d) * dir; }
      else { vx = (-dy / d) * dir; vy = (dx / d) * dir; }
      let tx = nearestBossE.x, ty = nearestBossE.y, tn = 1;
      for (const e of s.enemies) {
        if (!e.boss && Math.hypot(e.x - nearestBossE.x, e.y - nearestBossE.y) < 200) { tx += e.x; ty += e.y; tn++; }
      }
      const cdx = tx / tn - px, cdy = ty / tn - py, cd = Math.hypot(cdx, cdy) || 1;
      if (cd > 95) { vx += (cdx / cd) * 0.35; vy += (cdy / cd) * 0.35; }
      // Post-cast recovery: close in fast (same gap-close idea, minis).
      if (bossBusy && d > 100) { vx = (-dx / d) * 1.5; vy = (-dy / d) * 1.5; }
    }
  } else if (mode === 'kite' && nearestE) {
    const dx = nearestE.x - px, dy = nearestE.y - py, d = Math.hypot(dx, dy) || 1;
    const dir = (st && st.orbitDir) || 1;
    // v4.1 spiral-out: pure tangential strafing lets chasers cut the chord
    // of the orbit and close the gap. Always keep a radial-away component
    // while the nearest enemy is inside 400px.
    const radialW = nearest < 400 ? 1.2 : (nearest < 550 ? 0.5 : 0);
    if (nearest > 700) { vx = dx / d; vy = dy / d; } // close back into bow/rod range
    else if (nearest < 200) { vx = -dx / d * 1.3 + (-dy / d) * 0.9; vy = -dy / d * 1.3 + (dx / d) * 0.9; } // back off + strafe
    else { // 200-700: strafe + spiral out; orbit flips every 12s of game time
      vx = (-dy / d) * dir + (-dx / d) * radialW; vy = (dx / d) * dir + (-dy / d) * radialW;
      if (nNear >= 2 && nearest <= 450) { const ax = cx / nSwarm - px, ay = cy / nSwarm - py, ad = Math.hypot(ax, ay) || 1; vx += (ax / ad) * 0.3; vy += (ay / ad) * 0.3; }
    }
  } else if (nearestE) {
    // Melee engage band (v3, kept — this IS the kite-macro of point 1:
    // hold 55-95px, always moving, sword auto-swings while we strafe).
    const sp = nearestE.speed || 60;
    const ex = nearestE.x + ((px - nearestE.x) / (nearest || 1)) * sp * 0.3;
    const ey = nearestE.y + ((py - nearestE.y) / (nearest || 1)) * sp * 0.3;
    const dx = ex - px, dy = ey - py, d = Math.hypot(dx, dy) || 1;
    if (nearest > 100) { vx = dx / d; vy = dy / d; }
    else if (nearest < SWORD_MIN) { vx = -dx / d * 0.7 + (-dy / d) * 0.8; vy = -dy / d * 0.7 + (dx / d) * 0.8; }
    else {
      const dir = (st && st.orbitDir) || 1;
      vx = (-dy / d) * dir; vy = (dx / d) * dir;
    }
    if (nNear >= 2 && nearest <= 130) { const ax = cx / nSwarm - px, ay = cy / nSwarm - py, ad = Math.hypot(ax, ay) || 1; vx += (ax / ad) * 0.35; vy += (ay / ad) * 0.35; }
  }
  // --- DODGE BLEND: hard dodge overrides the mode vector outright;
  // soft dodge bends it. (Telegraphs already computed above.)
  if (dg.reasons.length) {
    if (dg.hard) { vx = dg.dx; vy = dg.dy; }
    else { vx += dg.dx * 1.5; vy += dg.dy * 1.5; }
  }
  // --- v6 LOOT ROUTING (killing-first, point 1): killing is the
  // objective — loot is collected only when it does not cost a kill.
  // Gems only on the way (close + safe) or when the field is empty;
  // high-value kinds keep a modest pull in mob modes; in Mastering mode
  // nothing but meat rescue (boss DPS uptime is everything).
  // Meat routing here is ONLY the "HP down >=10%" band (0.5-0.9): below
  // 50% only the rescue path may route to meat (it checks survivability).
  // Valuable drops (magnet / purple/rare loot / card / egg) are prioritised
  // in a wider radius: if close, grab them; if farther, detour only when the
  // path is not a horde and HP loss would stay modest.
  const chestCost = n => Math.round(30 + 25 * n + 1.5 * n * n);
  const zenyNow = s.zeny || 0, chestsNow = s.chestsOpened || 0;
  let bestP = null, bestScore = -1;
  for (const p of s.pickups) {
    const dx = p.x - px, dy = p.y - py, d = Math.hypot(dx, dy) || 1;
    const valuable = isValuablePickup(p);
    let w = 0;
    if (mode === 'mastering') {
      // Boss DPS uptime matters, but a magnet/valuable drop inches away is free.
      if (valuable && d < 220) w = 2.5;
    } else if (mode === 'loot-sweep') { /* victory sweep drives via nearestVictoryPickup */ }
    else if (p.kind === 'magnet') {
      if (d < 1600) w = d < 260 ? 3.0 : 1.6; // strong pull, wide reach
    } else if (p.kind === 'loot' || p.kind === 'card' || p.kind === 'egg') {
      if (d < 1500) w = d < 220 ? 2.4 : 1.4;
    } else if (p.kind === 'chest' && d < 1400) {
      w = zenyNow >= chestCost(chestsNow) ? (d < 220 ? 2.2 : 1.2) : 0;
    } else if (p.kind === 'meat' && hpFrac <= 0.9 && hpFrac >= 0.5 && d < 700 && (nearest > 120 || nNear <= 6)) {
      w = 1.0;
    } else if (p.kind && p.kind.startsWith('gem') && d < 400 && (nearest > 200 || nNear <= 3)) {
      w = 0.4 + Math.min(0.6, (p.value || 1) / 20);
    }
    // High-quality (purple/epic+) items get extra priority/reach.
    const q = Number(p.quality || 0);
    if (Number.isFinite(q) && q >= 3 && d < 1600) w = Math.max(w, d < 260 ? 2.8 : 1.5);
    // Do not route into a horde for a far detour; close pickups are worth it.
    if (w > 0 && valuable && d > 260) {
      const there = hordeThreatAt(s, p.x, p.y);
      const pd = Math.hypot(dx, dy) || 1;
      const route = pathThreat(s, px, py, dx / pd, dy / pd);
      const projectedLoss = there.dmg * Math.min(3, d / 140);
      const hp = s.maxHp ? s.hp : (s.hp || 1);
      if (there.n >= 12 || route.maxN >= 12 || (hp > 0 && projectedLoss > hp * 0.25)) w = 0;
    }
    const score = w * (1 - d / 1600);
    if (score > bestScore) { bestScore = score; bestP = { dx, dy, d, kind: p.kind, w }; }
  }
  if (bestP && bestP.w > 0 && mode !== 'emergency' && mode !== 'horde-prep' && mode !== 'rescue' && mode !== 'prethin' && mode !== 'breakout' && (mode !== 'boss' || bestP.w >= 1.0)) {
    vx += (bestP.dx / bestP.d) * bestP.w; vy += (bestP.dy / bestP.d) * bestP.w;
  }
  // v5: elites are loot — pull toward the nearest elite when it is safe
  // (HP>50%, density below the emergency line). Not in boss fights.
  if (nearestEliteE && mode !== 'emergency' && mode !== 'boss' && mode !== 'mastering' && mode !== 'rescue' && mode !== 'prethin' && mode !== 'breakout' && hpFrac > 0.5 && live < EMERG_N && nearestElite < 600) {
    const ex = nearestEliteE.x - px, ey = nearestEliteE.y - py, ed = Math.hypot(ex, ey) || 1;
    vx += (ex / ed) * 0.5; vy += (ey / ed) * 0.5;
  }
  // Horde avoidance: don't walk back into a pack that would chew through HP.
  // If the chosen direction leads into heavy contact pressure, bend away toward
  // the safest gap (boss-aware) unless we are already dodging/rescuing hard.
  if (mode !== 'emergency' && mode !== 'horde-prep' && mode !== 'rescue' && !(dg && dg.hard)) {
    const ahead = hordeThreatAt(s, px + vx * 140, py + vy * 140);
    const hereT = hordeThreatAt(s, px, py);
    const hp = s.maxHp ? s.hp : (s.hp || 1);
    const projectedLoss = ahead.dmg * 1.8;
    const headingIntoHorde = (ahead.n >= EMERG_N || (hp > 0 && projectedLoss > hp * 0.28)) && ahead.n > hereT.n + 3;
    if (headingIntoHorde) {
      const g = gapDir(s, px, py, 16, nearestBossE);
      if (g) { vx = g.dx * 1.4; vy = g.dy * 1.4; mode = 'horde-avoid'; }
    }
  }

  // Bounds: steer back inside the map.
  const b = s.bounds;
  if (b) {
    if (px < b.x0 + 300) vx += 1.5; if (px > b.x1 - 300) vx -= 1.5;
    if (py < b.y0 + 300) vy += 1.5; if (py > b.y1 - 300) vy -= 1.5;
  }
  // Never stand still: if the field is nearly empty, drift in a slow orbit.
  const mag = Math.hypot(vx, vy);
  if (mag < 0.25) { const a = (s.time * 0.5) % (Math.PI * 2); vx = Math.cos(a) * 0.8; vy = Math.sin(a) * 0.8; }
  else { vx /= mag; vy /= mag; }
  return { dx: vx, dy: vy, nearest, nearestAdd: nearestAdd === Infinity ? null : Math.round(nearestAdd), nearestBoss, nNear, nEnemies: live, nPickups: s.pickups.length, hpFrac, mode, thinReady, timeToBoss, timeToHorde, bossId: nearestBossE ? nearestBossE.id : null, bossHp: nearestBossE ? nearestBossE.hp : null, bossMaxHp: nearestBossE ? nearestBossE.maxHp : null, bossBusy: !!bossBusy, bossBrain: bossBrain ? { phase: bossBrain.phase, gcd: bossBrain.gcd, skills: bossBrain.skills } : null, nearestElite, bestPickup: bestP ? { kind: bestP.kind, d: Math.round(bestP.d), w: bestP.w } : null, zeny: s.zeny || 0, chestsOpened: s.chestsOpened || 0,
    dodge: { reasons: dg.reasons, hard: dg.hard }, rescue: rescue ? { d: Math.round(rescue.d), tReach: rescue.tReach, projected: rescue.projected } : (rescueDenied ? { denied: true, d: rescueDenied.d, projected: rescueDenied.projected } : null), rescueKey: rescue ? rescue.meat.x + ',' + rescue.meat.y : null, castsExposed: st ? (st.castsExposed || 0) : 0, dodges: st ? (st.dodges || 0) : 0, nearestMeat: nearestMeat ? Math.round(nearestMeatD) : null, mastering };
}
// v6.2 DEATH DIAGNOSIS: attribute the HP lost in the last 8 game-seconds
// before death to skill zones vs contact damage, from the rolling buffer.
// A tick's HP loss counts as skill damage when the player stood inside a
// live AoE zone (fireRing) or a boss skill was imminent. Large drops alone
// are not enough: the max-loot mob pack can batch several contact hits into
// one large HP delta, which was previously misreported as skill damage.
function diagnoseDeath(stats) {
  const buf = stats.death.buf || [];
  if (buf.length < 2) return { verdict: 'UNKNOWN', reason: 'no buffer' };
  const first = buf[0], last = buf[buf.length - 1];
  const hpLost = Math.max(0, first.hp - last.hp);
  let skillHp = 0, contactHp = 0, otherHp = 0, maxZones = first.zones;
  const skillsNear = new Set();
  for (let i = 1; i < buf.length; i++) {
    const b = buf[i];
    maxZones = Math.max(maxZones, b.zones);
    if (b.dhp < 0) {
      if (b.zones > 0 || b.imminent.length) { skillHp += -b.dhp; for (const sk of b.imminent) skillsNear.add(sk + ' (hit)'); }
      else if (b.nearest != null && b.nearest < 80) contactHp += -b.dhp;
      else if (b.dhp <= -8) skillHp += -b.dhp;
      else otherHp += -b.dhp;
    }
    if (last.t - b.t <= 2) for (const sk of b.imminent) skillsNear.add(sk);
  }
  let verdict = 'UNKNOWN';
  if (hpLost <= 0) verdict = 'UNKNOWN';
  else if (skillHp > contactHp && skillHp >= 0.5 * hpLost) verdict = 'SKILL-OVERLAP';
  else if (contactHp > skillHp && contactHp >= 0.5 * hpLost) verdict = 'PACK-CONTACT';
  else if (skillHp > 0 && contactHp > 0) verdict = 'MIXED';
  else if (skillHp > 0) verdict = 'SKILL-OVERLAP';
  else if (contactHp > 0) verdict = 'PACK-CONTACT';
  const diag = { verdict, windowS: Math.round((last.t - first.t) * 10) / 10, hpLost, skillHp, contactHp, otherHp, maxZones, zonesAtDeath: last.zones, nearestAtDeath: last.nearest, skillsNearDeath: [...skillsNear] };
  stats.death.diag = diag;
  return diag;
}
const DIRS = [
  { keys: ['d'], name: 'E' }, { keys: ['s', 'd'], name: 'SE' }, { keys: ['s'], name: 'S' }, { keys: ['s', 'a'], name: 'SW' },
  { keys: ['a'], name: 'W' }, { keys: ['w', 'a'], name: 'NW' }, { keys: ['w'], name: 'N' }, { keys: ['w', 'd'], name: 'NE' },
];
class Mover {
  constructor(page) { this.page = page; this.held = new Set(); }
  async setVec(dx, dy) {
    if (Math.hypot(dx, dy) < 0.05) return;
    const ang = Math.atan2(dy, dx); // screen: x east, y south; DIRS[0]=E, +45deg steps clockwise
    const idx = ((Math.round(ang / (Math.PI / 4)) % 8) + 8) % 8;
    const want = new Set(DIRS[idx].keys);
    for (const k of [...this.held]) if (!want.has(k)) { await this.page.keyboard.up(k); this.held.delete(k); }
    for (const k of want) if (!this.held.has(k)) { await this.page.keyboard.down(k); this.held.add(k); }
    this.dirName = DIRS[idx].name;
  }
  async releaseAll() { for (const k of [...this.held]) { try { await this.page.keyboard.up(k); } catch {} } this.held.clear(); }
}
function parseTimer(t) { if (!t) return null; const m = String(t).match(/(\d+):(\d+)/); return m ? parseInt(m[1]) * 60 + parseInt(m[2]) : null; }
async function shot(page, name) {
  await page.screenshot({ path: path.join(SCREENSHOT_DIR, `${RUN_TAG}-${name}.png`) }).catch(() => {});
  pruneScreenshots();
}
async function captureDashboard(page) {
  const finalPath = path.join(SCREENSHOT_DIR, 'live.png');
  const tempPath = path.join(SCREENSHOT_DIR, 'live.tmp.png');
  try {
    await page.screenshot({ path: tempPath });
    fs.renameSync(tempPath, finalPath);
  } catch {}
}
async function clickVisible(page, sel, timeout = 5000) { try { await page.locator(sel).first().click({ timeout }); return true; } catch { return false; } }
// Direct DOM click (bypasses Playwright actionability, which silently no-ops
// on this game's buttons — see #btn-create / #cc-ok failures). Returns the
// button state so a dead click is visible in the log.
async function domClick(page, sel) {
  return page.evaluate(s => { const b = document.querySelector(s); if (!b) return null; const r = b.getBoundingClientRect(); const st = { disabled: b.disabled, text: (b.textContent || '').trim().slice(0, 40), visible: r.width > 0 && r.height > 0 }; b.click(); return st; }, sel).catch(() => null);
}
async function waitVisible(page, sel, timeout = 15000) { try { await page.locator(sel).first().waitFor({ state: 'visible', timeout }); return true; } catch { return false; } }

// Join the requested lobby before anything else touches #npc-dialog. Returns
// true while the picker is on screen (clicked or waiting), so the caller can
// loop instead of falling through to the NPC handler.
async function ensureLobby(page) {
  const pick = await page.evaluate(({ name, id }) => {
    const dialog = document.querySelector('#npc-dialog');
    if (!dialog || !dialog.getClientRects().length) return { open: false };
    const buttons = [...document.querySelectorAll('#npc-text [data-lb]')];
    if (!buttons.length) return { open: false };
    const label = b => (b.querySelector('b')?.textContent || b.textContent || '').trim().slice(0, 24);
    const hit = buttons.find(b => new RegExp(name, 'i').test(b.textContent || '')) ||
      buttons.find(b => Number(b.dataset.lb) === id);
    try { localStorage.setItem('ro-survivors.lobby', String(id)); } catch {}
    if (hit) hit.click();
    return {
      open: true,
      choices: buttons.map(b => `${b.dataset.lb}:${label(b)}${b.disabled ? '(full)' : ''}`),
      clicked: hit ? `${hit.dataset.lb}:${label(hit)}` : null,
    };
  }, { name: LOBBY_NAME, id: LOBBY_ID }).catch(() => ({ open: false }));
  if (!pick.open) return false;
  log({ msg: pick.clicked
    ? `lobby picker: joined ${pick.clicked} (choices ${pick.choices.join(' ')}); not taking the offline option`
    : `lobby picker: ${LOBBY_NAME} not offered (choices ${pick.choices.join(' ')}); waiting instead of going offline` });
  // The plaza header names the lobby and channel once the socket is up
  // ("Prontera Fountain Square Nidavellir · Channel 16 · 12 players"), so it is
  // the one honest signal that we are online rather than solo.
  if (pick.clicked) {
    let online = false;
    for (let attempt = 0; attempt < 24 && !online; attempt++) {
      online = await page.evaluate(name => (document.querySelector('#lobby-place')?.innerText || '').includes(name), LOBBY_NAME).catch(() => false);
      if (!online) await page.waitForTimeout(500);
    }
    log({ msg: online
      ? `online confirmed: plaza header shows ${LOBBY_NAME}`
      : `WARN: ${LOBBY_NAME} not confirmed in the plaza header yet; continuing only after the lobby calls on screen` });
  }
  await page.waitForTimeout(1500);
  return true;
}
async function enterGame(page, runNo) {
  await page.goto(SITE, { waitUntil: 'domcontentloaded', timeout: 120000 });
  await page.waitForTimeout(4000);
  let enabled = false;
  {
    const st = await waitForPlay(page, 600000, `run ${runNo}`);
    enabled = st === 'play';
  }
  log({ run: runNo, msg: enabled ? 'splash loaded, entering as guest' : 'WARN #sp-play never enabled within 600s' });
  await shot(page, `r${runNo}-splash`);
  await clickVisible(page, '#sp-play', 8000);
  await page.waitForTimeout(2500);
  await dismissAccountModal(page, 'after pressing Play');
  const acc = await page.evaluate(() => { const el = document.querySelector('#account-popup'); return el ? !el.classList.contains('hidden') : false; });
  if (acc) { log({ run: runNo, msg: 'account popup appeared, declining (guest only)' }); await clickVisible(page, '#acc-decline', 3000); await page.waitForTimeout(1500); }
  await shot(page, `r${runNo}-after-splash`);
}
async function selectCharacter(page, runNo) {
  if (!await waitVisible(page, '#charselect', 20000)) { log({ run: runNo, msg: 'WARN #charselect did not appear' }); await shot(page, `r${runNo}-no-charselect`); return false; }
  const slots = await page.evaluate(() => [...document.querySelectorAll('#slots > *')].map(el => el.textContent.replace(/\s+/g, ' ').trim().slice(0, 160)));
  log({ run: runNo, msg: `charselect slots: ${JSON.stringify(slots)}` });
  await shot(page, `r${runNo}-charselect`);
  // Only pick a slot that actually holds a character (a job name, NOT
  // "Empty slot"). Clicking an empty slot just highlights it and leaves
  // Play disabled — that was the v2 run-1/2 bug: the old fallback
  // `text.length > 3` matched "Empty slot" and Play did nothing.
  const picked = await page.evaluate((reSrc) => {
    const els = [...document.querySelectorAll('#slots > *')];
    const hit = els.find(e => new RegExp(reSrc, 'i').test(e.textContent) && !/empty slot/i.test(e.textContent)) || els.find(e => /swordsman|espadach|thief|ladr|mage|mago|archer|arquero|acolyte|acólito|merchant|mercader/i.test(e.textContent) && !/empty slot/i.test(e.textContent));
    if (hit) { hit.click(); return hit.textContent.replace(/\s+/g, ' ').trim().slice(0, 120); } return null;
  }, JOB_DEFS[JOB].re.source);
  if (picked) { log({ run: runNo, msg: `selected slot: ${picked}` }); await page.waitForTimeout(800); log({ run: runNo, msg: `btn-play click: ${JSON.stringify(await domClick(page, '#btn-play'))}` }); return true; }
  log({ run: runNo, msg: 'no character yet — opening Create (Crear) form' });
  // Direct DOM click: Playwright's click silently no-ops on this page
  // (previous run: #btn-create "clicked" but the form never opened).
  const createState = await page.evaluate(() => { const b = document.querySelector('#btn-create'); if (!b) return null; const r = b.getBoundingClientRect(); return { disabled: b.disabled, text: b.textContent.trim(), rect: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)] }; });
  log({ run: runNo, msg: `btn-create state: ${JSON.stringify(createState)}` });
  await page.evaluate(() => { const b = document.querySelector('#btn-create'); if (b) b.click(); });
  if (!await waitVisible(page, '#charcreate', 15000)) { log({ run: runNo, msg: 'WARN #charcreate did not appear after Create' }); await shot(page, `r${runNo}-charcreate-missing`); return false; }
  await page.waitForTimeout(1500); await shot(page, `r${runNo}-charcreate`);
  const created = await page.evaluate(({ r, reSrc }) => {
    const jobs = [...document.querySelectorAll('#cc-jobs > *, #cc-jobs button, #cc-jobs .job')];
    const job = jobs.find(e => new RegExp(reSrc, 'i').test(e.textContent)) || jobs[0];
    if (job) job.click();
    const name = document.querySelector('#cc-name');
    if (name) { name.value = 'Bot' + Math.random().toString(36).slice(2, 7) + r; name.dispatchEvent(new Event('input', { bubbles: true })); }
    return job ? job.textContent.replace(/\s+/g, ' ').trim().slice(0, 80) : null;
  }, { r: runNo, reSrc: JOB_DEFS[JOB].re.source });
  log({ run: runNo, msg: `create: job picked=${created}` });
  // Submit via a direct DOM click (Playwright's click silently no-ops here
  // in the earlier run — the form stayed open with no error). Creation calls
  // vk() (guest-name registration), which is slow through the proxy
  // (api/guest took ~54s in the diag), so wait up to 180s for the form to
  // close, polling #cc-error for a validation message.
  const okState = await page.evaluate(() => { const b = document.querySelector('#cc-ok'); return b ? { disabled: b.disabled, text: b.textContent.trim(), name: (document.querySelector('#cc-name') || {}).value || null } : null; });
  log({ run: runNo, msg: `create submit state: ${JSON.stringify(okState)}` });
  await page.evaluate(() => { const b = document.querySelector('#cc-ok'); if (b) b.click(); });
  let createdOk = false, nameTries = 0;
  for (let waited = 0; waited < 180000; waited += 5000) {
    const st = await page.evaluate(() => {
      const form = document.querySelector('#charcreate');
      const err = document.querySelector('#cc-error');
      return { formHidden: !form || form.classList.contains('hidden'), err: err ? err.textContent.trim() : null };
    }).catch(() => ({}));
    if (st.err) {
      log({ run: runNo, msg: `create error: ${st.err}` });
      // Name-taken is retryable: pick a fresh random name and resubmit.
      if (/taken/i.test(st.err) && nameTries < 3) {
        nameTries++;
        await page.evaluate(() => { const n = document.querySelector('#cc-name'); if (n) { n.value = 'Bot' + Math.random().toString(36).slice(2, 7) + Date.now() % 1000; n.dispatchEvent(new Event('input', { bubbles: true })); } const b = document.querySelector('#cc-ok'); if (b) b.click(); });
        log({ run: runNo, msg: `name taken — retry ${nameTries} with a fresh name` });
      } else if (!/taken/i.test(st.err)) { break; }
    }
    if (st.formHidden) { createdOk = true; log({ run: runNo, msg: `character created — form closed after ~${waited / 1000}s` }); break; }
    await page.waitForTimeout(5000);
  }
  if (!createdOk) { log({ run: runNo, msg: 'character creation did not complete within 180s (form still open)' }); await shot(page, `r${runNo}-create-stuck`); return false; }
  await page.waitForTimeout(2000);
  await shot(page, `r${runNo}-after-create`);
  // After creation we are either back at charselect with the new character
  // selected, or already in the plaza. If back at charselect, press Play.
  const stillSelect = await page.evaluate(() => { const el = document.querySelector('#charselect'); return !!el && !el.classList.contains('hidden'); }).catch(() => false);
  if (stillSelect) {
    const slots2 = await page.evaluate(() => [...document.querySelectorAll('#slots > *')].map(el => el.textContent.replace(/\s+/g, ' ').trim().slice(0, 120)));
    log({ run: runNo, msg: `after create, slots: ${JSON.stringify(slots2)}` });
    const picked2 = await page.evaluate((reSrc) => {
      const els = [...document.querySelectorAll('#slots > *')];
      const hit = els.find(e => (new RegExp(reSrc, 'i').test(e.textContent) || /^bot/i.test(e.textContent)) && !/empty slot/i.test(e.textContent));
      if (hit) { hit.click(); return hit.textContent.replace(/\s+/g, ' ').trim().slice(0, 120); } return null;
    }, JOB_DEFS[JOB].re.source);
    log({ run: runNo, msg: `after create, selected: ${picked2}` });
    await page.waitForTimeout(800); log({ run: runNo, msg: `btn-play click: ${JSON.stringify(await domClick(page, '#btn-play'))}` });
  }
  await page.waitForTimeout(1500);
  return true;
}
async function readPlaza(page) {
  return page.evaluate(() => {
    if (typeof window.__RO_PLAZA_SNAPSHOT__ === 'function') { try { return window.__RO_PLAZA_SNAPSHOT__(); } catch (e) { return { ok: false, error: String(e) }; } }
    return null;
  }).catch(e => ({ ok: false, error: String(e) }));
}

// Prontera plaza -> Prontera stage, via the Expedition Captain NPC.
// The captain is an NPC in the plaza (addNpc "captain", talk range Eu=170,
// Space/Enter talks to the nearest NPC). The bot steers the plaza player to
// him using the exact plaza snapshot (__RO_PLAZA__), then talks, then picks
// Prontera in the Expeditions window. No blind wandering.
// FIX (2026-11-10): the stages-open signal from readHud alone is unreliable —
// in smoke6 the plaza snapshot showed overlays=["stages"] while
// readHud().stagesOpen stayed false, so the bot kept re-talking to the
// captain for the full 180s instead of picking a stage. Trust EITHER signal.
async function stagesOpenNow(page) {
  const hud = await readHud(page);
  if (hud.stagesOpen) return { via: 'hud', hud };
  const pz = await readPlaza(page);
  if (pz && pz.ok && pz.overlays && pz.overlays.includes('stages')) return { via: 'plaza-overlays', hud, pz };
  return { via: null, hud, pz };
}
const STAGE_MATCH = {
  prontera: /prontera/i,
  sewer: /culvert|alcantarilla|sewer/i,
  culvert: /culvert|alcantarilla|sewer/i,
  sunken: /sunken|hundido/i,
  byalan: /byalan/i,
  payon_forest: /payon.?forest|forest/i,
  payon_cave: /payon.?cave|cave/i,
};
// v4: stageKey selects which stage card to pick (prontera default;
// sewer = Culverts Lv 9-12, sunken = Sunken Ship Lv 11-15 for the ladder).
// ---- party play ---------------------------------------------------------
// The game supports party expeditions: the leader proposes a trip from the
// captain and every member accepts it. Party work needs the game's realtime
// socket (the lobby, the invitations and the trip all travel over it), so
// when the socket is unavailable the bot says so and plays solo.
const PARTY = argv.party === 'true';
const ALLY = String(argv.ally || '').trim();
async function partyState(page) {
  return await page.evaluate(() => {
    const p = window.__RO_PLAZA__;
    if (!p) return null;
    return {
      net: !!p.net,
      status: p.status || '',
      inParty: !!p.party,
      leader: p.isPartyLeader ? !!p.isPartyLeader() : false,
      members: p.partyMembers ? p.partyMembers().length : 0,
      partyAsk: !!p.partyAsk,
      tripAsk: !!p.tripAsk,
    };
  }).catch(() => null);
}
// Click a button in the game's dialog by its label (the game writes its UI
// through the same Ae() helper, so the buttons live in #npc-dialog).
async function clickDialogButton(page, labelRe) {
  return await page.evaluate((reSrc) => {
    const re = new RegExp(reSrc, 'i');
    const dlg = document.getElementById('npc-dialog');
    if (!dlg || dlg.classList.contains('hidden')) return false;
    const btn = [...dlg.querySelectorAll('button')].find(b => re.test((b.textContent || '').trim()));
    if (!btn) return false;
    btn.click();
    return true;
  }, labelRe).catch(() => false);
}
// Wait for the game's party invitation dialog and accept it.
async function acceptPartyInvite(page, seconds) {
  const deadline = Date.now() + seconds * 1000;
  while (Date.now() < deadline) {
    const st = await partyState(page);
    if (st && st.partyAsk) {
      if (await clickDialogButton(page, '^(Aceptar|Accept)$')) { log({ msg: 'party: accepted the invitation' }); return true; }
    }
    await page.waitForTimeout(1000);
  }
  return false;
}
// Wait for the trip the leader proposed and accept it.
async function acceptTripAsk(page, seconds) {
  const deadline = Date.now() + seconds * 1000;
  while (Date.now() < deadline) {
    const st = await partyState(page);
    if (st && st.tripAsk) {
      if (await clickDialogButton(page, '^(Aceptar|Accept|Listo|Ready|Voy|Go)$')) { log({ msg: 'party: accepted the trip' }); return true; }
    }
    await page.waitForTimeout(1000);
  }
  return false;
}
// Leader side: invite a named partner from the lobby's friend list.
async function inviteAlly(page, name) {
  await page.evaluate(() => {
    const btn = [...document.querySelectorAll('button, .ro-btn')].find(b => /^(Friends|Party|Grupo|Amigos)$/i.test((b.textContent || '').trim()));
    if (btn) btn.click();
  }).catch(() => {});
  await page.waitForTimeout(1200);
  const done = await page.evaluate((n) => {
    const panel = document.getElementById('lobby-friends') || document.getElementById('friends');
    if (!panel) return false;
    const want = String(n).toLowerCase();
    const leaf = [...panel.querySelectorAll('*')].find(e => e.children.length === 0 && (e.textContent || '').trim().toLowerCase() === want);
    if (!leaf) return false;
    const row = leaf.closest('button, li, .fr, .row, .friend') || leaf;
    row.click();
    return true;
  }, name).catch(() => false);
  if (done) log({ msg: `party: invited ${name}` });
  else log({ msg: `party: ${name} was not in the friend list (not online?)` });
  return done;
}
async function enterStage(page, runNo, stageKey) {
  const stageRe = STAGE_MATCH[stageKey] || STAGE_MATCH.prontera;
  const onSelect = await page.evaluate(() => { const el = document.querySelector('#charselect'); return !!el && !el.classList.contains('hidden'); }).catch(() => false);
  if (onSelect) { log({ run: runNo, msg: 'still on character select — did not enter the plaza, aborting stage entry' }); await shot(page, `r${runNo}-still-charselect`); return false; }
  const onCreate = await page.evaluate(() => { const el = document.querySelector('#charcreate'); return !!el && !el.classList.contains('hidden'); }).catch(() => false);
  if (onCreate) { log({ run: runNo, msg: 'still on the Create character form — character was not created, aborting stage entry' }); await shot(page, `r${runNo}-still-charcreate`); return false; }
  // Party play: get into a party before the captain conversation. Without the
  // game's realtime socket there is no lobby, no invitation and no trip, so
  // the bot says so and continues solo.
  let partyMember = false;
  if (PARTY) {
    // The plaza object only exists once the character is in town.
    let pst = null;
    for (let waited = 0; waited < 90000; waited += 2000) {
      pst = await partyState(page);
      if (pst) break;
      await page.waitForTimeout(2000);
    }
    if (!pst) log({ run: runNo, msg: 'party: the plaza never came up — solo play' });
    else if (!pst.net) log({ run: runNo, msg: 'party: the game server socket is unavailable (offline) — solo play' });
    else {
      if (!pst.inParty || pst.members < 2) {
        if (ALLY) { await inviteAlly(page, ALLY); await page.waitForTimeout(6000); }
        else { await acceptPartyInvite(page, 45); }
        const now = await partyState(page);
        if (now && now.inParty && now.members >= 2) log({ run: runNo, msg: `party: joined (${now.members} member(s), leader=${now.leader})` });
        else log({ run: runNo, msg: 'party: no party formed — solo play' });
      }
      const cur = await partyState(page);
      // A party only counts when it really has members: with the socket
      // down the plaza still holds an empty party object.
      if (cur && cur.inParty && cur.members >= 2) {
        partyMember = !cur.leader;
        log({ run: runNo, msg: `party: ${cur.leader ? 'leading' : 'following the leader'} (${cur.members} members, status=${cur.status})` });
      } else {
        log({ run: runNo, msg: `party: no party (status=${cur ? cur.status : '?'} net=${cur ? cur.net : '?'} members=${cur ? cur.members : '?'}) — solo play` });
      }
    }
  }
  const mover = new Mover(page);
  const deadline = Date.now() + 180000;
  let loggedPlaza = false, loggedStagesDiag = false;
  while (Date.now() < deadline) {
    const chk = await stagesOpenNow(page);
    if (chk.via) {
      if (chk.via === 'plaza-overlays' && !loggedStagesDiag) {
        loggedStagesDiag = true;
        const diag = await page.evaluate(() => { const el = document.querySelector('#stages'); const cs = el ? getComputedStyle(el) : null; return el ? { cls: el.className, display: cs.display, visibility: cs.visibility, cards: document.querySelectorAll('#stg-list .stg-card').length, goDisabled: (document.querySelector('#stg-go') || {}).disabled ?? null, goHidden: (document.querySelector('#stg-go') || { classList: { contains: () => null } }).classList.contains('hidden') } : null; }).catch(() => null);
        log({ run: runNo, msg: `DIAG stages open via plaza overlays but NOT via readHud: ${JSON.stringify(diag)}` });
      }
      log({ run: runNo, msg: `stages overlay open (via ${chk.via}) — going to stage selection` });
      break;
    }
    const hud = chk.hud;
    if (hud.hudVisible) break; // already in a run
    // Must come before the NPC-dialog branch below: the lobby picker lives in
    // the same #npc-dialog, and its only #npc-options button plays offline.
    if (await ensureLobby(page)) continue;
    if (hud.npcDialog) {
      const acted = await page.evaluate(() => {
        const opts = [...document.querySelectorAll('#npc-options button, #npc-options > *')].filter(e => { const cs = getComputedStyle(e); return cs.display !== 'none' && cs.visibility !== 'hidden' && !/sin conexi|offline/i.test(e.textContent || ''); });
        const hit = opts.find(e => /expedici|stage|viajar|partir|prontera|salir/i.test(e.textContent)) || opts[0];
        if (hit) { hit.click(); return hit.textContent.trim().slice(0, 80); } return null;
      });
      log({ run: runNo, msg: `npc dialog: ${acted ? 'chose "' + acted + '"' : 'no option, pressing Space'}` });
      if (!acted) await page.keyboard.press('Space');
      await page.waitForTimeout(1200); continue;
    }
    const pz = chk.pz || await readPlaza(page);
    // Character inventory feed (equipment + backpack) — the plaza snapshot
    // carries it, so it is written for the GUI's live inventory panel.
    if (pz && pz.char && pz.char.ok) {
      lastCharData = pz.char;
      try {
        const target = path.join(OUT, 'inventory.json');
        const tmp = `${target}.tmp`;
        fs.writeFileSync(tmp, JSON.stringify({ at: Date.now(), ...pz.char }));
        fs.renameSync(tmp, target);
      } catch {}
    }
    if (!pz && !hud.hudVisible) {
      const captainPrompt = await page.evaluate(() => {
        const prompt = document.querySelector('#lobby-prompt');
        return prompt && prompt.getClientRects().length && /talk to the captain/i.test(prompt.textContent) ? prompt.textContent.trim() : null;
      }).catch(() => null);
      if (captainPrompt) {
        await mover.releaseAll();
        log({ run: runNo, msg: `plaza snapshot unavailable; using visible captain prompt: ${captainPrompt}; pressing Space` });
        await page.keyboard.press('Space');
        await page.waitForTimeout(1000);
        continue;
      }
    }
    if (pz && pz.ok) {
      if (!loggedPlaza) { loggedPlaza = true; log({ run: runNo, msg: `plaza snapshot: player=(${pz.player.x},${pz.player.y}) npcs=${pz.npcs.map(n => n.id + '@' + n.x + ',' + n.y).join(' ')}` }); await shot(page, `r${runNo}-plaza`); }
      // Stages already open (seen via plaza overlays) — stop talking to the
      // captain and go straight to stage selection; pressing more keys here
      // only toggles/closes things (the smoke6 failure loop).
      if (pz.overlays && pz.overlays.includes('stages')) { log({ run: runNo, msg: 'stages already open per plaza snapshot — breaking to stage selection' }); break; }
      const cap = pz.npcs.find(n => n.id === 'captain');
      if (!cap) { log({ run: runNo, msg: 'plaza snapshot has no captain NPC yet — waiting' }); await page.waitForTimeout(2000); continue; }
      const dx = cap.x - pz.player.x, dy = cap.y - pz.player.y, d = Math.hypot(dx, dy);
      // Trust the game's own talk range (pz.near): inside a lobby the chat box
      // can hold focus, so WASD is swallowed and the character never moves —
      // that is how the bot sat at 148px from the captain for the full 180s.
      if (d < 120 || pz.near === 'captain') {
        await mover.releaseAll();
        log({ run: runNo, msg: `at captain (${Math.round(d)}px, near=${pz.near}, overlays=${JSON.stringify(pz.overlays)}, focus=${pz.activeTag}) — blurring focus, then Space` });
        await page.evaluate(() => { if (document.activeElement) document.activeElement.blur(); });
        await page.keyboard.press('Space');
        await page.waitForTimeout(1500);
        let chk2 = await stagesOpenNow(page);
        if (chk2.hud.npcDialog || chk2.via) continue;
        log({ run: runNo, msg: `Space did not open dialog — trying Enter` });
        await page.keyboard.press('Enter');
        await page.waitForTimeout(1500);
        chk2 = await stagesOpenNow(page);
        if (chk2.hud.npcDialog || chk2.via) continue;
        // Mouse path (the game's own click-to-talk): click the captain's
        // screen position — moveTo() sets talkTo when the click lands within
        // 60 world units of an NPC and fires onTalk() when close.
        if (cap.screen) {
          log({ run: runNo, msg: `keys did not talk — clicking captain at screen (${cap.screen.x},${cap.screen.y})` });
          await page.mouse.click(cap.screen.x, cap.screen.y + 30);
          await page.waitForTimeout(2500);
          chk2 = await stagesOpenNow(page);
          if (chk2.hud.npcDialog || chk2.via) continue;
          log({ run: runNo, msg: `canvas click did not open dialog either — retrying loop` });
        } else {
          log({ run: runNo, msg: `no screen coords for captain — retrying loop` });
        }
        await page.waitForTimeout(1000);
        continue;
      }
      // A focused chat input eats WASD; drop focus before steering.
      await page.evaluate(() => { const a = document.activeElement; if (a && /^(INPUT|TEXTAREA)$/.test(a.tagName)) a.blur(); }).catch(() => {});
      await mover.setVec(dx / d, dy / d);
      await page.waitForTimeout(300);
      continue;
    }
    // No plaza snapshot yet (plaza still loading) — wait.
    await page.waitForTimeout(2000);
  }
  await mover.releaseAll();
  const chkEnd = await stagesOpenNow(page);
  const hudEnd = chkEnd.hud;
  if (!chkEnd.via && !hudEnd.hudVisible) { log({ run: runNo, msg: 'FAILED to reach stages/run from plaza within 180s' }); await shot(page, `r${runNo}-plaza-failed`); return false; }
  if (chkEnd.via) {
    // Dump the real stage list before picking (card classes/select state).
    const listDump = await page.evaluate(() => [...document.querySelectorAll('#stg-list .stg-card')].map((c, i) => ({ i, cls: c.className, disabled: c.disabled, text: c.textContent.replace(/\s+/g, ' ').trim().slice(0, 90) }))).catch(() => null);
    log({ run: runNo, msg: `stages list (${(listDump || []).length} cards): ${JSON.stringify(listDump)}` });
    const stage = await page.evaluate((reSrc) => {
      const cards = [...document.querySelectorAll('#stg-list .stg-card')];
      const re = new RegExp(reSrc, 'i');
      const hit = cards.find(c => re.test(c.textContent));
      if (!hit) return null;
      const txt = hit.textContent.replace(/\s+/g, ' ').trim();
      hit.click();
      return { text: txt.slice(0, 120), locked: /locked|bloqueado/i.test(txt), cls: hit.className };
    }, stageRe.source);
    log({ run: runNo, msg: `stages open, picked [${stageKey}]: ${JSON.stringify(stage)}` });
    if (!stage) { log({ run: runNo, msg: `stage ${stageKey} NOT FOUND in stages list — aborting entry` }); return false; }
    if (stage.locked) { log({ run: runNo, msg: `stage ${stageKey} is LOCKED (${stage.text}) — ladder stops here` }); return false; }
    await page.waitForTimeout(800); await shot(page, `r${runNo}-stages`);
    const goState = await page.evaluate(() => { const b = document.querySelector('#stg-go'); return b ? { disabled: b.disabled, hidden: b.classList.contains('hidden'), text: b.textContent.trim() } : null; }).catch(() => null);
    log({ run: runNo, msg: `stg-go state before click: ${JSON.stringify(goState)}` });
    log({ run: runNo, msg: `stg-go click: ${JSON.stringify(await domClick(page, '#stg-go'))}` });
    // Fail fast if the run does not start: wait up to 20s for the run HUD
    // or the exposed run object; if neither appears, dump and abort
    // instead of burning the whole 180s play loop with no state.
    // "Set out" does NOT start the run directly: it closes the stages
    // window and opens a Difficulty dialog (rendered inside #npc-dialog)
    // with Cancel / "Go to the …" — the run only starts after confirming
    // there (found in fix1, 13:18:43). So wait up to 40s, and confirm the
    // dialog whenever it appears.
    let started = false, loggedDiff = false;
    for (let w = 0; w < 40000; w += 2000) {
      await page.waitForTimeout(2000);
      const liveState = await readState(page);
      if (isLiveRunState(liveState)) {
        started = true;
        log({ run: runNo, msg: `run started after ~${(w + 2000) / 1000}s (state=${liveState.state} stage=${liveState.stage})` });
        break;
      }
      // Party member: the leader's trip has to be accepted before the run
      // starts for this character.
      if (partyMember) await acceptTripAsk(page, 2);
      const dlg = await page.evaluate(() => {
        const d = document.querySelector('#npc-dialog');
        if (!d || d.classList.contains('hidden')) return null;
        const name = (document.querySelector('#npc-name') || {}).textContent || '';
        const text = (d.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 500);
        const btns = [...d.querySelectorAll('button')].map(b => ({ text: b.textContent.trim().slice(0, 60), disabled: b.disabled, hidden: b.classList.contains('hidden') }));
        return { name, text, btns };
      }).catch(() => null);
      if (dlg) {
        if (!loggedDiff) { loggedDiff = true; log({ run: runNo, msg: `difficulty dialog: ${JSON.stringify(dlg)}` }); }
        // Re-entering a map that still holds an abandoned run offers Resume/Discard;
        // resume would restore the old difficulty, so discard and start fresh.
        if (/Unfinished run/i.test(dlg.text)) {
          const discarded = await page.evaluate(() => {
            const d = document.querySelector('#npc-dialog');
            const hit = [...(d?.querySelectorAll('button') || [])].find(b => /discard/i.test(b.textContent) && !b.disabled && !b.classList.contains('hidden'));
            if (!hit) return null;
            hit.click();
            return hit.textContent.trim().slice(0, 60);
          }).catch(() => null);
          if (discarded) {
            log({ run: runNo, msg: `discarded the unfinished run ("${discarded}"); starting a fresh one` });
            continue;
          }
        }
        if (MAX_LOOT) {
          const maxed = await page.evaluate(() => {
            const d = document.querySelector('#npc-dialog');
            if (!d) return null;
            const inputs = [...d.querySelectorAll('.diff input[data-key]')];
            if (!inputs.length) return { inputs: 0 };
            for (const inp of inputs) {
              inp.value = inp.max;
              inp.dispatchEvent(new Event('input', { bubbles: true }));
            }
            return {
              inputs: inputs.length,
              values: inputs.map(i => `${i.dataset.key}=${i.value}`),
              loot: (d.querySelector('[data-out="drop"]') || {}).textContent || null,
            };
          }).catch(() => null);
          if (maxed && maxed.inputs) log({ run: runNo, msg: `MAX-LOOT: difficulty sliders at max (${maxed.values.join(',')}) loot ${maxed.loot}` });
        }
        const goBtn = await page.evaluate(() => {
          const d = document.querySelector('#npc-dialog');
          if (!d) return null;
          const btns = [...d.querySelectorAll('button')].filter(b => !b.disabled && !b.classList.contains('hidden'));
          const hit = btns.find(b => /go to|go!|start|depart|set out|comenzar|partir|confirm|accept/i.test(b.textContent));
          if (hit) { hit.click(); return hit.textContent.trim().slice(0, 60); } return null;
        }).catch(() => null);
        if (goBtn) log({ run: runNo, msg: `difficulty dialog: clicked "${goBtn}"` });
      }
    }
    if (!started) {
      const dump = await page.evaluate(() => ({ stagesHidden: (document.querySelector('#stages') || { classList: { contains: () => null } }).classList.contains('hidden'), overlays: [...document.querySelectorAll('.overlay:not(.hidden)')].map(e => e.id), bodyText: document.body.innerText.slice(0, 400) })).catch(() => null);
      log({ run: runNo, msg: `stg-go did NOT start a run within 40s: ${JSON.stringify(dump)}` });
      await shot(page, `r${runNo}-stage-start-failed`);
      return false;
    }
  }
  return true;
}

// After a stage clear the game shows loot/end screens, then returns to
// the plaza (or character select). Poll for the plaza snapshot; click
// through end screens with generic continue buttons. Returns true once
// the plaza snapshot is live.
async function returnToPlaza(page, runNo) {
  for (let w = 0; w < 120000; w += 3000) {
    const pz = await readPlaza(page).catch(() => null);
    if (pz && pz.ok) { log({ run: runNo, msg: `back in plaza after ~${w / 1000}s (player ${pz.player.x},${pz.player.y})` }); return true; }
    const st = await page.evaluate(() => {
      const vis = s => { const el = document.querySelector(s); return !!el && !el.classList.contains('hidden'); };
      return { charselect: vis('#charselect'), hud: vis('#hud'), overlays: [...document.querySelectorAll('.overlay:not(.hidden)')].map(e => e.id) };
    }).catch(() => ({}));
    if (st.charselect) {
      log({ run: runNo, msg: 'returnToPlaza: on character select — pressing Play to re-enter plaza' });
      await domClick(page, '#btn-play'); await page.waitForTimeout(3000); continue;
    }
    const clicked = await page.evaluate(() => {
      const btns = [...document.querySelectorAll('button')].filter(b => !b.disabled && !b.classList.contains('hidden') && b.getBoundingClientRect().width > 0);
      const hit = btns.find(b => /plaza|return|continue|volver|salir|close|cerrar|accept|aceptar|ok|reclamar|claim/i.test(b.textContent || ''));
      if (hit) { hit.click(); return (hit.textContent || '').trim().slice(0, 60); } return null;
    }).catch(() => null);
    if (clicked) log({ run: runNo, msg: `returnToPlaza: clicked "${clicked}" (overlays=${JSON.stringify(st.overlays)})` });
    else await page.keyboard.press('Space');
    await page.waitForTimeout(3000);
  }
  log({ run: runNo, msg: 'returnToPlaza FAILED within 120s — ladder stops here' });
  await shot(page, `r${runNo}-no-plaza`);
  return false;
}

// v6.2 DEATH DIAGNOSIS: attribute the HP lost in the last 8 game-seconds
// before death to skill zones vs contact damage, from the rolling buffer.
// A tick's HP loss counts as skill damage when the player stood inside a
// live AoE zone (fireRing/fxAnchor) as it dropped, contact when no zone
// covered the player and the nearest enemy was < 60px, else other.
// Verdict SKILL-OVERLAP = Araso's diagnosis; PACK-CONTACT = the v6 one.
// Preview frame rate: set per page while a run is going (see runOneWithPage).
let setStreamRate = null;
// Persistent and Camoufox workers reuse one page between runs. Keep the first
// homepage/login load separate from later Results/Town -> Character Select
// recovery so every death does not download the whole game again.
const persistentPageRunState = new WeakMap();

async function resetToCharacterSelect(page, runNo) {
  for (let waited = 0; waited < 120000; waited += 1000) {
    const state = await page.evaluate(() => {
      const visible = el => !!el && !el.classList.contains('hidden') && el.getBoundingClientRect().width > 0;
      const charselect = document.querySelector('#charselect');
      const gameover = document.querySelector('#gameover');
      const plaza = typeof window.__RO_PLAZA_SNAPSHOT__ === 'function' && !!window.__RO_PLAZA_SNAPSHOT__()?.ok;
      return { charselect: visible(charselect), gameover: visible(gameover), plaza };
    }).catch(() => ({ charselect: false, gameover: false, plaza: false }));
    if (state.charselect) {
      log({ run: runNo, msg: 'reusing page: character select ready after previous run' });
      return true;
    }
    if (state.gameover) {
      const clicked = await page.evaluate(() => {
        const overlay = document.querySelector('#gameover');
        const buttons = [...(overlay?.querySelectorAll('button') || [])].filter(b => !b.disabled && !b.classList.contains('hidden') && b.getBoundingClientRect().width > 0);
        const hit = document.querySelector('#btn-restart') || buttons.find(b => /back to character|return to town|town|continue|return|close|ok/i.test(b.textContent || ''));
        if (!hit || hit.disabled || hit.classList.contains('hidden')) return null;
        hit.click();
        return (hit.textContent || '').trim().slice(0, 60);
      }).catch(() => null);
      if (clicked) log({ run: runNo, msg: `reusing page: left Results via "${clicked}"` });
    } else if (state.plaza) {
      const clicked = await page.evaluate(() => {
        const hit = document.querySelector('#lobby-switch') || [...document.querySelectorAll('button, [data-act]')].find(b => /switch\s+character/i.test(b.textContent || '') && b.getBoundingClientRect().width > 0);
        if (!hit) return false;
        hit.click();
        return true;
      }).catch(() => false);
      if (clicked) log({ run: runNo, msg: 'reusing page: town -> switch character' });
    } else {
      await page.keyboard.press('Space').catch(() => {});
    }
    await page.waitForTimeout(1000);
  }
  log({ run: runNo, msg: 'WARN could not return to character select without reloading' });
  return false;
}

async function playRun(page, runNo) {
  if (typeof setStreamRate === 'function') setStreamRate(true);
  const mover = new Mover(page);
  const start = Date.now();
  const stats = { picks: 0, pickLog: [], skippedLog: [], cause: null, maxLevel: 1, maxKills: 0, lastHp: null, hpMin: 1, hpMinAt: null, snapSamples: [], stateSeen: false, noStateTicks: 0, liveSnapSaved: false, startGameTime: null, endGameTime: null, startExp: 0, endExp: 0, totalExpGained: 0, expSamples: [], stuckEscapes: 0, walkReroutes: 0, walkRouteMisses: 0, modes: {}, maxLive: 0, timeAbove40: 0, timeAbove55: 0, timeAbove100: 0, bossFights: [], bossBrainDumped: {}, bossKillTimes: {}, cleared: false, mvpKilled: null, dmgBy: {}, killsBy: {}, closeAt: null, lootUntil: null, timeUp: null, pickDedupe: {}, phantomPicks: 0, _lastT: null, _overtimeLogged: false, _closeLogged: false, dodge: { triggers: 0, hard: 0, castsExposed: 0 }, meat: { rescuesAttempted: 0, rescuesSucceeded: 0, rescuesDenied: 0, meatEaten: 0, _lastMeatCount: null, _rescueKey: null, _lastHp: null, _rescueActive: false },
    thin: { prethinEntries: 0, breakouts: 0, atSpawn: {}, _lastMode: null }, // v6.2
    death: { buf: [], _prevHp: null, diag: null }, // v6.2: skill-overlap vs pack diagnosis
    // v5 LOOT metrics (see ../loot-spec.md §8). gemExp = cumulative EXP gained
    // (gems are the only regular EXP source; +30 for an empty chest also lands
    // here). zenyEarned = end zeny + zeny spent on chests. lootPerMin =
    // (gemExp + zenyEarned + 100*chests + 200*(gear+cards+eggs)) / game-min.
    loot: { gemExp: 0, zenyEnd: 0, zenyEarned: 0, chestSpend: 0, chestsOpened: 0, gear: 0, cards: 0, eggs: 0, mobLoot: 0, _prevExp: null, _prevLevel: null, _prevExpNext: null, _prevChests: 0, _bossLootAtSpawn: {} } };
  const steerState = { orbitDir: 1, orbitFlipAt: 0, lastPos: null, lastPosAt: 0, stuckSince: null, escapeUntil: 0, escapeDir: null, ranged: JOB_DEFS[JOB].ranged, prevReady: null, skillReadyAt: {}, dodges: 0, hardDodges: 0, castsExposed: 0, rescueDenied: 0, rescuesAttempted: 0 };
  let pickerOpenedAt = null, pickerCards = 0, lastPickerKey = null, lastLog = 0, lastSample = 0, lastShot = 0, lastDashboardShot = 0;
  while (Date.now() - start < MAX_SECONDS * 1000) {
    const now = Date.now(); const elapsedS = Math.floor((now - start) / 1000);
    if (now - lastDashboardShot >= 5000) {
      lastDashboardShot = now;
      await captureDashboard(page);
    }
    const hud = await readHud(page);
    const s = await readState(page);
    if (!s || !s.ok) await mover.releaseAll();
    if (s && s.ok) {
      stats.stateSeen = true;
      stats.maxLevel = Math.max(stats.maxLevel, s.level); stats.maxKills = Math.max(stats.maxKills, s.kills); stats.lastHp = s.hp / s.maxHp;
      if (s.hp / s.maxHp < stats.hpMin) { stats.hpMin = s.hp / s.maxHp; stats.hpMinAt = s.time; }
      if (stats.startGameTime == null) { stats.startGameTime = s.time; stats.startExp = s.exp; }
      stats.endGameTime = s.time; stats.endExp = s.exp;
      // v4 density ledger: game-time spent above the anti-encirclement lines.
      if (stats._lastT != null) { const dt = Math.max(0, s.time - stats._lastT); if (s.enemies.length >= 40) stats.timeAbove40 += dt; if (s.enemies.length >= 55) stats.timeAbove55 += dt; if (s.enemies.length >= 100) stats.timeAbove100 += dt; }
      stats._lastT = s.time;
      stats.maxLive = Math.max(stats.maxLive, s.enemies.length);
      if (s.timeUp) stats.timeUp = s.timeUp; if (s.closeAt) stats.closeAt = s.closeAt; if (s.lootUntil) stats.lootUntil = s.lootUntil;
      if (s.dmgBy) stats.dmgBy = s.dmgBy; if (s.killsBy) stats.killsBy = s.killsBy;
      // v5 loot ledger (every snapshot tick).
      { const L = stats.loot;
        if (L._prevExp == null) { L._prevExp = s.exp; L._prevLevel = s.level; L._prevExpNext = s.expNext; L._prevChests = s.chestsOpened || 0; }
        else {
          if (s.level > L._prevLevel) L.gemExp += Math.max(0, (L._prevExpNext - L._prevExp) + s.exp);
          else if (s.exp >= L._prevExp) L.gemExp += s.exp - L._prevExp;
          L._prevExp = s.exp; L._prevLevel = s.level; L._prevExpNext = s.expNext;
        }
        const ch = s.chestsOpened || 0;
        if (ch > L._prevChests) { for (let n = L._prevChests; n < ch; n++) L.chestSpend += Math.round(30 + 25 * n + 1.5 * n * n); L._prevChests = ch; }
        L.chestsOpened = ch; L.zenyEnd = s.zeny || 0; L.zenyEarned = L.zenyEnd + L.chestSpend;
        L.gear = (s.runLoot || []).length; L.cards = (s.runCards || []).length; L.eggs = (s.runEggs || []).length; L.mobLoot = s.mobLoot || 0;
      }
      if (s.timeUp && !stats._closeLogged) { stats._closeLogged = true; log({ run: runNo, msg: `run timing: timeUp=${s.timeUp}s closeAt=${s.closeAt} lootUntil=${s.lootUntil} stage=${s.stage} bossSchedule=${JSON.stringify(mapBossTimes(s))}` }); }
      // v6.2 DEATH DIAGNOSIS: rolling 8-game-second buffer of what was
      // hurting us — live AoE zones overlapped, skills about to fire,
      // nearest enemy, HP deltas. On death this proves skill-overlap vs
      // pack-contact instead of asserting either. Zones = fireRings ONLY
      // (fxAnchors are damage numbers/visuals, not telegraphs — counting
      // them polluted the first smoke diagnosis).
      const _zonesNow = (s.fireRings || []).filter(r => Math.hypot(s.player.x - r.x, s.player.y - r.y) < r.r).length;
      const _nearNow = s.enemies.reduce((m, e) => Math.min(m, Math.hypot(e.x - s.player.x, e.y - s.player.y)), Infinity);
      const _immNow = [];
      for (const bb of s.bossBrains || []) (bb.skills || []).forEach((sk, i) => { if (bb.ready && bb.ready[i] != null && bb.ready[i] <= 0.5) _immNow.push(bb.boss + ':' + sk.name); });
      const _dhp = stats.death._prevHp == null ? 0 : s.hp - stats.death._prevHp;
      stats.death.buf.push({ t: s.time, hp: s.hp, dhp: _dhp, zones: _zonesNow, nearest: _nearNow === Infinity ? null : Math.round(_nearNow), imminent: _immNow });
      while (stats.death.buf.length > 1 && s.time - stats.death.buf[0].t > 8) stats.death.buf.shift();
      stats.death._prevHp = s.hp;
      // Boss tracking: first sight per boss id -> dump bossBrains (attack
      // patterns from the bundle, live) + record the fight; kill = boss
      // disappears from the live lists. mvpsKilled confirms Mastering.
      for (const bb of s.bossBrains || []) {
        if (!stats.bossBrainDumped[bb.boss]) {
          stats.bossBrainDumped[bb.boss] = true;
          stats.bossFights.push({ boss: bb.boss, spawnT: Math.round(s.time * 10) / 10, hpMax: bb.maxHp, skills: bb.skills, killT: null, hpStart: s.hp, hpMin: s.hp, hpEnd: null, dmgDealt: null, lastBossHp: bb.maxHp, castsStart: steerState.castsExposed || 0, dodgesStart: steerState.dodges || 0, castsExposed: null, dodges: null, maxZones: _zonesNow });
          // v6.2: what did the pack look like when this boss spawned?
          // (the whole point of pre-boss thinning — did we enter thin?)
          const _na = s.enemies.filter(e => !e.boss).reduce((m, e) => Math.min(m, Math.hypot(e.x - s.player.x, e.y - s.player.y)), Infinity);
          stats.thin.atSpawn[bb.boss] = { t: Math.round(s.time), live: s.enemies.length, nearestAdd: _na === Infinity ? null : Math.round(_na) };
          stats.loot._bossLootAtSpawn[bb.boss] = { gear: (s.runLoot || []).length, cards: (s.runCards || []).length, eggs: (s.runEggs || []).length, gemExp: stats.loot.gemExp, zeny: s.zeny || 0 };
          try { fs.writeFileSync(path.join(OUT, `boss-${bb.boss}-${Math.round(s.time)}s.json`), JSON.stringify({ t: s.time, brain: bb }, null, 2)); } catch (e) {}
          log({ run: runNo, msg: `BOSS ${bb.boss} spawned t=${s.time.toFixed(0)}s hp=${bb.maxHp} skills=${(bb.skills || []).map(x => x.name + '(cd' + x.cd + '/r' + x.range + ')').join(', ')} thinAtSpawn=${JSON.stringify(stats.thin.atSpawn[bb.boss])}` });
        }
      }
      for (const f of stats.bossFights) {
        if (f.killT == null) {
          f.hpMin = Math.min(f.hpMin, s.hp);
          f.maxZones = Math.max(f.maxZones || 0, _zonesNow); // v6.2: worst overlap during this fight
          const be = (s.bosses || []).find(b => b.id === f.boss) || (s.enemies || []).find(e => e.id === f.boss);
          if (be) f.lastBossHp = be.hp;
        }
      }
      for (const f of stats.bossFights) {
        if (f.killT == null && !(s.bosses || []).some(b => b.id === f.boss) && !(s.enemies || []).some(e => e.id === f.boss) && s.time > f.spawnT + 5) {
          f.killT = Math.round(s.time * 10) / 10; stats.bossKillTimes[f.boss] = f.killT;
          const b0 = stats.loot._bossLootAtSpawn[f.boss] || { gear: 0, cards: 0, eggs: 0, gemExp: 0, zeny: 0 };
          f.drops = { gear: (s.runLoot || []).length - b0.gear, cards: (s.runCards || []).length - b0.cards, eggs: (s.runEggs || []).length - b0.eggs, gemExp: Math.round(stats.loot.gemExp - b0.gemExp), zeny: (s.zeny || 0) - b0.zeny };
          f.hpEnd = s.hp; f.dmgDealt = f.hpMax - (f.lastBossHp ?? f.hpMax); f.castsExposed = (steerState.castsExposed || 0) - (f.castsStart || 0); f.dodges = (steerState.dodges || 0) - (f.dodgesStart || 0);
          log({ run: runNo, msg: `BOSS ${f.boss} KILLED at t=${f.killT}s (fight lasted ${Math.round(f.killT - f.spawnT)}s game) drops=${JSON.stringify(f.drops)}` });
          log({ run: runNo, msg: `BOSS ${f.boss} FIGHT ECONOMY: hp ${f.hpStart}->${f.hpEnd} (min ${f.hpMin}) dmgDealt=${f.dmgDealt} castsExposed=${f.castsExposed} dodges=${f.dodges}` });
        }
      }
      { const mvps = Array.isArray(s.mvpsKilled) ? s.mvpsKilled.length : (s.mvpsKilled || 0);
        if (mvps > 0 && stats.mvpKilled == null) { stats.mvpKilled = mvps; log({ run: runNo, msg: `MVP KILLED: mvpsKilled=${JSON.stringify(s.mvpsKilled)} at t=${s.time.toFixed(0)}s` }); } }
      const xpTotal = (s.level - 1) * 100 + s.exp; // coarse XP proxy (expNext varies; level is the real signal)
      stats.expSamples.push({ t: s.time, lv: s.level, exp: s.exp, kills: s.kills });
      if (stats.expSamples.length > 400) stats.expSamples.splice(0, 100);
      if (now - lastSample > 15000) { lastSample = now; stats.snapSamples.push({ t: s.time, lv: s.level, hp: s.hp, maxHp: s.maxHp, kills: s.kills, enemies: s.enemies.length, nearest: null, pickups: s.pickups.length, state: s.state, px: s.player.x, py: s.player.y }); }
      if (!stats.liveSnapSaved && s.enemies.length > 0) {
        stats.liveSnapSaved = true;
        log({ run: runNo, msg: `live snapshot active: t=${s.time.toFixed(1)}s enemies=${s.enemies.length} pickups=${s.pickups.length}` });
      }
      // Slim inventory feed for the GUI's live inventory panel. Written
      // every couple of seconds, one file per instance.
      if (s.ok && (!stats.snapFeedAt || now - stats.snapFeedAt > 2000)) {
        stats.snapFeedAt = now;
        try {
          const slim = {
            at: Date.now(), run: runNo, t: s.time, stage: s.stage, state: s.state,
            level: s.level, hp: s.hp, maxHp: s.maxHp, exp: s.exp, expNext: s.expNext,
            kills: s.kills, zeny: s.zeny, chestsOpened: s.chestsOpened,
            mvpsKilled: s.mvpsKilled, bossKills: s.bossKills, mobLoot: s.mobLoot,
            slots: s.slots || [], weapons: s.weapons || [], passives: s.passives || [],
            runCards: s.runCards || [], runLoot: s.runLoot || [], runEggs: s.runEggs || [],
            equip: s.equip || (lastCharData && lastCharData.equipInfo) || null,
            backpack: (lastCharData && lastCharData.inventory) || [],
            charName: (lastCharData && lastCharData.name) || null,
            stats: s.stats || null,
          };
          const target = path.join(OUT, 'snapshot.json');
          const tmp = `${target}.tmp`;
          fs.writeFileSync(tmp, JSON.stringify(slim));
          fs.renameSync(tmp, target);
        } catch {}
      }
    } else if (s === null) { stats.noStateTicks++; }
    // v6 FAIL-FAST (found in Eclipse smoke 2026-11-11): if the snapshot
    // goes away (page navigated / renderer died), readState returns an
    // error object and the loop below spins SILENTLY forever — no status
    // logs, ~0 CPU — until the wall cap. Abort loudly instead.
    if (s && s.ok) stats._lastGoodStateAt = now;
    else {
      if (stats._lastGoodStateAt == null) stats._lastGoodStateAt = now;
      else if (now - stats._lastGoodStateAt > 30000) {
        stats.cause = 'state-lost: no snapshot for 30s (page navigated/crashed?)';
        log({ run: runNo, msg: `STATE LOST: no __RO_SNAPSHOT__ for 30s — aborting run (last good t=${stats.endGameTime != null ? stats.endGameTime.toFixed(1) : '-'}s, noStateTicks=${stats.noStateTicks})` });
        await shot(page, `r${runNo}-state-lost`);
        break;
      }
    }
    if (hud.gameOver) {
      stats.cause = hud.gameOverTitle || 'game over';
      const diag = diagnoseDeath(stats); // v6.2: what actually killed us?
      log({ run: runNo, msg: `RUN OVER: ${stats.cause} — ${hud.gameOverStats || ''}` });
      log({ run: runNo, msg: `DEATH-DIAGNOSIS: ${JSON.stringify(diag)}` });
      log({ run: runNo, msg: `DEATH-BUFFER: ${JSON.stringify(stats.death.buf)}` }); // v6.2: full 8s tick log for post-hoc attribution
      await shot(page, `r${runNo}-gameover`); break;
    }
    if (s && s.ok && s.state === 'over') {
      const won = !!(s.finalBossDefeated || s.lootUntil > 0) && !activeBosses(s).length;
      stats.cleared = won; stats.mvpKilled = s.mvpsKilled;
      stats.cause = won ? 'STAGE CLEAR — endgame pickup sweep ended' : 'stage ended';
      log({ run: runNo, msg: `${won ? 'STAGE CLEAR' : 'STAGE ENDED'}: state=over time=${s.time.toFixed(0)}s pickupsRemaining=${s.pickups.length}` });
      await shot(page, `r${runNo}-${won ? 'clear' : 'ended'}`); break;
    }
    if (s && s.ok && s.timeUp && s.time >= s.timeUp) {
      const liveBosses = activeBosses(s);
      if (!liveBosses.length && victorySweepActive(s)) {
        if (!stats._victoryLootLogged) {
          stats._victoryLootLogged = true;
          log({ run: runNo, msg: `FINAL BOSS DEFEATED: leash removed; targeting nearest Magnet, otherwise nearest pickup` });
        }
      } else if (!liveBosses.length) {
        stats.cause = 'STAGE CLEAR — timeUp reached (' + s.timeUp + 's game time)'; stats.cleared = true; stats.mvpKilled = s.mvpsKilled;
        log({ run: runNo, msg: `STAGE CLEAR: time=${s.time.toFixed(0)}s lv=${s.level} kills=${s.kills} mvpsKilled=${s.mvpsKilled} bossKills=${s.bossKills} chests=${s.chestsOpened}` });
        await shot(page, `r${runNo}-clear`); break;
      } else {
        const closeAt = Number(s.closeAt);
        if (Number.isFinite(closeAt) && closeAt >= 0 && s.time >= closeAt) {
          stats.cause = 'timeUp reached but boss alive at closeAt (' + s.timeUp + 's)'; stats.mvpKilled = s.mvpsKilled;
          log({ run: runNo, msg: `END: timeUp passed, boss ${liveBosses[0].id || '-'} still alive at closeAt — lv=${s.level} kills=${s.kills} mvpsKilled=${s.mvpsKilled}` });
          await shot(page, `r${runNo}-clear-noboss`); break;
        }
        if (!stats._overtimeLogged) { stats._overtimeLogged = true; log({ run: runNo, msg: `OVERTIME: timeUp ${s.timeUp}s passed, boss ${liveBosses[0].id || '-'} still alive (hp ${liveBosses[0].hp}) — continuing until defeat` }); }
      }
    }
    if (hud.paused) { await mover.releaseAll(); await clickVisible(page, '#btn-resume', 3000); await sleep(500); continue; }
    if (hud.story || hud.npcDialog) { await mover.releaseAll(); await page.keyboard.press('Space'); await sleep(600); continue; }
    if ((hud.pickerOpen || (s && s.ok && s.state === 'levelup')) && hud.cards.length) {
      await mover.releaseAll();
      const key = hud.pickerTitle + '|' + hud.cards.map(c => c.text).join('||');
      if (key !== lastPickerKey) { pickerOpenedAt = now; pickerCards = hud.cards.length; lastPickerKey = key; log({ run: runNo, msg: `picker (${hud.pickerTitle || 'level-up'}): ${hud.cards.map(c => c.text.slice(0, 60)).join(' | ')}` }); }
      const unlockAt = pickerOpenedAt + PICKER_UNLOCK_BASE_MS + PICKER_UNLOCK_PER_CARD_MS * pickerCards;
      if (Date.now() < unlockAt) { await sleep(Math.min(unlockAt - Date.now(), 1500)); continue; }
      const ownedSkills = (s && s.ok ? [...(s.slots || []), ...(s.weapons || []), ...(s.passives || [])] : []);
      const _t = (s && s.ok ? s.time : 0);
      const _nextBoss = nextBossTime(s, _t);
      const liveBosses = activeBosses(s);
      const ctx = { hpFrac: (s && s.ok ? s.hp / s.maxHp : 1), level: (s && s.ok ? s.level : 1), elapsedS, ownedSkills, slotsFree: (s && s.ok && s.slots ? Math.max(0, 8 - s.slots.length) : null), job: JOB, pickType: hud.pickType, liveEnemies: (s && s.ok ? s.enemies.length : 0), bossDueIn: (_nextBoss != null ? _nextBoss - _t : null), bossActive: liveBosses.length > 0, zeny: (s && s.ok ? s.zeny : 0), chestsOpened: (s && s.ok ? s.chestsOpened : 0), masteringActive: liveBosses.some(b => /mastering/i.test(b.id || '')), timeToMastering: (s && s.ok ? 720 - s.time : null), bossId: liveBosses.length ? liveBosses[0].id : null };
      const scored = hud.cards.map((c, i) => ({ index: i, ...scoreCard(c.text, ctx), text: c.text }));
      let best = null; scored.forEach(sc => { if (!best || sc.score > best.score) best = sc; });
      const rerollBtn = (hud.perkBtns || []).find(b => /reroll|repetir/i.test(b.text) && !b.disabled);
      const wizardNoPreferred = JOB === 'mage' && scored.every(sc => (sc.hits || []).some(h => h === 'user-priority:random' || h === 'user-banned'));
      if (wizardNoPreferred && rerollBtn && !stats._rerolledThisPicker) {
        stats._rerolledThisPicker = true;
        log({ run: runNo, msg: 'Wizard offer has no preferred card — rerolling once before fallback/banish' });
        await page.evaluate(() => { const b = [...document.querySelectorAll('#picker button, #pk-perks button')].find(x => /reroll|repetir/i.test(x.textContent || '') && !x.disabled); if (b) b.click(); });
        await sleep(900); lastPickerKey = null; pickerOpenedAt = null; continue;
      }
      if (wizardNoPreferred && (stats._rerolledThisPicker || !rerollBtn) && !stats._banishedThisPicker) {
        const banishBtn = (hud.perkBtns || []).find(b => /banish|desterrar/i.test(b.text) && !b.disabled);
        if (banishBtn) {
          stats._banishedThisPicker = true;
          log({ run: runNo, msg: 'Wizard reroll still has no preferred card — using banish before random fallback' });
          await page.evaluate(() => { const b = [...document.querySelectorAll('#picker button, #pk-perks button, .pk-perk')].find(x => /banish|desterrar/i.test(x.textContent || '') && !x.disabled); if (b) b.click(); });
          await sleep(700); lastPickerKey = null; pickerOpenedAt = null; continue;
        }
      }
      // Other jobs: reroll once when every offer is poor and a reroll perk is visible.
      if (best && best.score < 150 && !(best.hits || []).some(h => String(h).startsWith('loot:')) && rerollBtn && !stats._rerolledThisPicker) {
        stats._rerolledThisPicker = true;
        log({ run: runNo, msg: `picker: all offers poor (best ${best.score}) — rerolling once` });
        await page.evaluate(() => { const b = [...document.querySelectorAll('#picker button, #pk-perks button')].find(x => /reroll|repetir/i.test(x.textContent || '') && !x.disabled); if (b) b.click(); });
        await sleep(900); lastPickerKey = null; pickerOpenedAt = null; continue;
      }
      stats._rerolledThisPicker = false;
      stats._banishedThisPicker = false;
      scored.filter(sc => sc !== best).forEach(sc => stats.skippedLog.push({ at: elapsedS, card: sc.text.slice(0, 100), score: sc.score, plan: sc.plan }));
      log({ run: runNo, msg: `picking ${best.index + 1}/${hud.cards.length} score=${best.score} [${best.hits.join(',')}] "${best.text.slice(0, 90)}"` });
      const pickKey = ((s && s.ok ? s.level : '?') + '|' + best.text.slice(0, 80));
      if (stats.pickDedupe[pickKey] != null && now - stats.pickDedupe[pickKey] < 20000) {
        stats.phantomPicks++;
        const diag = await page.evaluate(() => [...document.querySelectorAll('#pk-cards .pk-card')].map(el => ({ cls: el.className, dis: el.disabled }))).catch(() => null);
        log({ run: runNo, msg: `PHANTOM? same level+card ${Math.round((now - stats.pickDedupe[pickKey]) / 1000)}s after last counted pick — pressing again but NOT counting: "${best.text.slice(0, 60)}" cards=${JSON.stringify(diag)}` });
      } else {
        stats.pickDedupe[pickKey] = now; stats.picks++;
        stats.pickLog.push({ at: elapsedS, card: best.text.slice(0, 100), score: best.score, plan: best.plan, hits: best.hits, skipped: scored.filter(sc => sc !== best).map(sc => ({ card: sc.text.slice(0, 60), score: sc.score })) });
      }
      await page.keyboard.press(String(best.index + 1)); await sleep(700);
      const h2 = await readHud(page);
      if (h2.pickerOpen && h2.cards.length && h2.cards.map(c => c.text).join() === hud.cards.map(c => c.text).join()) { await page.keyboard.press('Enter'); await sleep(500); }
      // Wait for the picker to actually close (confirm animation) before
      // looping — otherwise the same open picker is re-logged and re-pressed
      // as a phantom second pick (validation run: 9 logged vs ~6 real).
      for (let w = 0; w < 3000; w += 250) { const h3 = await readHud(page); if (!h3.pickerOpen) break; await sleep(250); }
      lastPickerKey = null; pickerOpenedAt = null; continue;
    }
    // In-run: steer from exact state.
    if (s && s.ok && s.state === 'playing' && !s.player.dead) {
      // Orbit direction flips every 12s of game time (v4.1: less turning, chasers cut chords).
      if (s.time > steerState.orbitFlipAt) { steerState.orbitDir *= -1; steerState.orbitFlipAt = s.time + 12; }
      // Stuck detection: moved <25px in 5s of wall time while enemies are near.
      const nowMs = Date.now();
      if (!steerState.lastPos) { steerState.lastPos = { x: s.player.x, y: s.player.y }; steerState.lastPosAt = nowMs; }
      else if (nowMs - steerState.lastPosAt > 5000) {
        const moved = Math.hypot(s.player.x - steerState.lastPos.x, s.player.y - steerState.lastPos.y);
        if (moved < 25 && s.enemies.length > 0) {
          steerState.stuckSince = (steerState.stuckSince || nowMs);
          if (nowMs - steerState.stuckSince > 0 && nowMs > steerState.escapeUntil) {
            stats.stuckEscapes++;
            // Escape: sample 8 directions, pick the one with fewest enemies
            // within 250px along that ray (pure centroid-away runs into the
            // pack when surrounded). Hold it for 2s.
            let bestDir = null, bestCount = Infinity;
            for (let k = 0; k < 8; k++) {
              const a = k * Math.PI / 4, ux = Math.cos(a), uy = Math.sin(a);
              let cnt = 0;
              for (const e of s.enemies) { const rx = e.x - s.player.x, ry = e.y - s.player.y, d = Math.hypot(rx, ry); if (d < 250 && (rx * ux + ry * uy) / (d || 1) > 0.5) cnt++; }
              if (cnt < bestCount) { bestCount = cnt; bestDir = { dx: ux, dy: uy }; }
            }
            steerState.escapeDir = bestDir; steerState.escapeUntil = nowMs + 2000;
            log({ run: runNo, msg: `STUCK? moved ${Math.round(moved)}px in 5s with ${s.enemies.length} enemies near at (${Math.round(s.player.x)},${Math.round(s.player.y)}) moving=${!!s.player.moving} — escaping (${stats.stuckEscapes})` });
          }
        } else steerState.stuckSince = null;
        steerState.lastPos = { x: s.player.x, y: s.player.y }; steerState.lastPosAt = nowMs;
      }
      let v;
      if (nowMs < steerState.escapeUntil && steerState.escapeDir) { v = { ...steer(s, steerState), dx: steerState.escapeDir.dx, dy: steerState.escapeDir.dy }; }
      else v = steer(s, steerState);
      v = applySpawnLeash(s, v);
      v = await mapAwareVector(page, s, v);
      if (v.walkRouted) stats.walkReroutes++;
      if (v.walkRouteMiss) stats.walkRouteMisses++;
      stats.modes[v.mode] = (stats.modes[v.mode] || 0) + 1;
      // v6.2 thin ledger: log every entry into prethin / breakout once.
      if (v.mode === 'horde-prep' && stats.thin._lastMode !== 'horde-prep') { log({ run: runNo, msg: `HORDE PREP: t=${s.time.toFixed(0)}s next horde in ${v.timeToHorde != null ? Math.round(v.timeToHorde) : '-'}s live=${v.nEnemies} nearest=${v.nearest === Infinity ? '-' : Math.round(v.nearest)} hp=${s.hp}/${s.maxHp}` }); }
      if (v.mode === 'prethin' && stats.thin._lastMode !== 'prethin') { stats.thin.prethinEntries++; log({ run: runNo, msg: `PRETHIN: t=${s.time.toFixed(0)}s next boss in ${v.timeToBoss != null ? Math.round(v.timeToBoss) : '-'}s live=${v.nEnemies} nearestAdd=${v.nearestAdd} hp=${s.hp}/${s.maxHp}` }); }
      if (v.mode === 'breakout' && stats.thin._lastMode !== 'breakout') { stats.thin.breakouts++; log({ run: runNo, msg: `BREAKOUT: t=${s.time.toFixed(0)}s boss=${v.bossId} live=${v.nEnemies} nearestAdd=${v.nearestAdd} hp=${s.hp}/${s.maxHp}` }); }
      stats.thin._lastMode = v.mode;
      // (setVec is guarded below: a dead target aborts cleanly.)
      stats.dodge.triggers = steerState.dodges || 0; stats.dodge.hard = steerState.hardDodges || 0; stats.dodge.castsExposed = steerState.castsExposed || 0;
      stats.meat.rescuesAttempted = steerState.rescuesAttempted || 0; stats.meat.rescuesDenied = steerState.rescueDenied || 0;
      { const meatNow = (s.pickups || []).filter(p => p.kind === 'meat').length;
        const wasRescue = stats.meat._rescueActive;
        if (stats.meat._lastMeatCount != null && meatNow < stats.meat._lastMeatCount && stats.meat._lastHp != null && s.hp > stats.meat._lastHp) {
          stats.meat.meatEaten++;
          if (wasRescue) stats.meat.rescuesSucceeded++;
        }
        stats.meat._rescueActive = (v.mode === 'rescue');
        stats.meat._lastMeatCount = meatNow; stats.meat._lastHp = s.hp; }
      try { await mover.setVec(v.dx, v.dy); } catch (e) { stats.cause = 'state-lost: input failed (target closed)'; log({ run: runNo, msg: `STATE LOST at input: ${String(e).slice(0, 120)} — aborting run` }); break; }
      if (now - lastLog > 15000) { lastLog = now; const L = stats.loot; log({ run: runNo, msg: `alive t=${s.time.toFixed(0)}s lv=${s.level} hp=${s.hp}/${s.maxHp} kills=${s.kills} (${(s.kills / Math.max(1, s.time) * 60).toFixed(1)}/game-min) enemies=${v.nEnemies} maxLive=${stats.maxLive} >55=${Math.round(stats.timeAbove55)}s nearest=${v.nearest === Infinity ? '-' : Math.round(v.nearest)} mode=${v.mode} hordeIn=${v.timeToHorde == null ? '-' : Math.round(v.timeToHorde)}s boss=${v.nearestBoss === Infinity ? '-' : Math.round(v.nearestBoss) + '/' + (v.bossHp == null ? '-' : v.bossHp + '/' + v.bossMaxHp)} pickups=${v.nPickups} dir=${mover.dirName} LOOT gemExp=${Math.round(L.gemExp)} zeny=${L.zenyEnd} chests=${L.chestsOpened} gear=${L.gear} cards=${L.cards} eggs=${L.eggs} bestPickup=${v.bestPickup ? v.bestPickup.kind + '@' + v.bestPickup.d + 'px' : '-'} dodge=${(v.dodge.reasons || []).join('+') || '-'} casts=${v.castsExposed} rescue=${v.rescue ? (v.rescue.denied ? 'DENIED@' + v.rescue.d : 'GO@' + v.rescue.d) : '-'}` }); }
      // Headed/watchable runs: periodic screenshot every 60s wall so the run
      // can be reviewed as stills even without the video.
      if (!ATTACH_EXISTING && now - lastShot > 60000) { lastShot = now; await shot(page, `r${runNo}-t${Math.round(s.time)}s`); }
    } else if (s && s.ok) {
      await mover.releaseAll();
      // v4.1: refresh the stuck-detection baseline while paused/picking so
      // the 5s window never spans a picker pause (false STUCK? in v4).
      steerState.lastPos = { x: s.player.x, y: s.player.y }; steerState.lastPosAt = Date.now(); steerState.stuckSince = null;
      if (now - lastLog > 15000) { lastLog = now; log({ run: runNo, msg: `state=${s.state} t=${s.time.toFixed(0)}s lv=${s.level} hp=${s.hp}/${s.maxHp} kills=${s.kills}` }); }
    } else {
      await mover.releaseAll();
    }
    await sleep(LOOP_MS);
  }
  await mover.releaseAll();
  if (typeof setStreamRate === 'function') setStreamRate(false);
  const survivedS = Math.floor((Date.now() - start) / 1000);
  const gameSeconds = (stats.endGameTime != null && stats.startGameTime != null) ? Math.max(0, stats.endGameTime - stats.startGameTime) : 0;
  const _gmin = Math.max(gameSeconds / 60, 0.001);
  const _L = stats.loot;
  const lootSummary = { gemExp: Math.round(_L.gemExp), gemExpPerMin: Math.round((_L.gemExp / _gmin) * 10) / 10, zenyEnd: _L.zenyEnd, zenyEarned: _L.zenyEarned, zenyPerMin: Math.round((_L.zenyEarned / _gmin) * 10) / 10, chestSpend: _L.chestSpend, chestsOpened: _L.chestsOpened, chestsPerMin: Math.round((_L.chestsOpened / _gmin) * 100) / 100, gear: _L.gear, cards: _L.cards, eggs: _L.eggs, mobLoot: _L.mobLoot, pickupsLeftOnField: stats.snapSamples.length ? stats.snapSamples[stats.snapSamples.length - 1].pickups : null, lootPerMin: Math.round(((_L.gemExp + _L.zenyEarned + 100 * _L.chestsOpened + 200 * (_L.gear + _L.cards + _L.eggs)) / _gmin) * 10) / 10 };
  const result = { run: runNo, survivedSeconds: survivedS, gameSeconds: Math.round(gameSeconds * 10) / 10, loot: lootSummary, gameWallRatio: survivedS ? Math.round((gameSeconds / survivedS) * 1000) / 1000 : 0, level: stats.maxLevel, kills: stats.maxKills, killsPerMin: gameSeconds ? Math.round((stats.maxKills / gameSeconds) * 60 * 100) / 100 : 0, killsPerGameMin: gameSeconds ? Math.round((stats.maxKills / gameSeconds) * 60 * 100) / 100 : 0, xpPerGameMin: null, picks: stats.picks, lastHpFrac: stats.lastHp, hpMin: Math.round(stats.hpMin * 1000) / 1000, hpMinAtGameS: stats.hpMinAt, stuckEscapes: stats.stuckEscapes, walkReroutes: stats.walkReroutes, walkRouteMisses: stats.walkRouteMisses, modes: stats.modes, thin: { prethinEntries: stats.thin.prethinEntries, breakouts: stats.thin.breakouts, atSpawn: stats.thin.atSpawn }, deathDiag: stats.death.diag, stateSeen: stats.stateSeen, noStateTicks: stats.noStateTicks, cause: stats.cause || (survivedS >= MAX_SECONDS ? 'time-cap reached (still alive)' : 'loop ended'), mvpKilled: stats.mvpKilled ?? null, job: JOB, stage: STAGE, cleared: stats.cleared, maxLive: stats.maxLive, timeAbove40: Math.round(stats.timeAbove40), timeAbove55: Math.round(stats.timeAbove55), timeAbove100: Math.round(stats.timeAbove100), bossFights: stats.bossFights, bossKillTimes: stats.bossKillTimes, dmgBy: stats.dmgBy, killsBy: stats.killsBy, phantomPicks: stats.phantomPicks, dodge: stats.dodge, meat: { rescuesAttempted: stats.meat.rescuesAttempted, rescuesSucceeded: stats.meat.rescuesSucceeded, rescuesDenied: stats.meat.rescuesDenied, meatEaten: stats.meat.meatEaten }, closeAt: stats.closeAt, timeUp: stats.timeUp, snapSamples: stats.snapSamples, pickLog: stats.pickLog, skippedLog: stats.skippedLog };
  // XP/min from level progression: expNext is 5 at L1; use level + exp samples.
  if (stats.expSamples.length >= 2) { const a = stats.expSamples[0], b2 = stats.expSamples[stats.expSamples.length - 1]; const dt = Math.max(1, b2.t - a.t); result.xpPerGameMin = Math.round((((b2.lv - a.lv) * 5 + (b2.exp - a.exp)) / dt) * 60 * 10) / 10; }
  log({ run: runNo, msg: `RESULT run ${runNo}: ${result.survivedSeconds}s, lv ${result.level}, ${result.kills} kills, ${result.picks} picks, stateSeen=${result.stateSeen}, cause: ${result.cause} | LOOT gemExp=${lootSummary.gemExp} (${lootSummary.gemExpPerMin}/min) zeny=${lootSummary.zenyEarned} (${lootSummary.zenyPerMin}/min) chests=${lootSummary.chestsOpened} gear=${lootSummary.gear} cards=${lootSummary.cards} eggs=${lootSummary.eggs} loot/min=${lootSummary.lootPerMin} | DODGE triggers=${stats.dodge.triggers} hard=${stats.dodge.hard} castsExposed=${stats.dodge.castsExposed} | MEAT rescues=${stats.meat.rescuesAttempted}/${stats.meat.rescuesSucceeded} denied=${stats.meat.rescuesDenied} eaten=${stats.meat.meatEaten} | THIN prethin=${stats.thin.prethinEntries} breakouts=${stats.thin.breakouts} atSpawn=${JSON.stringify(stats.thin.atSpawn)} | DEATH ${stats.death.diag ? JSON.stringify(stats.death.diag) : '-'}` });
  return result;
}

// --- speed probe (v3): measure game-time/wall-time ratio per viewport config
// in ONE entered run (no re-entry per config). Steers with the v3 policy so
// the bot does not die mid-probe; handles pickers with the planner.
async function probeSpeed(page, runNo) {
  const mover = new Mover(page);
  const steerState = { orbitDir: 1, orbitFlipAt: 0, lastPos: null, lastPosAt: 0, stuckSince: null, escapeUntil: 0, escapeDir: null, ranged: JOB_DEFS[JOB].ranged, prevReady: null, skillReadyAt: {}, dodges: 0, hardDodges: 0, castsExposed: 0, rescueDenied: 0, rescuesAttempted: 0 };
  // NOTE: deviceScaleFactor is fixed at context creation (--dsf), so one probe
  // launch covers the viewport axis at that dsf. Run a second probe launch
  // with --viewport=640x400 --dsf=0.5 for the low-dsf axis.
  const configs = [
    { name: `640x400 dsf${DSF}`, w: 640, h: 400 },
    { name: `800x500 dsf${DSF}`, w: 800, h: 500 },
    { name: `1280x800 dsf${DSF} (v2 baseline)`, w: 1280, h: 800 },
  ];
  const results = [];
  for (const cfg of configs) {
    await page.setViewportSize({ width: cfg.w, height: cfg.h });
    await sleep(5000); // settle
    const s0 = await readState(page);
    const wall0 = Date.now();
    let pickerOpenedAt = null, pickerCards = 0, lastPickerKey = null;
    while (Date.now() - wall0 < SPEED_PROBE_SECONDS * 1000) {
      const hud = await readHud(page);
      const s = await readState(page);
      if (hud.pickerOpen && hud.cards.length) {
        await mover.releaseAll();
        const key = hud.pickerTitle + '|' + hud.cards.map(c => c.text).join('||');
        if (key !== lastPickerKey) { pickerOpenedAt = Date.now(); pickerCards = hud.cards.length; lastPickerKey = key; }
        if (Date.now() < pickerOpenedAt + PICKER_UNLOCK_BASE_MS + PICKER_UNLOCK_PER_CARD_MS * pickerCards) { await sleep(200); continue; }
        const ctx = { hpFrac: (s && s.ok ? s.hp / s.maxHp : 1), level: (s && s.ok ? s.level : 1), elapsedS: 0, ownedSkills: (s && s.ok ? [...(s.slots || []), ...(s.weapons || [])] : []), slotsFree: 8 };
        let best = null; hud.cards.forEach((c, i) => { const sc = scoreCard(c.text, ctx); if (!best || sc.score > best.score) best = { index: i, ...sc }; });
        if (best) { log({ run: runNo, msg: `probe picker: ${best.index + 1}/${hud.cards.length} score=${best.score}` }); await page.keyboard.press(String(best.index + 1)); await sleep(700); }
        lastPickerKey = null; pickerOpenedAt = null; continue;
      }
      if (s && s.ok && s.state === 'playing' && !s.player.dead) {
        if (s.time > steerState.orbitFlipAt) { steerState.orbitDir *= -1; steerState.orbitFlipAt = s.time + 12; }
        const v = steer(s, steerState);
        await mover.setVec(v.dx, v.dy);
      }
      await sleep(LOOP_MS);
    }
    await mover.releaseAll();
    const s1 = await readState(page);
    const wallS = (Date.now() - wall0) / 1000;
    const gameS = (s0 && s0.ok && s1 && s1.ok) ? (s1.time - s0.time) : null;
    const ratio = gameS != null ? Math.round((gameS / wallS) * 1000) / 1000 : null;
    const rec = { config: cfg.name, wallSeconds: Math.round(wallS), gameSeconds: gameS != null ? Math.round(gameS * 10) / 10 : null, ratio, level: s1 && s1.ok ? s1.level : null, kills: s1 && s1.ok ? s1.kills : null, hp: s1 && s1.ok ? `${s1.hp}/${s1.maxHp}` : null };
    results.push(rec);
    log({ run: runNo, msg: `PROBE ${cfg.name}: ${rec.gameSeconds}s game / ${rec.wallSeconds}s wall = ${ratio}x (lv ${rec.level}, kills ${rec.kills})` });
    if (s1 && s1.ok && (s1.state === 'over' || s1.player.dead)) { log({ run: runNo, msg: 'probe: run ended, stopping probe' }); break; }
  }
  await mover.releaseAll();
  return results;
}
async function runOne(browser, runNo, job, stageKey) {
  // One full session: enter game, create/select `job`, enter `stageKey`,
  // play it. If it clears Prontera and LADDER is on, attempts sewer
  // (Culverts) then sunken (Sunken Ship) in the same session/character.
  const accountState = ACCOUNT_USER && fs.existsSync(AUTH_STATE) ? AUTH_STATE : undefined;
  const ctx = await browser.newContext({ viewport: { width: VIEWPORT[0], height: VIEWPORT[1] }, deviceScaleFactor: DSF, ignoreHTTPSErrors: true, ...(accountState ? { storageState: accountState } : {}), ...(RECORD_VIDEO ? { recordVideo: { dir: path.join(OUT, 'videos'), size: { width: VIEWPORT[0], height: VIEWPORT[1] } } } : {}) });
  const page = await ctx.newPage();
  // Frame cap: the game renders on every animation frame, which on a software
  // rasterizer costs a full core per instance. The simulation is time-based,
  // so a lower frame rate keeps the game speed and only makes it coarser.
  const fpsCap = parseInt(argv.fps || '0', 10);
  if (fpsCap > 5) {
    await page.addInitScript((cap) => {
      // The cap follows window.__RO_FPS__ so the bot can drop it while the
      // game is loading or idling (an idle browser still burns a core if it
      // animates at 20 fps).
      const minGap = () => 1000 / (window.__RO_FPS__ || cap);
      let last = 0;
      window.requestAnimationFrame = (cb) => {
        const wait = Math.max(0, minGap() - (performance.now() - last));
        return setTimeout(() => { last = performance.now(); cb(performance.now()); }, wait);
      };
      const origCancel = window.cancelAnimationFrame.bind(window);
      window.cancelAnimationFrame = (id) => { try { origCancel(id); } catch {} clearTimeout(id); };
    }, fpsCap);
  }
  try {
    return await runOneWithPage(page, runNo, job, stageKey);
  } finally {
    await ctx.close().catch(() => {});
  }
}
// Same session body, on a caller-owned page (Camoufox reuses one persistent
// profile page across runs; login and the created character survive).
async function runOneWithPage(page, runNo, job, stageKey) {
  JOB = job; STAGE = stageKey;
  await installPatchedBundleRoute(page);
  page.on('dialog', async dialog => { try { await dialog.dismiss(); } catch {} });
  page.on('console', m => { if (/error|replay/i.test(m.text())) log({ run: runNo, msg: `console.${m.type()}: ${m.text().slice(0, 300)}` }); });
  page.on('pageerror', e => log({ run: runNo, msg: `pageerror: ${String(e).slice(0, 300)}` }));
  const stageResults = [];
  // Live preview for the GUI grid. A screencast is used instead of repeated
  // screenshots: the compositor already produces frames, so asking for a fresh
  // capture every 5s only competes with the game for CPU (the box has 4 cores
  // and the headless games run on SwiftShader). The frames go out as JPEGs
  // that the app streams to the panel, so the preview plays like a video.
  const previewPath = path.join(OUT, argv.shot || 'shot.jpg');
  const previewEvery = Math.max(1, parseInt(argv['shot-every'] || '5', 10)) * 1000;
  const FRAME_PORT = parseInt(argv['frame-port'] || '0', 10);
  const FRAME_INDEX = parseInt(argv['frame-index'] || '0', 10);
  let previewCdp = null;
  let latestFrame = null;
  let lastWrite = 0;
  const postFrame = (b64) => {
    if (!FRAME_PORT) return false;
    try {
      const body = Buffer.from(b64, 'base64');
      const req = require('http').request({
        host: '127.0.0.1', port: FRAME_PORT, path: `/frame/${FRAME_INDEX}`, method: 'POST',
        headers: { 'content-type': 'image/jpeg', 'content-length': body.length },
      }, res => res.resume());
      req.on('error', () => {});
      req.end(body);
      return true;
    } catch { return false; }
  };
  try {
    previewCdp = await page.context().newCDPSession(page);
    await previewCdp.send('Page.enable');
    previewCdp.on('Page.screencastFrame', async frame => {
      latestFrame = frame.data;
      try { await previewCdp.send('Page.screencastFrameAck', { sessionId: frame.sessionId }); } catch {}
      // Push at most ~20 frames per second. The frames go straight to the
      // engine's memory (no disk churn); without a server they land in a file.
      const now = Date.now();
      if (now - lastWrite >= 50 && latestFrame) {
        lastWrite = now;
        if (!postFrame(latestFrame)) {
          try { fs.writeFileSync(previewPath, Buffer.from(latestFrame, 'base64')); } catch {}
        }
      }
    });
    await previewCdp.send('Page.startScreencast', { format: 'jpeg', quality: 55, everyNthFrame: 1 });
  } catch (e) {
    previewCdp = null;
  }
  // Adaptive rate: full speed while a run is going, a trickle while the bot
  // is loading, in town or waiting. An idle instance must not burn a core.
  let streamBusy = null;
  const applyStreamRate = (busy) => {
    if (!previewCdp || streamBusy === busy) return;
    streamBusy = busy;
    previewCdp.send('Page.startScreencast', { format: 'jpeg', quality: busy ? 55 : 40, everyNthFrame: busy ? 1 : 8 }).catch(() => {});
    page.evaluate(fps => { window.__RO_FPS__ = fps; }, busy ? 20 : 6).catch(() => {});
  };
  setStreamRate = applyStreamRate;
  applyStreamRate(false);
  const previewTimer = setInterval(() => {
    // Fallback for a browser without a screencast: a still every 5s.
    if (latestFrame || previewCdp) return;
    page.screenshot({ path: previewPath, timeout: 8000 }).catch(() => {});
  }, previewEvery);
  const continuing = persistentPageRunState.has(page);
  try {
    if (continuing) {
      if (!await resetToCharacterSelect(page, runNo)) {
        stageResults.push({ run: runNo, job, stage: stageKey, cause: 'could not return to character select without reload' });
        return stageResults;
      }
    } else {
      if (ACCOUNT_USER) {
        await page.goto(SITE, { waitUntil: 'domcontentloaded', timeout: 120000 });
        const signedIn = await ensureAccountLogin(page);
        if (!signedIn) {
          // Never farm the wrong identity: a failed login would leave the bot on
          // the guest profile, creating and levelling a throwaway character.
          log({ run: runNo, msg: `ERROR: could not sign in as ${ACCOUNT_USER} — refusing to play on the guest profile` });
          stageResults.push({ run: runNo, job, stage: stageKey, cause: 'account login failed (guest refused)' });
          return stageResults;
        }
        // The first load let the site register its service worker, which caches
        // the live bundle. Drop it, or the next load would run unpatched.
        await clearSiteCaches(page);
      }
      await enterGame(page, runNo);
    }
    if (!await selectCharacter(page, runNo)) { stageResults.push({ run: runNo, job, stage: stageKey, cause: 'character select failed' }); return stageResults; }
    persistentPageRunState.set(page, true);
    await page.waitForTimeout(2000);
    const apiState = await page.evaluate(() => ({ run: typeof window.__RO_SNAPSHOT__, plaza: typeof window.__RO_PLAZA_SNAPSHOT__ })).catch(() => null);
    log({ run: runNo, msg: `patched APIs: ${JSON.stringify(apiState)}` });
    if (!await enterStage(page, runNo, stageKey)) { stageResults.push({ run: runNo, job, stage: stageKey, cause: 'could not enter stage from plaza' }); return stageResults; }
    const hudOk = await waitVisible(page, '#hud', 30000);
    log({ run: runNo, msg: hudOk ? 'run HUD visible — starting exact-state play loop' : 'WARN run HUD never appeared' });
    await shot(page, `r${runNo}-run-start`);
    const s0 = await readState(page);
    log({ run: runNo, msg: `__RO_SNAPSHOT__ at run start: ${JSON.stringify(s0 ? { ok: s0.ok, state: s0.state, stage: s0.stage, px: s0.player && s0.player.x, py: s0.player && s0.player.y, enemies: s0.enemies && s0.enemies.length, bossBrains: s0.bossBrains && s0.bossBrains.length, dmgBy: s0.dmgBy } : null)}` });
    if (s0 && s0.ok) { try { fs.writeFileSync(path.join(__dirname, '..', 'rea', 'live-snapshot.json'), JSON.stringify(s0, null, 2)); } catch {} }
    let res;
    if (PROBE) { res = { run: runNo, probe: await probeSpeed(page, runNo) }; }
    else res = await playRun(page, runNo);
    res.job = job; res.stage = stageKey;
    stageResults.push(res);
    // Ladder: after a Prontera clear, same character/session -> sewer -> sunken.
    if (LADDER && res.cleared && stageKey === 'prontera') {
      for (const next of ['sewer', 'sunken']) {
        log({ run: runNo, msg: `LADDER: prontera cleared — attempting ${next} with the same character` });
        STAGE = next;
        if (!await returnToPlaza(page, runNo)) { stageResults.push({ run: runNo, job, stage: next, cause: 'could not return to plaza' }); break; }
        if (!await enterStage(page, runNo, next)) { stageResults.push({ run: runNo, job, stage: next, cause: 'could not enter stage / locked' }); break; }
        const hudOk2 = await waitVisible(page, '#hud', 30000);
        log({ run: runNo, msg: hudOk2 ? `ladder ${next}: HUD visible — playing` : `WARN ladder ${next}: HUD never appeared` });
        const res2 = await playRun(page, runNo + '-' + next);
        res2.job = job; res2.stage = next;
        stageResults.push(res2);
        if (!res2.cleared) break;
      }
    }
  } catch (e) {
    log({ run: runNo, msg: `ERROR run ${runNo}: ${String(e).slice(0, 500)}` });
    await shot(page, `r${runNo}-error`);
    stageResults.push({ run: runNo, job, stage: stageKey, cause: 'error: ' + String(e).slice(0, 200) });
  }
  clearInterval(previewTimer);
  return stageResults;
}
// Splash -> account -> character select. Needed both on first attach and after a
// patched-bundle reload, which always lands back on the splash screen.
async function passSplash(page) {
  const st = await waitForPlay(page, 180000, 'splash');
  if (st !== 'play') {
    log({ msg: 'WARN #sp-play never enabled within 180s' });
    return false;
  }
  log({ msg: 'splash ready — entering the already-signed-in account' });
  await page.evaluate(() => document.querySelector('#sp-play').click());
  await page.waitForTimeout(2500);
  // Pressing Play while signed out pops the account prompt over the splash.
  await dismissAccountModal(page, 'after pressing Play');
  const acc = await page.evaluate(() => { const el = document.querySelector('#account-popup'); return el ? !el.classList.contains('hidden') : false; });
  if (acc) {
    log({ msg: 'account popup appeared — staying on the saved guest (decline)' });
    await page.evaluate(() => { const b = document.querySelector('#acc-decline'); if (b) b.click(); });
    await page.waitForTimeout(1500);
  }
  return true;
}
async function runAttached() {
  const cdpUrl = argv['cdp-url'] || 'http://127.0.0.1:9222';
  let browser, browserSource, launchedBrowser = false;
  let storageState = HEADLESS && fs.existsSync(AUTH_STATE) ? AUTH_STATE : undefined;
  // Optional: restore a saved guest/account session BEFORE the app boots.
  // The game reads localStorage on load and mints a fresh guest in parallel
  // with any post-boot write, so a runtime setItem + reload loses the race.
  // Seed the context storage state instead; the first /api/save then carries
  // the saved token (verified: HTTP 200 GET api/save with account 38092).
  if (argv.session) {
    let seed = { cookies: [], origins: [] };
    try { if (typeof storageState === 'string' && fs.existsSync(storageState)) seed = JSON.parse(fs.readFileSync(storageState, 'utf8')); } catch { seed = { cookies: [], origins: [] }; }
    const origins = Array.isArray(seed.origins) ? seed.origins : [];
    const siteOrigin = new URL(SITE).origin;
    let site = origins.find(origin => origin.origin === siteOrigin);
    if (!site) { site = { origin: siteOrigin, localStorage: [] }; origins.push(site); }
    site.localStorage = (site.localStorage || []).filter(entry => entry.name !== 'ro-survivors-guest-session');
    site.localStorage.push({ name: 'ro-survivors-guest-session', value: String(argv.session) });
    storageState = { cookies: seed.cookies || [], origins };
  }
  if (await cdpIsReady(cdpUrl)) {
    browser = await chromium.connectOverCDP(cdpUrl);
    browserSource = 'existing browser session';
  } else {
    if (HEADLESS && !storageState) {
      throw new Error('Headless mode needs a saved sign-in. Start Visible mode once and sign in first.');
    }
    const executablePath = defaultBrowserExecutable();
    const profile = path.join(OUT, HEADLESS ? 'browser-profile-headless' : 'browser-profile-visible');
    fs.mkdirSync(profile, { recursive: true });
    const debugPort = new URL(cdpUrl).port || (new URL(cdpUrl).protocol === 'https:' ? '443' : '80');
    const args = [
      `--remote-debugging-port=${debugPort}`,
      '--remote-debugging-address=127.0.0.1',
      '--remote-allow-origins=*',
      `--user-data-dir=${profile}`,
      `--window-size=${VIEWPORT[0]},${VIEWPORT[1]}`,
      '--no-first-run',
      '--no-default-browser-check',
      '--ignore-certificate-errors',
      '--disable-dev-shm-usage',
      '--disable-background-timer-throttling',
      '--disable-renderer-backgrounding',
      ...(HEADLESS ? ['--headless=new', '--enable-unsafe-swiftshader', '--use-angle=swiftshader'] : []),
      ...(NEED_PROXY ? ['--proxy-server=http://127.0.0.1:18080'] : []),
    ];
    ownedBrowserProcess = spawn(executablePath, args, { detached: true, stdio: 'ignore' });
    ownedBrowserProcess.unref();
    launchedBrowser = true;
    browserSource = `app-launched ${HEADLESS ? 'headless' : 'visible'} default browser`;
    log({ msg: `${browserSource}: ${executablePath}` });
    let ready = false;
    for (let attempt = 0; attempt < 60; attempt++) {
      if (await cdpIsReady(cdpUrl)) { ready = true; break; }
      if (ownedBrowserProcess.exitCode !== null) break;
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    if (!ready) {
      if (ownedBrowserProcess.exitCode === null) ownedBrowserProcess.kill('SIGTERM');
      ownedBrowserProcess = null;
      throw new Error(`The default browser did not expose its local control endpoint: ${cdpUrl}`);
    }
    browser = await chromium.connectOverCDP(cdpUrl);
    if (HEADLESS) {
      ownedHeadlessContext = await browser.newContext({
        storageState, viewport: { width: VIEWPORT[0], height: VIEWPORT[1] },
        deviceScaleFactor: DSF, ignoreHTTPSErrors: true,
      });
    }
  }
  let page = null, state = null;
  const safeDialog = p => { try { p.on('dialog', async dialog => { try { await dialog.dismiss(); } catch {} }); } catch {} };
  for (const context of browser.contexts()) {
    for (const candidate of context.pages()) {
      if (!candidate.url().includes('ro-survivors.com')) continue;
      safeDialog(candidate);
      await installPatchedBundleRoute(candidate);
      const observed = await readState(candidate);
      if (isLiveRunState(observed)) {
        page = candidate; state = observed; break;
      }
      if (!page && START_FROM_EXISTING) page = candidate;
    }
    if (state) break;
  }
  if (!page) {
    const context = ownedHeadlessContext || browser.contexts()[0] || await browser.newContext();
    const pages = context.pages();
    page = launchedBrowser ? (pages[0] || await context.newPage()) :
      (pages.find(candidate => candidate.url() === 'about:blank') || await context.newPage());
    safeDialog(page);
    await installPatchedBundleRoute(page);
    if (!page.url().includes('ro-survivors.com')) await page.goto(SITE, { waitUntil: 'domcontentloaded' });
    state = await readState(page);
  } else {
    safeDialog(page);
  }
  // The saved session is already seeded into this context's storage state
  // (see runAttached). Only a CDP-attached browser needs the runtime fallback.
  if (argv.session && !(HEADLESS && ownedHeadlessContext)) {
    await page.evaluate(s => { try { localStorage.setItem('ro-survivors-guest-session', s); } catch {} }, String(argv.session));
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 120000 });
    await page.waitForTimeout(5000);
    log({ msg: 'session injected: reloaded the game with the saved account session' });
  } else if (argv.session) {
    log({ msg: 'session seeded into browser storage state before boot (no reload needed)' });
  }
  const patchRouteState = patchedRouteStates.get(page) || await installPatchedBundleRoute(page);
  // runAttached goes straight to the character select, but the splash has to
  // finish loading first (the loading bar takes ~25s) and an existing guest
  // account gets a register prompt after Play. Without this the bot clicked
  // nothing, found zero slots, and refused to start.
  const hudNow = await page.evaluate(() => document.querySelector('#hud')?.innerText || '').catch(() => '');
  const inPlaza = await page.evaluate(() => typeof window.__RO_PLAZA_SNAPSHOT__ === 'function' && !!window.__RO_PLAZA_SNAPSHOT__()?.ok).catch(() => false);
  const onSelectNow = await page.evaluate(() => { const el = document.querySelector('#charselect'); return !!el && !el.classList.contains('hidden'); }).catch(() => false);
  if (START_FROM_EXISTING && !isLiveRunState(state) && !inPlaza && !onSelectNow && !hudNow) await passSplash(page);
  const hasSnapshotApi = await page.evaluate(() => typeof window.__RO_SNAPSHOT__ === 'function').catch(() => false);
  // Some hosts serve the patched bundle themselves (the GUI app answers
  // /build/main-*.js at the protocol layer, so this bot's route never fires and
  // patchRouteState.served stays false). Ask the loaded bundle directly: if it
  // carries the instrumentation, the page is already patched — a reload would
  // be pointless and, worse, would abort the attach.
  const bundlePatched = hasSnapshotApi || inPlaza ? true : await page.evaluate(async () => {
    const src = [...document.querySelectorAll('script[src]')].map(s => s.src).find(s => /build\/main-/.test(s));
    if (!src) return false;
    try { const text = await (await fetch(src, { cache: 'no-store' })).text(); return text.includes('__RO_SNAPSHOT__') && text.includes('__RO_PLAZA_SNAPSHOT__'); }
    catch { return false; }
  }).catch(() => false);
  if (bundlePatched && !patchRouteState.served) log({ msg: 'patched bundle already served by this host — no reload needed' });
  // __RO_SNAPSHOT__ only appears inside a field, so a plaza page (which only renders
  // with the patched bundle) is already instrumented and must not be reloaded.
  if (!hasSnapshotApi && !inPlaza && !patchRouteState.served && !bundlePatched) {
    const pageState = await page.evaluate(() => {
      const text = document.body?.innerText || '';
      const gameOver = document.querySelector('#gameover') && !document.querySelector('#gameover').classList.contains('hidden');
      const inTown = /Fountain Square|Talk to the captain|Stylist|Ore Merchant|Channel\s+\d+/i.test(text);
      const mapNames = ['Sunken Ship', 'Prontera Fields', 'Prontera Culverts', 'Byalan Island', 'Payon Forest', 'Payon Cave'];
      const currentMap = mapNames.find(name => text.toLowerCase().includes(name.toLowerCase())) || null;
      const fieldCoordinates = /(?:Sunken Ship|Prontera Fields|Prontera Culverts|Byalan Island|Payon Forest|Payon Cave)[^\n]{0,100}\(\s*\d+\s*,\s*\d+\s*\)/i.test(text);
      const hasClock = /\b\d{2}:\d{2}\b/.test(text);
      return { gameOver: !!gameOver, currentMap, activeField: !inTown && fieldCoordinates && hasClock };
    }).catch(() => ({ gameOver: false, currentMap: null, activeField: false }));
    if (pageState.gameOver) {
      throw new Error('The browser is showing run results without snapshot instrumentation; refusing to reload and lose them.');
    }
    if (pageState.activeField && (!pageState.currentMap || (STAGE_MATCH[STAGE] || /$a/).test(pageState.currentMap))) {
      throw new Error('A run is active in the requested map, but this page lacks snapshot instrumentation; refusing to reload and lose progress.');
    }
    if (pageState.activeField) {
      log({ msg: `abandoning an uninstrumented ${pageState.currentMap} run to honor requested ${STAGE}; refreshing through the patched bundle route` });
    }
    log({ msg: 'idle game page lacks snapshot instrumentation; refreshing once through the patched bundle route' });
    // An installed service worker can serve a cached, unpatched bundle that Playwright
    // cannot intercept; drop it (and its caches) so the reload fetches the patched one.
    const dropped = await page.evaluate(async () => {
      const scopes = [];
      for (const registration of await navigator.serviceWorker.getRegistrations()) {
        scopes.push(registration.scope);
        await registration.unregister();
      }
      const names = await caches.keys();
      await Promise.all(names.map(name => caches.delete(name)));
      return { scopes, names };
    }).catch(() => null);
    if (dropped && dropped.scopes.length) log({ msg: `unregistered service worker ${dropped.scopes.join(', ')} and cleared ${dropped.names.length} cache(s) so the patched bundle is fetched` });
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 120000 });
    for (let attempt = 0; attempt < 80 && !patchRouteState.served; attempt++) {
      await page.waitForTimeout(250);
    }
    if (!patchRouteState.served) {
      // One retry: a freshly re-installed service worker can still win the race.
      log({ msg: 'patched bundle missed on first reload; clearing the service worker again and retrying' });
      await page.evaluate(async () => {
        for (const registration of await navigator.serviceWorker.getRegistrations()) await registration.unregister();
        await Promise.all((await caches.keys()).map(name => caches.delete(name)));
      }).catch(() => {});
      await page.reload({ waitUntil: 'domcontentloaded', timeout: 120000 });
      for (let attempt = 0; attempt < 80 && !patchRouteState.served; attempt++) {
        await page.waitForTimeout(250);
      }
    }
    if (!patchRouteState.served) {
      throw new Error('The patched game bundle was not loaded after refreshing the idle page; not steering.');
    }
    state = await readState(page);
    log({ msg: 'patched game bundle loaded; snapshot will become available when the selected character enters a field' });
    // The reload always lands on the splash screen; enter the saved account again.
    if (START_FROM_EXISTING) {
      await passSplash(page);
      state = await readState(page);
    }
  }
  const authContext = browser.contexts().find(context => context.pages().includes(page));
  if (!HEADLESS && authContext) await saveBrowserAuth(authContext);
  if (!page) throw new Error('Could not open the game in the selected browser.');
  let objectives;
  try { objectives = JSON.parse(argv.objectives || '[]'); } catch { throw new Error('--objectives must be a JSON array of objective names.'); }
  if (!Array.isArray(objectives)) throw new Error('--objectives must be a JSON array of objective names.');
  objectives = objectives.map(value => String(value).trim()).filter(Boolean);
  if (!objectives.length && argv['until-card']) objectives = [String(argv['until-card']).trim()].filter(Boolean);
  const maxCardRuns = Math.max(0, parseInt(argv['max-card-runs'] || '0', 10) || 0);
  if (objectives.length && !START_FROM_EXISTING) throw new Error('Repeat objectives require --start-existing=true so later runs can reuse the saved character.');
  if (!isLiveRunState(state) && !START_FROM_EXISTING) throw new Error('No active run; pass --start-existing=true to start from this signed-in browser profile.');
  const results = [];
  const foundObjectives = new Set();
  let runNo = 1, allObjectivesFound = false;
  while (true) {
    if (!isLiveRunState(state)) {
      const leftResults = await page.evaluate(() => {
        const overlay = document.querySelector('#gameover');
        const button = document.querySelector('#btn-restart');
        if (!overlay || overlay.classList.contains('hidden') || !button) return false;
        button.click();
        return true;
      }).catch(() => false);
      if (leftResults) {
        log({ run: runNo, msg: 'left Results screen via Back to character; reusing the signed-in profile' });
        await page.waitForTimeout(1500);
      }
      let onSelect = await page.evaluate(() => {
        const el = document.querySelector('#charselect');
        return !!el && !el.classList.contains('hidden');
      });
      for (let attempt = 0; attempt < 120 && !onSelect; attempt++) {
        const entered = await page.evaluate(() => !!document.querySelector('#hud')?.innerText);
        if (entered) break;
        await page.waitForTimeout(250);
        onSelect = await page.evaluate(() => {
          const el = document.querySelector('#charselect');
          return !!el && !el.classList.contains('hidden');
        });
      }
      if (!onSelect) {
        const openedAccount = await page.evaluate(() => {
          const button = [...document.querySelectorAll('*')].find(el => {
            const rect = el.getBoundingClientRect();
            return el.textContent?.replace(/\s+/g, ' ').trim() === 'Play!' && rect.width > 0 && rect.height > 0;
          });
          if (!button) return false;
          button.click();
          return true;
        });
        if (openedAccount) {
          log({ run: runNo, msg: 'opening the already-signed-in account; not creating an account' });
          for (let attempt = 0; attempt < 60; attempt++) {
            onSelect = await page.evaluate(() => {
              const el = document.querySelector('#charselect');
              return !!el && !el.classList.contains('hidden');
            });
            const hud = await page.evaluate(() => document.querySelector('#hud')?.innerText || '');
            if (onSelect || JOB_DEFS[JOB].re.test(hud)) break;
            await page.waitForTimeout(250);
          }
        }
      }
      // Starting while already in town: the plaza HUD does not name the character,
      // so hop back to character select to confirm the job before setting out.
      if (!onSelect) {
        const switched = await page.evaluate(() => {
          const el = [...document.querySelectorAll('button, [data-act]')]
            .find(b => /switch\s+character/i.test(b.textContent || '') && b.getBoundingClientRect().width > 0);
          if (!el) return false;
          el.click();
          return true;
        }).catch(() => false);
        if (switched) {
          log({ run: runNo, msg: 'already in town — switched back to character select to confirm the character' });
          for (let attempt = 0; attempt < 80; attempt++) {
            onSelect = await page.evaluate(() => {
              const el = document.querySelector('#charselect');
              return !!el && !el.classList.contains('hidden');
            });
            if (onSelect) break;
            await page.waitForTimeout(250);
          }
        }
      }
      let selectedExistingCharacter = null;
      if (onSelect) {
        const selected = await page.evaluate(reSrc => {
          const hit = [...document.querySelectorAll('#slots > *')]
            .find(el => new RegExp(reSrc, 'i').test(el.textContent) && !/empty slot/i.test(el.textContent));
          if (!hit) return null;
          hit.click();
          return hit.textContent.replace(/\s+/g, ' ').trim().slice(0, 120);
        }, JOB_DEFS[JOB].re.source);
        if (!selected) throw new Error(`No existing ${JOB} character found; refusing to create or select another job.`);
        selectedExistingCharacter = selected;
        log({ run: runNo, msg: `selected existing character: ${selected}` });
        await page.waitForTimeout(500);
        if (!await domClick(page, '#btn-play')) throw new Error('Could not open existing character in the signed-in profile.');
        await page.waitForTimeout(1500);
      }
      const setupHud = await page.evaluate(() => document.querySelector('#hud')?.innerText || '');
      if (!JOB_DEFS[JOB].re.test(setupHud) && !JOB_DEFS[JOB].re.test(selectedExistingCharacter || '')) {
        throw new Error(`Neither the selected character nor the game screen confirms ${JOB}; refusing to start another job.`);
      }
      log({ run: runNo, msg: `starting ${STAGE} from existing ${JOB}/profile; no guest account or slider changes` });
      if (!await enterStage(page, runNo, STAGE)) throw new Error(`Could not start selected stage ${STAGE} from the existing profile.`);
      for (let i = 0; i < 120; i++) {
        state = await readState(page);
        if (isLiveRunState(state)) break;
        await page.waitForTimeout(250);
      }
      if (!isLiveRunState(state)) throw new Error('Stage UI closed but no live run snapshot appeared; not steering.');
    }
    const wantedStage = STAGE_MATCH[STAGE] || STAGE_MATCH.prontera;
    if (state.stage && !wantedStage.test(String(state.stage))) {
      throw new Error(`Existing run is ${state.stage}, not the selected ${STAGE} stage; refusing to steer a different map.`);
    }
    for (const key of ['w', 'a', 's', 'd']) await page.keyboard.up(key).catch(() => {});
    const characterHud = await page.evaluate(() => document.querySelector('#hud')?.innerText || '');
    if (!JOB_DEFS[JOB].re.test(characterHud)) throw new Error(`The active character HUD does not identify ${JOB}; refusing to steer another job.`);
    const b = state.bounds;
    const center = b ? { x: (b.x0 + b.x1) / 2, y: (b.y0 + b.y1) / 2 } : null;
    const radius = center ? Math.round(Math.hypot(state.player.x - center.x, state.player.y - center.y)) : null;
    log({ run: runNo, msg: `ATTACHED existing browser; state=${state.state} stage=${state.stage} time=${state.time}s player=(${Math.round(state.player.x)},${Math.round(state.player.y)}) spawnRadius=${radius} jobPolicy=${JOB}; preserving signed-in profile and settings` });
    const result = await playRun(page, runNo);
    result.job = JOB; result.stage = STAGE;
    await page.waitForTimeout(500);
    const observed = await page.evaluate(() => {
      const names = value => Array.isArray(value) ? value.flatMap(item => {
        if (typeof item === 'string') return [item];
        if (!item || typeof item !== 'object') return [];
        return ['name', 'title', 'label', 'id', 'key', 'type', 'kind'].map(key => item[key]).filter(value => typeof value === 'string');
      }) : [];
      const root = window.__RO__ || {};
      const cards = [...document.querySelectorAll('#gameover .go-cards .cardimg')].map(card => card.title || card.getAttribute('alt') || '').filter(Boolean);
      const resultText = document.querySelector('#gameover')?.innerText || '';
      const lootNames = [...names(root.runLoot), ...names(root.runCards), ...names(root.runEggs)];
      return { cards, lootNames, resultText };
    }).catch(() => ({ cards: [], lootNames: [], resultText: '' }));
    const resultNames = [...observed.cards, ...observed.lootNames, observed.resultText];
    result.cards = observed.cards;
    result.lootNames = observed.lootNames;
    for (const objective of mergeFoundObjectives(foundObjectives, resultNames, objectives)) foundObjectives.add(objective);
    result.objectiveStatus = objectives.map(objective => ({ objective, found: foundObjectives.has(objective.toLowerCase()) }));
    result.foundObjectives = [...foundObjectives];
    allObjectivesFound = allObjectivesObtained(foundObjectives, objectives);
    log({ run: runNo, msg: `RESULT-OBJECTIVES: ${JSON.stringify(result.objectiveStatus)}; progress=${foundObjectives.size}/${objectives.length}; complete=${allObjectivesFound}; resultCards=${JSON.stringify(observed.cards)}; lootNames=${JSON.stringify(observed.lootNames)}` });
    results.push(result);
    if (!objectives.length || allObjectivesFound || (maxCardRuns > 0 && runNo >= maxCardRuns)) break;
    log({ run: runNo, msg: `objectives incomplete; starting run ${runNo + 1} on the same saved ${JOB}` });
    const returned = await page.evaluate(() => {
      const overlay = document.querySelector('#gameover');
      const button = document.querySelector('#btn-restart');
      if (!overlay || overlay.classList.contains('hidden') || !button) return false;
      button.click();
      return true;
    }).catch(() => false);
    if (returned) await page.waitForTimeout(1500);
    state = null;
    runNo++;
  }
  const patchedSha = PATCHED ? require('crypto').createHash('sha256').update(fs.readFileSync(PATCHED)).digest('hex').slice(0, 16) : 'none';
  fs.writeFileSync(path.join(OUT, `summary-${RUN_TAG}.json`), JSON.stringify({
    tag: RUN_TAG, bot: 'v6.2-pre-boss-thinning-attached', job: JOB, stage: STAGE,
    runs: results.length, maxSeconds: MAX_SECONDS, objectives, foundObjectives: [...foundObjectives], allObjectivesFound,
    attached: browserSource, patchedSha256: patchedSha, results,
  }, null, 2));
  if (authContext) await saveBrowserAuth(authContext);
  await closeOwnedHeadlessBrowser();
  await new Promise(resolve => logStream.end(resolve));
  process.exit(0); // Leave a user-visible browser open; close only the app-owned headless browser.
}

// v6.1 harness: the browser can die under load (renderer OOM-killed
// while another agent's headed browser hogs the shared CPU) — a dead
// browser used to kill the whole batch at the next runOne's newContext
// (outside runOne's try/catch). Relaunch on demand, never lose the batch.
async function launchBrowser() {
  // --gpu=true lets headless Chromium use the machine's real GPU through
  // ANGLE; the default forces SwiftShader, which burns a full CPU core per
  // instance (and this box has only 4 cores).
  const GPU = argv.gpu === 'true';
  // A shared disk cache lets the second and later instances load the game's
  // assets from disk instead of downloading them again (the game ships a lot
  // of art). Each account still keeps its own profile (cookies, localStorage).
  const cacheDir = argv['cache-dir'] || '';
  return chromium.launch({
    headless: HEADLESS,
    args: [
      ...(GPU ? ['--use-angle=gl', '--enable-gpu', '--ignore-gpu-blocklist', '--enable-features=Vulkan,SkiaGraphite'] : ['--enable-unsafe-swiftshader', '--use-angle=swiftshader']),
      ...(cacheDir ? [`--disk-cache-dir=${cacheDir}`] : []),
      '--disable-gpu-sandbox', '--no-sandbox',
      `--window-size=${VIEWPORT[0]},${VIEWPORT[1]}`,
      ...(NEED_PROXY ? ['--proxy-server=http://127.0.0.1:18080'] : []),
      '--ignore-certificate-errors', '--disable-dev-shm-usage', '--mute-audio',
      '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
      // Keep the GPU process light: the farm renders many small canvases.
      '--disable-features=CalculateNativeWinOcclusion',
    ],
  });
}
async function ensureBrowser(browser) {
  if (browser && browser.isConnected()) return browser;
  log({ msg: 'browser dead — relaunching for the next run' });
  try { await browser.close().catch(() => {}); } catch {}
  return launchBrowser();
}
async function safeRunOne(browser, runNo, job, stageKey) {
  try { return await runOne(browser, runNo, job, stageKey); }
  catch (e) {
    log({ run: runNo, msg: `ERROR run ${runNo} (outside runOne): ${String(e).slice(0, 300)}` });
    return [{ run: runNo, job, stage: stageKey, cause: 'error: ' + String(e).slice(0, 200) }];
  }
}
// The site registers a service worker that caches the game's bundle. The
// worker fetches the bundle itself (Playwright does not intercept worker
// requests), so it would serve the UNPATCHED bundle on the next load and the
// bot would lose its state API. Drop the worker and its caches before every
// load so the patched bundle is always the one that runs.
async function clearSiteCaches(page) {
  await page.evaluate(async () => {
    try {
      if (navigator.serviceWorker) {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const r of regs) { try { await r.unregister(); } catch {} }
      }
    } catch {}
    try {
      if (window.caches) {
        const keys = await caches.keys();
        for (const k of keys) { try { await caches.delete(k); } catch {} }
      }
    } catch {}
  }).catch(() => {});
}

// The splash replaces the Play button with "Check again" while the server is
// in maintenance. Waiting for a Play button that never appears just burns
// the wait; this helper reports the maintenance state instead, and pokes the
// "Check again" button every minute so the splash picks the server up again
// on its own.
async function splashState(page) {
  return page.evaluate(() => {
    const b = document.querySelector('#sp-play');
    const maint = document.querySelector('.sp-maint-retry');
    const text = document.body ? (document.body.innerText || '') : '';
    return {
      play: !!(b && !b.disabled),
      maintenance: !!maint || /under maintenance|server maintenance/i.test(text),
    };
  }).catch(() => ({ play: false, maintenance: false }));
}
async function waitForPlay(page, maxMs, label) {
  const deadline = Date.now() + maxMs;
  let saidMaint = false;
  while (Date.now() < deadline) {
    const st = await splashState(page);
    if (st.play) return 'play';
    if (st.maintenance && !saidMaint) {
      saidMaint = true;
      log({ msg: `the splash says the server is in maintenance — waiting (checked every 60s, starts automatically)${label ? ` [${label}]` : ''}` });
    }
    if (saidMaint) {
      await page.evaluate(() => { const b = document.querySelector('.sp-maint-retry'); if (b) b.click(); }).catch(() => {});
      await page.waitForTimeout(60000);
    } else {
      await page.waitForTimeout(2000);
    }
  }
  return 'timeout';
}

// The splash puts a "You now need an account" modal over everything once
// Play is pressed while signed out. It has to be dismissed before the login
// tab (and the rest of the splash) can be used.
async function dismissAccountModal(page, why) {
  const dismissed = await page.evaluate(() => {
    const all = [...document.querySelectorAll('button, .ro-btn, [role=button]')];
    const b = all.find(x => /i have an account/i.test((x.textContent || '').trim()));
    if (b) { b.click(); return true; }
    return false;
  }).catch(() => false);
  if (dismissed) {
    await page.waitForTimeout(700);
    log({ msg: `dismissed the "I have an account" prompt${why ? ` (${why})` : ''}` });
  }
  return dismissed;
}

// Sign the page into a game ACCOUNT at the splash's own login tab. The
// session is then cached per account (AUTH_STATE) so later runs skip this.
// A maintenance answer is not a rejection: the attempt is repeated until the
// server is back, so an unattended instance recovers on its own.
async function ensureAccountLogin(page) {
  const user = ACCOUNT_USER, pass = ACCOUNT_PASS;
  if (!user || !pass) return false;
  for (let attempt = 1; attempt <= 120; attempt++) {
    const res = await attemptAccountLogin(page, user, pass);
    if (res !== 'maintenance') return res === 'ok';
    log({ msg: 'the server is in maintenance — the sign-in is retried in 60s' });
    await page.waitForTimeout(60000);
    await page.evaluate(() => { const b = document.querySelector('.sp-maint-retry'); if (b) b.click(); }).catch(() => {});
  }
  log({ msg: 'WARN the server stayed in maintenance for 2 hours — giving up on this sign-in' });
  return false;
}

async function attemptAccountLogin(page, user, pass) {
  let ready = false;
  {
    const st = await waitForPlay(page, 120000, 'account login');
    ready = st === 'play';
  }
  if (!ready) { log({ msg: 'WARN splash never became ready for the account login' }); return 'failed'; }
  await dismissAccountModal(page, 'before signing in');
  const signed = await page.evaluate((u) => {
    // The splash shows the signed-in account name on the first tab when the
    // session is still valid, so a case-insensitive name match is enough.
    const txt = (document.body.innerText || '').toLowerCase();
    return txt.includes(String(u).toLowerCase());
  }, user).catch(() => false);
  if (signed) { log({ msg: `account already signed in: ${user}` }); return 'ok'; }
  log({ msg: `signing in as ${user}` });
  await page.evaluate(() => { const t = document.querySelector('.sp-tabs [data-sp-tab="login"]'); if (t) t.click(); });
  await page.waitForTimeout(800);
  await page.evaluate(({ u, p }) => {
    const f = document.getElementById('sp-login');
    if (!f) return;
    // The game reads the fields through their input events; setting .value
    // alone leaves it with empty credentials and it silently stays on guest.
    const iu = f.querySelector('input[name="username"]');
    const ip = f.querySelector('input[name="password"]');
    iu.value = u; iu.dispatchEvent(new Event('input', { bubbles: true }));
    ip.value = p; ip.dispatchEvent(new Event('input', { bubbles: true }));
    f.querySelector('.sp-submit').click();
  }, { u: user, p: pass });
  for (let waited = 0; waited < 40000; waited += 2000) {
    // A successful login lands on the character select screen with the
    // account's characters. Accounts without a display name show nothing
    // about the user name there, so the screen itself is the signal.
    const st = await page.evaluate(() => {
      const cs = document.getElementById('charselect');
      const slots = [...document.querySelectorAll('#slots > *')].map(e => e.textContent.replace(/\s+/g, ' ').trim()).filter(t => t && !/empty slot/i.test(t));
      return {
        charselect: !!(cs && !cs.classList.contains('hidden')),
        err: (document.querySelector('#sp-login .sp-error')?.textContent || '').trim(),
        slots: slots.length,
      };
    }).catch(() => ({ charselect: false, err: '', slots: 0 }));
    if (st.err) {
      if (/maintenance|server is down|come back in a few minutes/i.test(st.err)) return 'maintenance';
      log({ msg: `login rejected: ${st.err}` });
      return 'rejected';
    }
    if (st.charselect) {
      log({ msg: `signed in as ${user}${st.slots ? ` (${st.slots} character slot(s))` : ''}` });
      await saveBrowserAuth(page.context());
      return 'ok';
    }
    await page.waitForTimeout(2000);
  }
  log({ msg: 'WARN account login did not confirm within 40s' });
  return 'failed';
}

// Camoufox (Firefox) sign-in, at the splash's own login tab. Runs before
// enterGame so the later Play click lands on the signed-in account.
async function loginCamoufox(page) {
  const user = process.env.RO_BOT_USER || argv.username || '';
  const pass = process.env.RO_BOT_PASS || argv.password || '';
  const signedIn = await page.evaluate(() => { try { const a = JSON.parse(localStorage.getItem('ro-survivors.account.v1') || 'null'); return !!(a && a.name); } catch { return false; } }).catch(() => false);
  if (signedIn) { log({ msg: 'camoufox: profile already signed in — skipping login' }); return; }
  if (!user || !pass) { log({ msg: 'camoufox: no saved sign-in and no username/password given — staying on guest (selectCharacter will create a guest character)' }); return; }
  let ready = false;
  {
    const st = await waitForPlay(page, 180000, 'camoufox login');
    ready = st === 'play';
  }
  if (!ready) { log({ msg: 'WARN camoufox: splash never ready for login' }); return; }
  await dismissAccountModal(page, 'camoufox before signing in');
  log({ msg: `camoufox: signing in as ${user}` });
  await page.evaluate(() => { const t = document.querySelector('.sp-tabs [data-sp-tab="login"]'); if (t) t.click(); });
  await page.waitForTimeout(800);
  await page.evaluate(({ u, p }) => {
    const f = document.getElementById('sp-login');
    if (!f) return;
    const iu = f.querySelector('input[name="username"]');
    const ip = f.querySelector('input[name="password"]');
    iu.value = u; iu.dispatchEvent(new Event('input', { bubbles: true }));
    ip.value = p; ip.dispatchEvent(new Event('input', { bubbles: true }));
    f.querySelector('.sp-submit').click();
  }, { u: user, p: pass });
  for (let waited = 0; waited < 40000; waited += 2000) {
    const ok = await page.evaluate(() => {
      const cs = document.getElementById('charselect');
      return {
        charselect: !!(cs && !cs.classList.contains('hidden')),
        session: !!localStorage.getItem('ro-survivors-session'),
      };
    }).catch(() => ({ charselect: false, session: false }));
    if (ok.charselect || ok.session) { log({ msg: `camoufox: signed in as ${user}` }); return; }
    await page.waitForTimeout(2000);
  }
  log({ msg: 'WARN camoufox: login did not confirm within 40s — continuing' });
}

// Multi-account headless mode: one persistent Camoufox profile, real login,
// character auto-created on first run, 5s preview screenshots into OUT.
async function runCamoufox() {
  const { firefox } = require(CAMOUFOX_ROOT + '/playwright-core');
  const { launchOptions } = require(CAMOUFOX_ROOT + '/camoufox-js');
  const { generateFingerprint } = require(CAMOUFOX_ROOT + '/camoufox-js/dist/fingerprints.js');
  const profileDir = argv.profile || path.join(OUT, `camoufox-profile-${RUN_TAG}`);
  fs.mkdirSync(profileDir, { recursive: true });
  // Headless instances must be SILENT:
  //   media.volume_scale 0 -> Firefox scales every audio stream to zero.
  // Prefs go through the profile's user.js because camoufox's protocol
  // injector refuses double prefs. (Do NOT disable service workers here:
  // that breaks Playwright's request interception in Firefox, which is how
  // the patched game bundle gets served.)
  const userJs = path.join(profileDir, 'user.js');
  try {
    fs.writeFileSync(userJs, [
      'user_pref("media.volume_scale", 0.0);',
      '',
    ].join('\n'));
  } catch {}
  let fingerprint = null;
  try { fingerprint = JSON.parse(fs.readFileSync(path.join(profileDir, 'fingerprint.json'), 'utf8')); } catch {}
  if (!fingerprint) {
    fingerprint = generateFingerprint(undefined, { operatingSystems: ['linux'] });
    try { fs.writeFileSync(path.join(profileDir, 'fingerprint.json'), JSON.stringify(fingerprint)); } catch {}
  }
  const opts = await launchOptions({ headless: true, humanize: true, enable_cache: true, os: 'linux', fingerprint, iKnowWhatImDoing: true });
  log({ msg: `camoufox: launching headless profile ${profileDir}` });
  const ctx = await firefox.launchPersistentContext(profileDir, { ...opts, viewport: { width: VIEWPORT[0], height: VIEWPORT[1] }, deviceScaleFactor: DSF, ignoreHTTPSErrors: true });
  camoufoxContext = ctx;
  const page = ctx.pages()[0] || await ctx.newPage();
  // Before any game script runs: English + muted (game-level silence), so the
  // instance never produces sound even if the M keypress is refused.
  await page.addInitScript(() => {
    try {
      const KEY = 'ro-survivors:settings';
      let s = {};
      try { s = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch {}
      s.lang = 'en';
      s.muted = true;
      localStorage.setItem(KEY, JSON.stringify(s));
    } catch {}
  });
  await installPatchedBundleRoute(page);
  page.on('dialog', async d => { try { await d.dismiss(); } catch {} });
  page.on('console', m => { if (/error|replay/i.test(m.text())) log({ msg: `console.${m.type()}: ${m.text().slice(0, 300)}` }); });
  page.on('pageerror', e => log({ msg: `pageerror: ${String(e).slice(0, 300)}` }));

  const shotEvery = Math.max(1, parseInt(argv['shot-every'] || '5', 10));
  const shotPath = path.join(OUT, argv.shot || 'shot.png');
  const shotTimer = setInterval(() => { page.screenshot({ path: shotPath }).catch(() => {}); }, shotEvery * 1000);
  log({ msg: `camoufox: preview shots every ${shotEvery}s → ${shotPath}` });

  try {
    await page.goto(SITE, { waitUntil: 'domcontentloaded', timeout: 120000 });
    await loginCamoufox(page);
    // Mute the game itself. The init script already sets the game's muted
    // flag, so only press M when it is somehow not muted — pressing it
    // blindly would toggle a muted game back to sound.
    try {
      const before = await page.evaluate(() => { try { return JSON.parse(localStorage.getItem('ro-survivors:settings') || '{}').muted; } catch { return null; } }).catch(() => null);
      if (before !== true) { await page.keyboard.press('m'); await page.waitForTimeout(800); }
      const muted = await page.evaluate(() => { try { return JSON.parse(localStorage.getItem('ro-survivors:settings') || '{}').muted; } catch { return null; } }).catch(() => null);
      log({ msg: `camoufox: muted=${muted} (browser volume scaled to 0)` });
    } catch (e) { log({ msg: `camoufox: mute key failed: ${String(e).slice(0, 120)}` }); }
    const results = [];
    let runNo = 0;
    for (let i = 0; i < RUNS; i++) {
      runNo++;
      await clearSiteCaches(page);
      const rs = await runOneWithPage(page, runNo, JOB, STAGE);
      results.push(...rs);
      if (i < RUNS - 1) await sleep(3000);
    }
    const summary = { tag: RUN_TAG, bot: 'v6.2-camoufox', job: JOB, stage: STAGE, runs: RUNS, maxSeconds: MAX_SECONDS, headless: true, viewport: VIEWPORT.join('x'), dsf: DSF, results };
    fs.writeFileSync(path.join(OUT, `summary-${RUN_TAG}.json`), JSON.stringify(summary, null, 2));
    log({ msg: `DONE. ${JSON.stringify(results.map(r => ({ run: r.run, job: r.job, stage: r.stage, s: r.survivedSeconds, gameS: r.gameSeconds, lv: r.level, kills: r.kills, cleared: !!r.cleared, cause: r.cause })))}` });
  } finally {
    clearInterval(shotTimer);
    await ctx.close().catch(() => {});
    camoufoxContext = null;
  }
}

// The game's own status endpoint. "warn"/"down" means the server is in
// maintenance: no lobby, no party, no runs. The bot says so instead of
// spinning on a dead server.
async function serverStatus() {
  try {
    const res = await fetch('https://ro-survivors.com/status.json', { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const j = await res.json();
    return (j && typeof j === 'object') ? j : null;
  } catch { return null; }
}
// status.json is a hand-written flag and it can go stale: it stayed
// "maintenance" long after both servers were back up. The lobby list is the
// truth (it says per-lobby "up" and "state"). Returns 'up', 'down' or
// 'unknown' (unknown = the list could not be read, so do not block on it).
async function serverLive() {
  try {
    const res = await fetch('https://ro-survivors.com/api/lobbies', { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return 'unknown';
    const j = await res.json();
    const list = Array.isArray(j && j.lobbies) ? j.lobbies : [];
    if (!list.length) return 'unknown';
    return list.some(l => l && l.up !== false && (!l.state || l.state === 'ok')) ? 'up' : 'down';
  } catch { return 'unknown'; }
}
// A persistent profile keeps the game's HTTP cache and the account session
// between runs, so an instance starts warm instead of downloading the whole
// art pack again (that was ~80s per start).
const PROFILE_DIR = argv.profile || '';
async function launchPersistentContext() {
  const dir = PROFILE_DIR;
  fs.mkdirSync(dir, { recursive: true });
  // Seed a fresh profile from a warm one: the game assets are the same for
  // every account, only the login differs.
  const seed = argv['cache-seed'];
  if (seed && fs.existsSync(seed) && !fs.existsSync(path.join(dir, 'Cache'))) {
    try { fs.cpSync(seed, path.join(dir, 'Cache'), { recursive: true, force: false }); log({ msg: `cache seeded from ${seed}` }); } catch {}
  }
  const GPU = argv.gpu === 'true';
  const cacheDir = argv['cache-dir'] || '';
  return await chromium.launchPersistentContext(dir, {
    headless: HEADLESS,
    viewport: { width: VIEWPORT[0], height: VIEWPORT[1] },
    deviceScaleFactor: DSF,
    ignoreHTTPSErrors: true,
    args: [
      ...(GPU ? ['--use-angle=gl', '--enable-gpu', '--ignore-gpu-blocklist', '--enable-features=Vulkan,SkiaGraphite'] : ['--enable-unsafe-swiftshader', '--use-angle=swiftshader']),
      ...(cacheDir ? [`--disk-cache-dir=${cacheDir}`] : []),
      '--disable-gpu-sandbox', '--no-sandbox',
      `--window-size=${VIEWPORT[0]},${VIEWPORT[1]}`,
      ...(NEED_PROXY ? ['--proxy-server=http://127.0.0.1:18080'] : []),
      '--ignore-certificate-errors', '--disable-dev-shm-usage', '--mute-audio',
      '--disable-background-timer-throttling', '--disable-renderer-backgrounding',
    ],
  });
}
async function safeRunOnePage(page, runNo, job, stageKey) {
  try { return await runOneWithPage(page, runNo, job, stageKey); }
  catch (e) {
    log({ run: runNo, msg: `ERROR run ${runNo} (outside runOne): ${String(e).slice(0, 300)}` });
    return [{ run: runNo, job, stage: stageKey, cause: 'error: ' + String(e).slice(0, 200) }];
  }
}
async function runPersistent() {
  const ctx = await launchPersistentContext();
  camoufoxContext = ctx;   // closed on SIGTERM
  const page = ctx.pages()[0] || await ctx.newPage();
  const results = [];
  let runNo = 0;
  for (let i = 0; i < RUNS; i++) {
    runNo++;
    const rs = await safeRunOnePage(page, runNo, JOB, STAGE);
    results.push(...rs);
    if (i < RUNS - 1) await sleep(3000);
  }
  const summary = { tag: RUN_TAG, bot: 'v6.2-persistent', job: JOB, stage: STAGE, runs: RUNS, maxSeconds: MAX_SECONDS, headless: HEADLESS, viewport: VIEWPORT.join('x'), dsf: DSF, results };
  fs.writeFileSync(path.join(OUT, `summary-${RUN_TAG}.json`), JSON.stringify(summary, null, 2));
  log({ msg: `DONE. ${JSON.stringify(results.map(r => ({ run: r.run, job: r.job, stage: r.stage, s: r.survivedSeconds, gameS: r.gameSeconds, lv: r.level, kills: r.kills, cleared: !!r.cleared, cause: r.cause })))}` });
  await ctx.close().catch(() => {});
  camoufoxContext = null;
}
async function main() {
  await sleep(1500);
  log({ msg: `bot v6.2 PRE-BOSS THINNING start: recordVideo=${RECORD_VIDEO} headed=${!HEADLESS} job=${JOB} stage=${STAGE} compare=${COMPARE} ladder=${LADDER} maxLoot=${MAX_LOOT} runs=${RUNS} max ${MAX_SECONDS}s/run, headless=${HEADLESS}, viewport=${VIEWPORT.join('x')} dsf=${DSF}, probe=${PROBE}, out=${OUT}, patched=${PATCHED}` });
  if (!PATCHED || !fs.existsSync(PATCHED)) log({ msg: 'patched bundle unavailable — running the plain live bundle (the farm still works)' });
  if (!JOB_DEFS[JOB]) { console.error(`unknown job ${JOB} — use archer|mage|swordsman|acolyte`); process.exit(1); }
  const status = await serverStatus();
  if (status && status.state === 'down') {
    const when = status.at ? new Date(status.at).toISOString().replace('T', ' ').slice(0, 16) + ' UTC' : 'soon';
    log({ msg: `server is down (${when}): ${status.message || 'maintenance'} — no runs until it reopens` });
    console.log(`[server] down: ${status.message || 'maintenance'} (${when})`);
    process.exit(0);
  }
  if (status && (status.state === 'maintenance' || status.state === 'warn') && status.message && /maintenance/i.test(status.message) && !process.env.RO_BOT_IGNORE_MAINTENANCE) {
    // Maintenance: the game cannot run, so do not burn a core waiting for it.
    // Poll the server and start the moment it is back. The game client reads
    // the very same status.json, so this flag is the truth.
    log({ msg: `server in maintenance — waiting (checked every 60s, starts automatically)` });
    for (;;) {
      await sleep(60000);
      const s = await serverStatus();
      if (s && s.state !== 'maintenance' && s.state !== 'down') { log({ msg: `server back (state=${s.state}) — starting` }); break; }
    }
  }
  if (CAMOUFOX) { await runCamoufox(); return; }
  if (PROFILE_DIR) { await runPersistent(); return; }
  if (ATTACH_EXISTING) { await runAttached(); return; }
  let browser = await launchBrowser();
  const results = [];
  let runNo = 0;
  if (COMPARE) {
    // One run per job, same config; pick the fastest clearer for the main runs.
    const compareResults = [];
    for (const job of ['archer', 'mage', 'swordsman']) {
      runNo++;
      browser = await ensureBrowser(browser);
      const rs = await safeRunOne(browser, runNo, job, 'prontera');
      compareResults.push(...rs);
      results.push(...rs);
      await sleep(3000);
    }
    const score = r => (r.cleared ? 100000 : 0) + (r.gameSeconds || 0) * 10 + (r.kills || 0);
    const best = [...compareResults].sort((a, b) => score(b) - score(a))[0];
    JOB = best.job;
    log({ msg: `COMPARE done: ${JSON.stringify(compareResults.map(r => ({ job: r.job, s: r.survivedSeconds, gameS: r.gameSeconds, lv: r.level, kills: r.kills, cleared: !!r.cleared, cause: r.cause })))} — BEST JOB: ${JOB}` });
  }
  for (let i = 0; i < RUNS; i++) {
    runNo++;
    browser = await ensureBrowser(browser);
    const rs = await safeRunOne(browser, runNo, JOB, STAGE);
    results.push(...rs);
    // v6: a state-lost abort is an environment failure (renderer died),
    // not a run — retry the slot once with a fresh attempt.
    if (rs.some(r => typeof r.cause === 'string' && r.cause.startsWith('state-lost'))) {
      log({ msg: `run ${runNo} aborted on state-lost — retrying the slot once with a fresh attempt` });
      runNo++;
      browser = await ensureBrowser(browser);
      const rs2 = await safeRunOne(browser, runNo, JOB, STAGE);
      results.push(...rs2);
      await sleep(3000);
    }
    if (i < RUNS - 1) await sleep(3000);
  }
  await browser.close().catch(() => {}); if (relay) relay.kill();
  const patchedSha = PATCHED ? require('crypto').createHash('sha256').update(fs.readFileSync(PATCHED)).digest('hex').slice(0, 16) : 'none';
  const summary = { tag: RUN_TAG, bot: 'v6.2-pre-boss-thinning', job: JOB, compare: COMPARE, ladder: LADDER, runs: RUNS, maxSeconds: MAX_SECONDS, headless: HEADLESS, viewport: VIEWPORT.join('x'), dsf: DSF, probe: PROBE, patchedBundle: 'rea/patched/main-BNOcv2PN.js', patchedSha256: patchedSha, results };
  fs.writeFileSync(path.join(OUT, `summary-${RUN_TAG}.json`), JSON.stringify(summary, null, 2));
  log({ msg: `DONE. ${JSON.stringify(results.map(r => ({ run: r.run, job: r.job, stage: r.stage, s: r.survivedSeconds, gameS: r.gameSeconds, lv: r.level, kills: r.kills, cleared: !!r.cleared, cause: r.cause })))}` });
}
main().catch(e => { console.error(e); if (relay) relay.kill(); process.exit(1); });
